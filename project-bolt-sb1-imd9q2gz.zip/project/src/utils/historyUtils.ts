import { HistoryManager, HistoryState, Design, CanvasElement } from '../types';

// إنشاء مدير تاريخ جديد
export const createHistoryManager = (initialDesign: Design, initialSelectedElement: CanvasElement | null): HistoryManager => {
  const initialState: HistoryState = {
    design: initialDesign,
    selectedElement: initialSelectedElement
  };

  return {
    past: [],
    present: initialState,
    future: []
  };
};

// إضافة حالة جديدة إلى التاريخ
export const pushHistory = (
  historyManager: HistoryManager,
  design: Design,
  selectedElement: CanvasElement | null
): HistoryManager => {
  // إنشاء نسخة عميقة من الحالة الحالية
  const newPresent: HistoryState = {
    design: JSON.parse(JSON.stringify(design)),
    selectedElement: selectedElement ? JSON.parse(JSON.stringify(selectedElement)) : null
  };

  // إضافة الحالة الحالية إلى الماضي وتعيين الحالة الجديدة كحالة حالية
  return {
    past: [...historyManager.past, historyManager.present],
    present: newPresent,
    future: [] // مسح المستقبل عند إضافة حالة جديدة
  };
};

// التراجع عن آخر تغيير
export const undo = (historyManager: HistoryManager): HistoryManager => {
  if (historyManager.past.length === 0) {
    return historyManager; // لا يمكن التراجع أكثر
  }

  const previous = historyManager.past[historyManager.past.length - 1];
  const newPast = historyManager.past.slice(0, historyManager.past.length - 1);

  return {
    past: newPast,
    present: previous,
    future: [historyManager.present, ...historyManager.future]
  };
};

// إعادة التغيير الذي تم التراجع عنه
export const redo = (historyManager: HistoryManager): HistoryManager => {
  if (historyManager.future.length === 0) {
    return historyManager; // لا يمكن الإعادة أكثر
  }

  const next = historyManager.future[0];
  const newFuture = historyManager.future.slice(1);

  return {
    past: [...historyManager.past, historyManager.present],
    present: next,
    future: newFuture
  };
};

// التحقق من إمكانية التراجع
export const canUndo = (historyManager: HistoryManager): boolean => {
  return historyManager.past.length > 0;
};

// التحقق من إمكانية الإعادة
export const canRedo = (historyManager: HistoryManager): boolean => {
  return historyManager.future.length > 0;
};