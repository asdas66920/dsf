import Handlebars from 'handlebars';
import { DataBinding } from '../types';

// تسجيل مساعدات (helpers) إضافية لـ Handlebars
export const registerHandlebarsHelpers = () => {
  // تنسيق التاريخ
  Handlebars.registerHelper('formatDate', function(value, format) {
    if (!value) return '';
    
    try {
      const date = new Date(value.toString());
      if (isNaN(date.getTime())) return value;
      
      // تنسيقات مختلفة للتاريخ
      switch (format) {
        case 'short':
          return date.toLocaleDateString('ar-SA');
        case 'long':
          return date.toLocaleDateString('ar-SA', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          });
        case 'time':
          return date.toLocaleTimeString('ar-SA');
        case 'datetime':
          return date.toLocaleString('ar-SA');
        default:
          return date.toLocaleDateString('ar-SA');
      }
    } catch (error) {
      console.error('خطأ في تنسيق التاريخ:', error);
      return value;
    }
  });

  // تنسيق العملة
  Handlebars.registerHelper('formatCurrency', function(value, currency = 'SAR') {
    if (value === undefined || value === null) return '';
    
    try {
      const num = typeof value === 'string' ? parseFloat(value) : value;
      if (isNaN(num)) return value;
      
      return new Intl.NumberFormat('ar-SA', { 
        style: 'currency', 
        currency: currency 
      }).format(num);
    } catch (error) {
      console.error('خطأ في تنسيق العملة:', error);
      return value;
    }
  });

  // تنسيق الرقم
  Handlebars.registerHelper('formatNumber', function(value, decimals = 2) {
    if (value === undefined || value === null) return '';
    
    try {
      const num = typeof value === 'string' ? parseFloat(value) : value;
      if (isNaN(num)) return value;
      
      return new Intl.NumberFormat('ar-SA', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
      }).format(num);
    } catch (error) {
      console.error('خطأ في تنسيق الرقم:', error);
      return value;
    }
  });

  // تنسيق النسبة المئوية
  Handlebars.registerHelper('formatPercent', function(value, decimals = 2) {
    if (value === undefined || value === null) return '';
    
    try {
      const num = typeof value === 'string' ? parseFloat(value) : value;
      if (isNaN(num)) return value;
      
      return new Intl.NumberFormat('ar-SA', { 
        style: 'percent',
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
      }).format(num / 100);
    } catch (error) {
      console.error('خطأ في تنسيق النسبة المئوية:', error);
      return value;
    }
  });

  // اختصار النص
  Handlebars.registerHelper('truncate', function(text, length = 50) {
    if (!text) return '';
    
    text = text.toString();
    if (text.length <= length) return text;
    return text.substring(0, length) + '...';
  });

  // تحويل النص إلى حروف كبيرة
  Handlebars.registerHelper('uppercase', function(text) {
    if (!text) return '';
    return text.toString().toUpperCase();
  });

  // تحويل النص إلى حروف صغيرة
  Handlebars.registerHelper('lowercase', function(text) {
    if (!text) return '';
    return text.toString().toLowerCase();
  });

  // الشرط المتقدم
  Handlebars.registerHelper('ifCond', function(v1, operator, v2, options) {
    switch (operator) {
      case '==':
        return (v1 == v2) ? options.fn(this) : options.inverse(this);
      case '===':
        return (v1 === v2) ? options.fn(this) : options.inverse(this);
      case '!=':
        return (v1 != v2) ? options.fn(this) : options.inverse(this);
      case '!==':
        return (v1 !== v2) ? options.fn(this) : options.inverse(this);
      case '<':
        return (v1 < v2) ? options.fn(this) : options.inverse(this);
      case '<=':
        return (v1 <= v2) ? options.fn(this) : options.inverse(this);
      case '>':
        return (v1 > v2) ? options.fn(this) : options.inverse(this);
      case '>=':
        return (v1 >= v2) ? options.fn(this) : options.inverse(this);
      case '&&':
        return (v1 && v2) ? options.fn(this) : options.inverse(this);
      case '||':
        return (v1 || v2) ? options.fn(this) : options.inverse(this);
      default:
        return options.inverse(this);
    }
  });

  // جمع قيمتين
  Handlebars.registerHelper('add', function(v1, v2) {
    return Number(v1) + Number(v2);
  });

  // طرح قيمتين
  Handlebars.registerHelper('subtract', function(v1, v2) {
    return Number(v1) - Number(v2);
  });

  // ضرب قيمتين
  Handlebars.registerHelper('multiply', function(v1, v2) {
    return Number(v1) * Number(v2);
  });

  // قسمة قيمتين
  Handlebars.registerHelper('divide', function(v1, v2) {
    if (v2 === 0) return 0;
    return Number(v1) / Number(v2);
  });
  
  // تحويل النص إلى رقم
  Handlebars.registerHelper('toNumber', function(value) {
    if (value === undefined || value === null) return 0;
    const num = Number(value);
    return isNaN(num) ? 0 : num;
  });
  
  // تحويل النص إلى منطقي (boolean)
  Handlebars.registerHelper('toBoolean', function(value) {
    if (value === undefined || value === null) return false;
    if (typeof value === 'boolean') return value;
    if (typeof value === 'string') {
      const lowercaseValue = value.toLowerCase();
      return lowercaseValue === 'true' || lowercaseValue === 'yes' || lowercaseValue === '1';
    }
    return Boolean(value);
  });
  
  // التحقق من وجود قيمة
  Handlebars.registerHelper('isNull', function(value) {
    return value === undefined || value === null || value === '';
  });
  
  // التحقق من نوع القيمة
  Handlebars.registerHelper('typeOf', function(value, type) {
    if (type === 'array') return Array.isArray(value);
    return typeof value === type;
  });
};

// تجميع قالب Handlebars
export const compileTemplate = (templateString: string): Handlebars.TemplateDelegate => {
  try {
    return Handlebars.compile(templateString);
  } catch (error) {
    console.error('خطأ في تجميع قالب Handlebars:', error);
    // إرجاع قالب بسيط في حالة الخطأ
    return Handlebars.compile('{{.}}');
  }
};

// تطبيق قالب Handlebars على بيانات
export const applyTemplate = (template: Handlebars.TemplateDelegate, data: any): string => {
  try {
    return template(data);
  } catch (error) {
    console.error('خطأ في تطبيق قالب Handlebars:', error);
    return 'خطأ في تطبيق القالب';
  }
};

// تحويل بيانات الصف إلى كائن مناسب لـ Handlebars
export const prepareDataForTemplate = (rowData: Record<string, string | number>): Record<string, any> => {
  // إنشاء كائن بيانات أساسي
  const data: Record<string, any> = { ...rowData };
  
  // إضافة كائنات مساعدة
  data.row = rowData;
  
  // إضافة تاريخ التوليد
  data.generatedAt = new Date();
  
  return data;
};

// تحليل قالب من نص عنصر
export const parseTemplateFromText = (text: string, rowData: Record<string, string | number>): string => {
  try {
    // تجميع القالب
    const template = compileTemplate(text);
    
    // تحضير البيانات
    const data = prepareDataForTemplate(rowData);
    
    // تطبيق القالب
    return applyTemplate(template, data);
  } catch (error) {
    console.error('خطأ في تحليل القالب من النص:', error);
    return text;
  }
};

// تحليل قالب من ربط بيانات
export const parseTemplateFromBinding = (binding: DataBinding, rowData: Record<string, string | number>): string => {
  try {
    // إذا كان الربط يستخدم قالبًا
    if (binding.useTemplate && binding.template) {
      // تجميع القالب
      const template = compileTemplate(binding.template);
      
      // تحضير البيانات
      const data = prepareDataForTemplate(rowData);
      
      // تطبيق القالب
      return applyTemplate(template, data);
    }
    
    // إذا لم يكن يستخدم قالبًا، نرجع قيمة العمود مباشرة
    const columnName = binding.column;
    const value = rowData[columnName];
    
    if (value === undefined) {
      return '';
    }
    
    return String(value);
  } catch (error) {
    console.error('خطأ في تحليل القالب من ربط البيانات:', error);
    return '';
  }
};

// التحقق من صحة قالب Handlebars
export const validateHandlebarsTemplate = (templateString: string): { isValid: boolean; error?: string } => {
  try {
    Handlebars.compile(templateString);
    return { isValid: true };
  } catch (error) {
    return { 
      isValid: false, 
      error: error instanceof Error ? error.message : 'خطأ غير معروف في القالب'
    };
  }
};

// تحليل قالب مع بيانات اختبار
export const testHandlebarsTemplate = (templateString: string, testData: Record<string, any> = {}): { result: string; error?: string } => {
  try {
    const template = compileTemplate(templateString);
    
    // إضافة بيانات اختبار افتراضية إذا لم تكن موجودة
    const defaultTestData = {
      الاسم: 'أحمد محمد',
      البريد_الإلكتروني: 'ahmed@example.com',
      رقم_الهاتف: '+966501234567',
      المسمى_الوظيفي: 'مدير تنفيذي',
      الشركة: 'شركة التقنية المتطورة',
      العنوان: 'الرياض، المملكة العربية السعودية',
      تاريخ_الإصدار: '2025-05-15',
      رقم_التسلسل: '12345',
      السعر: 1500,
      الضريبة: 225,
      العمر: 35,
      ...testData
    };
    
    // تحضير البيانات
    const data = prepareDataForTemplate(defaultTestData);
    
    // تطبيق القالب
    const result = applyTemplate(template, data);
    
    return { result };
  } catch (error) {
    return { 
      result: 'خطأ في تطبيق القالب', 
      error: error instanceof Error ? error.message : 'خطأ غير معروف في تطبيق القالب'
    };
  }
};