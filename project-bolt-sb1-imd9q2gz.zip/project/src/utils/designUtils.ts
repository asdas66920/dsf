import { CanvasElement, Design, TextElement, ImageElement, ShapeElement, ExcelData, GeneratedDesign, DataBinding } from '../types';
import { formatCellValue } from './excelUtils';
import { v4 as uuidv4 } from 'uuid';
import { saveAs } from 'file-saver';
import JSZip from 'jszip';
import { parseTemplateFromText, parseTemplateFromBinding, registerHandlebarsHelpers } from './templateUtils';

// تسجيل مساعدات Handlebars
registerHandlebarsHelpers();

export const createNewDesign = (width: number, height: number, name: string): Design => {
  return {
    id: uuidv4(),
    name,
    width,
    height,
    elements: [],
    background: '#ffffff'
  };
};

export const createTextElement = (x: number, y: number): TextElement => {
  return {
    id: uuidv4(),
    type: 'text',
    x,
    y,
    width: 200,
    height: 50,
    rotation: 0,
    scaleX: 1,
    scaleY: 1,
    opacity: 1,
    visible: true,
    name: 'نص جديد',
    zIndex: Date.now(),
    text: 'أدخل النص هنا',
    fontSize: 16,
    fontFamily: 'Tajawal',
    fill: '#000000',
    align: 'right',
    verticalAlign: 'middle',
    padding: 5,
    lineHeight: 1.2,
    fontStyle: 'normal',
    textDecoration: ''
  };
};

export const createImageElement = (x: number, y: number, src: string, width: number, height: number): ImageElement => {
  return {
    id: uuidv4(),
    type: 'image',
    x,
    y,
    width,
    height,
    rotation: 0,
    scaleX: 1,
    scaleY: 1,
    opacity: 1,
    visible: true,
    name: 'صورة جديدة',
    zIndex: Date.now(),
    src
  };
};

export const createShapeElement = (x: number, y: number, shapeType: 'rect' | 'circle' | 'ellipse' | 'line'): ShapeElement => {
  return {
    id: uuidv4(),
    type: 'shape',
    x,
    y,
    width: 100,
    height: 100,
    rotation: 0,
    scaleX: 1,
    scaleY: 1,
    opacity: 1,
    visible: true,
    name: 'شكل جديد',
    zIndex: Date.now(),
    shapeType,
    fill: '#e5e7eb',
    stroke: '#000000',
    strokeWidth: 1,
    strokeStyle: 'solid',
    cornerRadius: 0,
    shadow: {
      enabled: false,
      color: 'rgba(0,0,0,0.5)',
      blur: 10,
      offsetX: 5,
      offsetY: 5,
      opacity: 0.5
    },
    reflection: {
      enabled: false,
      opacity: 0.5,
      distance: 20
    },
    gradient: {
      enabled: false,
      type: 'linear',
      angle: 90,
      startColor: '#ffffff',
      endColor: '#e5e7eb'
    },
    stretch: {
      enabled: false,
      factor: 1.2,
      direction: 'horizontal'
    }
  };
};

export const duplicateElement = (element: CanvasElement): CanvasElement => {
  return {
    ...element,
    id: uuidv4(),
    name: `${element.name} (نسخة)`,
    x: element.x + 20,
    y: element.y + 20,
    zIndex: Date.now()
  };
};

export const applyDataToElement = (element: CanvasElement, rowData: Record<string, string | number>): CanvasElement => {
  if (!element.dataBinding) {
    return element;
  }
  
  // إذا كان الربط عبارة عن مصفوفة من الروابط
  if (Array.isArray(element.dataBinding)) {
    // نسخة من العنصر للتعديل
    let updatedElement = { ...element };
    
    // إذا كان العنصر من نوع نص، نقوم بتطبيق كل ربط بيانات
    if (element.type === 'text') {
      let textContent = (element as TextElement).text;
      
      // تطبيق كل ربط بيانات
      element.dataBinding.forEach(binding => {
        if (!binding.column) return;
        
        // إذا كان الربط يستخدم قالب Handlebars
        if (binding.useTemplate && binding.template) {
          const renderedText = parseTemplateFromBinding(binding, rowData);
          
          // استبدال النص بالقيمة المنسقة
          // استخدام نمط {{column_name}} للاستبدال
          const placeholder = `{{${binding.column}}}`;
          
          // تحقق مما إذا كان النص يحتوي على النمط
          if (textContent.includes(placeholder)) {
            textContent = textContent.replace(new RegExp(placeholder, 'g'), renderedText);
          } else if (binding === element.dataBinding[0]) {
            // إذا كان هذا هو الربط الأول ولم يتم العثور على النمط، استبدل النص بالكامل
            textContent = renderedText;
          }
        } else {
          // استخدام الطريقة التقليدية
          const columnName = binding.column;
          const value = rowData[columnName];
          
          if (value === undefined) return;
          
          const formattedValue = formatCellValue(value, binding.format);
          
          // استبدال النص بالقيمة المنسقة
          // استخدام نمط {{column_name}} للاستبدال
          const placeholder = `{{${columnName}}}`;
          
          // تحقق مما إذا كان النص يحتوي على النمط
          if (textContent.includes(placeholder)) {
            textContent = textContent.replace(new RegExp(placeholder, 'g'), formattedValue);
          } else if (binding === element.dataBinding[0]) {
            // إذا كان هذا هو الربط الأول ولم يتم العثور على النمط، استبدل النص بالكامل
            textContent = formattedValue;
          }
        }
      });
      
      // تحقق مما إذا كان النص نفسه يحتوي على قالب Handlebars
      if (textContent.includes('{{') && textContent.includes('}}')) {
        textContent = parseTemplateFromText(textContent, rowData);
      }
      
      // تحديث نص العنصر
      updatedElement = {
        ...updatedElement,
        text: textContent
      } as TextElement;
      
      // إذا كان هناك موضع محدد لأي من الروابط، نقوم بتحديث موضع العنصر
      // نستخدم الموضع من أول ربط له موضع محدد
      const bindingWithPosition = element.dataBinding.find(binding => binding.position);
      if (bindingWithPosition && bindingWithPosition.position) {
        updatedElement = {
          ...updatedElement,
          x: bindingWithPosition.position.x,
          y: bindingWithPosition.position.y
        };
      }
      
      // تطبيق خصائص التنسيق من أول ربط له خصائص تنسيق
      const bindingWithFormatting = element.dataBinding.find(binding => 
        binding.textColor || binding.fontSize || binding.fontFamily || 
        binding.fontStyle || binding.textDecoration || binding.textAlign || 
        binding.verticalAlign
      );
      
      if (bindingWithFormatting) {
        const textElement = updatedElement as TextElement;
        if (bindingWithFormatting.textColor) textElement.fill = bindingWithFormatting.textColor;
        if (bindingWithFormatting.fontSize) textElement.fontSize = bindingWithFormatting.fontSize;
        if (bindingWithFormatting.fontFamily) textElement.fontFamily = bindingWithFormatting.fontFamily;
        if (bindingWithFormatting.fontStyle) textElement.fontStyle = bindingWithFormatting.fontStyle;
        if (bindingWithFormatting.textDecoration) textElement.textDecoration = bindingWithFormatting.textDecoration;
        if (bindingWithFormatting.textAlign) textElement.align = bindingWithFormatting.textAlign;
        if (bindingWithFormatting.verticalAlign) textElement.verticalAlign = bindingWithFormatting.verticalAlign;
        updatedElement = textElement;
      }
    }
    // إذا كان العنصر من نوع صورة، نستخدم أول ربط يحتوي على رابط صورة
    else if (element.type === 'image') {
      for (const binding of element.dataBinding) {
        if (!binding.column) continue;
        
        const columnName = binding.column;
        const value = rowData[columnName];
        
        if (value === undefined) continue;
        
        // إذا كانت القيمة عبارة عن رابط صورة
        if (typeof value === 'string' && (value.startsWith('http') || value.startsWith('data:'))) {
          updatedElement = {
            ...updatedElement,
            src: value
          } as ImageElement;
          
          // إذا كان هناك موضع محدد، نقوم بتحديث موضع العنصر
          if (binding.position) {
            updatedElement = {
              ...updatedElement,
              x: binding.position.x,
              y: binding.position.y
            };
          }
          
          break; // نستخدم أول رابط صورة صالح
        }
      }
    }
    
    return updatedElement;
  }
  // إذا كان الربط عبارة عن ربط واحد (للتوافق مع الإصدارات السابقة)
  else {
    const binding = element.dataBinding;
    const columnName = binding.column;
    const value = rowData[columnName];
    
    if (value === undefined) {
      return element;
    }
    
    // إذا كان الربط يستخدم قالب Handlebars
    if (binding.useTemplate && binding.template) {
      if (element.type === 'text') {
        // تطبيق القالب على البيانات
        const renderedText = parseTemplateFromBinding(binding, rowData);
        
        // إذا كان النص يحتوي على نمط {{column_name}}، نقوم باستبداله
        let updatedText = (element as TextElement).text;
        const placeholder = `{{${columnName}}}`;
        
        if (updatedText.includes(placeholder)) {
          updatedText = updatedText.replace(new RegExp(placeholder, 'g'), renderedText);
        } else {
          // إذا لم يكن هناك نمط، نستبدل النص بالكامل
          updatedText = renderedText;
        }
        
        // تحقق مما إذا كان النص نفسه يحتوي على قالب Handlebars
        if (updatedText.includes('{{') && updatedText.includes('}}')) {
          updatedText = parseTemplateFromText(updatedText, rowData);
        }
        
        let updatedElement: TextElement = {
          ...element as TextElement,
          text: updatedText
        };
        
        // إذا كان هناك موضع محدد، نقوم بتحديث موضع العنصر
        if (binding.position) {
          updatedElement = {
            ...updatedElement,
            x: binding.position.x,
            y: binding.position.y
          };
        }
        
        // تطبيق خصائص التنسيق إذا كانت موجودة
        if (binding.textColor) updatedElement.fill = binding.textColor;
        if (binding.fontSize) updatedElement.fontSize = binding.fontSize;
        if (binding.fontFamily) updatedElement.fontFamily = binding.fontFamily;
        if (binding.fontStyle) updatedElement.fontStyle = binding.fontStyle;
        if (binding.textDecoration) updatedElement.textDecoration = binding.textDecoration;
        if (binding.textAlign) updatedElement.align = binding.textAlign;
        if (binding.verticalAlign) updatedElement.verticalAlign = binding.verticalAlign;
        
        return updatedElement;
      }
    } else {
      // استخدام الطريقة التقليدية
      const formattedValue = formatCellValue(value, binding.format);
      
      if (element.type === 'text') {
        // إذا كان النص يحتوي على نمط {{column_name}}، نقوم باستبداله
        let updatedText = (element as TextElement).text;
        const placeholder = `{{${columnName}}}`;
        
        if (updatedText.includes(placeholder)) {
          updatedText = updatedText.replace(new RegExp(placeholder, 'g'), formattedValue);
        } else {
          // إذا لم يكن هناك نمط، نستبدل النص بالكامل
          updatedText = formattedValue;
        }
        
        // تحقق مما إذا كان النص نفسه يحتوي على قالب Handlebars
        if (updatedText.includes('{{') && updatedText.includes('}}')) {
          updatedText = parseTemplateFromText(updatedText, rowData);
        }
        
        let updatedElement: TextElement = {
          ...element as TextElement,
          text: updatedText
        };
        
        // إذا كان هناك موضع محدد، نقوم بتحديث موضع العنصر
        if (binding.position) {
          updatedElement = {
            ...updatedElement,
            x: binding.position.x,
            y: binding.position.y
          };
        }
        
        // تطبيق خصائص التنسيق إذا كانت موجودة
        if (binding.textColor) updatedElement.fill = binding.textColor;
        if (binding.fontSize) updatedElement.fontSize = binding.fontSize;
        if (binding.fontFamily) updatedElement.fontFamily = binding.fontFamily;
        if (binding.fontStyle) updatedElement.fontStyle = binding.fontStyle;
        if (binding.textDecoration) updatedElement.textDecoration = binding.textDecoration;
        if (binding.textAlign) updatedElement.align = binding.textAlign;
        if (binding.verticalAlign) updatedElement.verticalAlign = binding.verticalAlign;
        
        return updatedElement;
      }
      
      // للصور، نتحقق إذا كانت القيمة عبارة عن رابط صورة
      if (element.type === 'image' && typeof value === 'string' && (value.startsWith('http') || value.startsWith('data:'))) {
        let updatedElement = {
          ...element,
          src: value
        };
        
        // إذا كان هناك موضع محدد، نقوم بتحديث موضع العنصر
        if (binding.position) {
          updatedElement = {
            ...updatedElement,
            x: binding.position.x,
            y: binding.position.y
          };
        }
        
        return updatedElement;
      }
    }
  }
  
  return element;
};

// تحويل التصميم إلى صورة باستخدام Konva
export const designToImage = (design: Design, format: 'png' | 'jpeg', quality: number): Promise<string> => {
  return new Promise((resolve, reject) => {
    // إنشاء عنصر canvas مؤقت
    const canvas = document.createElement('canvas');
    canvas.width = design.width;
    canvas.height = design.height;
    const ctx = canvas.getContext('2d');
    
    if (!ctx) {
      reject(new Error('فشل إنشاء سياق الرسم'));
      return;
    }
    
    // رسم خلفية التصميم
    ctx.fillStyle = design.background;
    ctx.fillRect(0, 0, design.width, design.height);
    
    // تحميل جميع الصور أولاً
    const imagePromises: Promise<void>[] = [];
    const imageElements: {element: ImageElement, img: HTMLImageElement}[] = [];
    
    design.elements
      .filter(el => el.type === 'image' && el.visible)
      .forEach(el => {
        const imgElement = el as ImageElement;
        const img = new Image();
        img.crossOrigin = 'anonymous';
        
        const promise = new Promise<void>((resolve, reject) => {
          img.onload = () => {
            imageElements.push({ element: imgElement, img });
            resolve();
          };
          img.onerror = (e) => {
            console.error(`فشل تحميل الصورة: ${imgElement.src}`, e);
            // محاولة تحميل الصورة بطريقة بديلة إذا كانت من مصدر خارجي
            if (imgElement.src.startsWith('http') && !imgElement.src.startsWith(window.location.origin)) {
              // محاولة استخدام خدمة وسيطة لتجاوز مشاكل CORS
              const proxiedUrl = `https://cors-anywhere.herokuapp.com/${imgElement.src}`;
              const proxyImg = new Image();
              proxyImg.crossOrigin = 'anonymous';
              proxyImg.onload = () => {
                imageElements.push({ element: imgElement, img: proxyImg });
                resolve();
              };
              proxyImg.onerror = () => {
                console.warn(`فشل تحميل الصورة حتى مع استخدام الوسيط: ${imgElement.src}`);
                resolve(); // نستمر حتى مع فشل تحميل بعض الصور
              };
              proxyImg.src = proxiedUrl;
            } else {
              resolve(); // نستمر حتى مع فشل تحميل بعض الصور
            }
          };
        });
        
        img.src = imgElement.src;
        imagePromises.push(promise);
      });
    
    // بعد تحميل جميع الصور، نرسم العناصر
    Promise.all(imagePromises)
      .then(() => {
        // ترتيب العناصر حسب zIndex
        const sortedElements = [...design.elements].sort((a, b) => a.zIndex - b.zIndex);
        
        // رسم كل عنصر
        sortedElements.forEach(element => {
          if (!element.visible) return;
          
          // حفظ حالة السياق
          ctx.save();
          
          // تطبيق الشفافية
          ctx.globalAlpha = element.opacity;
          
          // تطبيق التحويلات (الموضع والدوران والتكبير)
          ctx.translate(element.x + element.width / 2, element.y + element.height / 2);
          ctx.rotate((element.rotation * Math.PI) / 180);
          ctx.scale(element.scaleX, element.scaleY);
          ctx.translate(-element.width / 2, -element.height / 2);
          
          // رسم العنصر حسب نوعه
          switch (element.type) {
            case 'text': {
              const textElement = element as TextElement;
              ctx.font = `${textElement.fontStyle} ${textElement.fontSize}px ${textElement.fontFamily}`;
              ctx.fillStyle = textElement.fill;
              ctx.textAlign = textElement.align === 'right' ? 'right' : textElement.align === 'center' ? 'center' : 'left';
              ctx.textBaseline = textElement.verticalAlign === 'top' ? 'top' : textElement.verticalAlign === 'middle' ? 'middle' : 'bottom';
              
              // تقسيم النص إلى أسطر
              const lines = textElement.text.split('\n');
              const lineHeight = textElement.fontSize * textElement.lineHeight;
              
              lines.forEach((line, index) => {
                const y = textElement.verticalAlign === 'top' 
                  ? index * lineHeight 
                  : textElement.verticalAlign === 'middle' 
                    ? (index - lines.length / 2 + 0.5) * lineHeight + element.height / 2 
                    : element.height - (lines.length - index) * lineHeight;
                
                const x = textElement.align === 'right' 
                  ? element.width - textElement.padding 
                  : textElement.align === 'center' 
                    ? element.width / 2 
                    : textElement.padding;
                
                ctx.fillText(line, x, y);
              });
              break;
            }
            case 'shape': {
              const shapeElement = element as ShapeElement;
              
              // تطبيق الظل إذا كان مفعلاً
              if (shapeElement.shadow && shapeElement.shadow.enabled) {
                ctx.shadowColor = shapeElement.shadow.color;
                ctx.shadowBlur = shapeElement.shadow.blur;
                ctx.shadowOffsetX = shapeElement.shadow.offsetX;
                ctx.shadowOffsetY = shapeElement.shadow.offsetY;
              }
              
              // تطبيق التدرج اللوني إذا كان مفعلاً
              let fillStyle: CanvasGradient | string = shapeElement.fill;
              
              if (shapeElement.gradient && shapeElement.gradient.enabled) {
                if (shapeElement.gradient.type === 'linear') {
                  const angleRad = (shapeElement.gradient.angle * Math.PI) / 180;
                  const startX = element.width / 2 - Math.cos(angleRad) * element.width / 2;
                  const startY = element.height / 2 - Math.sin(angleRad) * element.height / 2;
                  const endX = element.width / 2 + Math.cos(angleRad) * element.width / 2;
                  const endY = element.height / 2 + Math.sin(angleRad) * element.height / 2;
                  
                  const gradient = ctx.createLinearGradient(startX, startY, endX, endY);
                  gradient.addColorStop(0, shapeElement.gradient.startColor);
                  gradient.addColorStop(1, shapeElement.gradient.endColor);
                  
                  fillStyle = gradient;
                } else if (shapeElement.gradient.type === 'radial') {
                  const gradient = ctx.createRadialGradient(
                    element.width / 2, element.height / 2, 0,
                    element.width / 2, element.height / 2, Math.max(element.width, element.height) / 2
                  );
                  gradient.addColorStop(0, shapeElement.gradient.startColor);
                  gradient.addColorStop(1, shapeElement.gradient.endColor);
                  
                  fillStyle = gradient;
                }
              }
              
              ctx.fillStyle = fillStyle;
              ctx.strokeStyle = shapeElement.stroke;
              ctx.lineWidth = shapeElement.strokeWidth;
              
              // تطبيق نمط الحدود
              if (shapeElement.strokeStyle === 'dashed') {
                ctx.setLineDash([10, 5]);
              } else if (shapeElement.strokeStyle === 'dotted') {
                ctx.setLineDash([2, 2]);
              } else {
                ctx.setLineDash([]);
              }
              
              switch (shapeElement.shapeType) {
                case 'rect': {
                  // رسم مستطيل مع زوايا مدورة إذا كان مطلوباً
                  if (shapeElement.cornerRadius || 
                      shapeElement.cornerRadiusTopRight || 
                      shapeElement.cornerRadiusTopLeft || 
                      shapeElement.cornerRadiusBottomRight || 
                      shapeElement.cornerRadiusBottomLeft) {
                    
                    const topLeft = shapeElement.cornerRadiusTopLeft || shapeElement.cornerRadius || 0;
                    const topRight = shapeElement.cornerRadiusTopRight || shapeElement.cornerRadius || 0;
                    const bottomRight = shapeElement.cornerRadiusBottomRight || shapeElement.cornerRadius || 0;
                    const bottomLeft = shapeElement.cornerRadiusBottomLeft || shapeElement.cornerRadius || 0;
                    
                    ctx.beginPath();
                    ctx.moveTo(topLeft, 0);
                    ctx.lineTo(element.width - topRight, 0);
                    ctx.quadraticCurveTo(element.width, 0, element.width, topRight);
                    ctx.lineTo(element.width, element.height - bottomRight);
                    ctx.quadraticCurveTo(element.width, element.height, element.width - bottomRight, element.height);
                    ctx.lineTo(bottomLeft, element.height);
                    ctx.quadraticCurveTo(0, element.height, 0, element.height - bottomLeft);
                    ctx.lineTo(0, topLeft);
                    ctx.quadraticCurveTo(0, 0, topLeft, 0);
                    ctx.closePath();
                    
                    ctx.fill();
                    if (shapeElement.strokeWidth > 0) {
                      ctx.stroke();
                    }
                  } else {
                    ctx.beginPath();
                    ctx.rect(0, 0, element.width, element.height);
                    ctx.fill();
                    if (shapeElement.strokeWidth > 0) {
                      ctx.stroke();
                    }
                  }
                  break;
                }
                case 'circle': {
                  const radius = Math.min(element.width, element.height) / 2;
                  ctx.beginPath();
                  ctx.arc(element.width / 2, element.height / 2, radius, 0, Math.PI * 2);
                  ctx.fill();
                  if (shapeElement.strokeWidth > 0) {
                    ctx.stroke();
                  }
                  break;
                }
                case 'ellipse':
                  ctx.beginPath();
                  ctx.ellipse(
                    element.width / 2,
                    element.height / 2,
                    element.width / 2,
                    element.height / 2,
                    0,
                    0,
                    Math.PI * 2
                  );
                  ctx.fill();
                  if (shapeElement.strokeWidth > 0) {
                    ctx.stroke();
                  }
                  break;
                case 'line':
                  ctx.beginPath();
                  ctx.moveTo(0, 0);
                  ctx.lineTo(element.width, element.height);
                  if (shapeElement.strokeWidth > 0) {
                    ctx.stroke();
                  }
                  break;
              }
              
              // رسم الانعكاس إذا كان مفعلاً
              if (shapeElement.reflection && shapeElement.reflection.enabled) {
                ctx.save();
                
                // إعادة تعيين الظل لتجنب تطبيقه على الانعكاس
                ctx.shadowColor = 'transparent';
                ctx.shadowBlur = 0;
                ctx.shadowOffsetX = 0;
                ctx.shadowOffsetY = 0;
                
                // تطبيق الشفافية للانعكاس
                ctx.globalAlpha = element.opacity * shapeElement.reflection.opacity;
                
                // تطبيق التحويلات للانعكاس
                ctx.translate(0, element.height + shapeElement.reflection.distance);
                ctx.scale(1, -1);
                
                // رسم نفس الشكل كانعكاس
                switch (shapeElement.shapeType) {
                  case 'rect': {
                    if (shapeElement.cornerRadius || 
                        shapeElement.cornerRadiusTopRight || 
                        shapeElement.cornerRadiusTopLeft || 
                        shapeElement.cornerRadiusBottomRight || 
                        shapeElement.cornerRadiusBottomLeft) {
                      
                      const topLeft = shapeElement.cornerRadiusTopLeft || shapeElement.cornerRadius || 0;
                      const topRight = shapeElement.cornerRadiusTopRight || shapeElement.cornerRadius || 0;
                      const bottomRight = shapeElement.cornerRadiusBottomRight || shapeElement.cornerRadius || 0;
                      const bottomLeft = shapeElement.cornerRadiusBottomLeft || shapeElement.cornerRadius || 0;
                      
                      ctx.beginPath();
                      ctx.moveTo(topLeft, 0);
                      ctx.lineTo(element.width - topRight, 0);
                      ctx.quadraticCurveTo(element.width, 0, element.width, topRight);
                      ctx.lineTo(element.width, element.height - bottomRight);
                      ctx.quadraticCurveTo(element.width, element.height, element.width - bottomRight, element.height);
                      ctx.lineTo(bottomLeft, element.height);
                      ctx.quadraticCurveTo(0, element.height, 0, element.height - bottomLeft);
                      ctx.lineTo(0, topLeft);
                      ctx.quadraticCurveTo(0, 0, topLeft, 0);
                      ctx.closePath();
                      
                      ctx.fill();
                      if (shapeElement.strokeWidth > 0) {
                        ctx.stroke();
                      }
                    } else {
                      ctx.beginPath();
                      ctx.rect(0, 0, element.width, element.height);
                      ctx.fill();
                      if (shapeElement.strokeWidth > 0) {
                        ctx.stroke();
                      }
                    }
                    break;
                  }
                  case 'circle': {
                    const radius = Math.min(element.width, element.height) / 2;
                    ctx.beginPath();
                    ctx.arc(element.width / 2, element.height / 2, radius, 0, Math.PI * 2);
                    ctx.fill();
                    if (shapeElement.strokeWidth > 0) {
                      ctx.stroke();
                    }
                    break;
                  }
                  case 'ellipse':
                    ctx.beginPath();
                    ctx.ellipse(
                      element.width / 2,
                      element.height / 2,
                       element.width / 2,
                      element.height / 2,
                      0,
                      0,
                      Math.PI * 2
                    );
                    ctx.fill();
                    if (shapeElement.strokeWidth > 0) {
                      ctx.stroke();
                    }
                    break;
                  case 'line':
                    ctx.beginPath();
                    ctx.moveTo(0, 0);
                    ctx.lineTo(element.width, element.height);
                    if (shapeElement.strokeWidth > 0) {
                      ctx.stroke();
                    }
                    break;
                }
                
                ctx.restore();
              }
              
              break;
            }
            case 'image': {
              // البحث عن الصورة المحملة مسبقًا
              const imageData = imageElements.find(item => item.element.id === element.id);
              if (imageData) {
                try {
                  ctx.drawImage(imageData.img, 0, 0, element.width, element.height);
                } catch (error) {
                  console.error('خطأ في رسم الصورة:', error);
                  // رسم مستطيل بدلاً من الصورة في حالة الخطأ
                  ctx.fillStyle = '#f3f4f6';
                  ctx.fillRect(0, 0, element.width, element.height);
                  ctx.strokeStyle = '#d1d5db';
                  ctx.lineWidth = 1;
                  ctx.strokeRect(0, 0, element.width, element.height);
                  
                  // رسم علامة X
                  ctx.beginPath();
                  ctx.moveTo(0, 0);
                  ctx.lineTo(element.width, element.height);
                  ctx.moveTo(element.width, 0);
                  ctx.lineTo(0, element.height);
                  ctx.strokeStyle = '#9ca3af';
                  ctx.stroke();
                }
              } else {
                // رسم مستطيل بدلاً من الصورة إذا لم يتم تحميلها
                ctx.fillStyle = '#f3f4f6';
                ctx.fillRect(0, 0, element.width, element.height);
                ctx.strokeStyle = '#d1d5db';
                ctx.lineWidth = 1;
                ctx.strokeRect(0, 0, element.width, element.height);
                
                // رسم علامة X
                ctx.beginPath();
                ctx.moveTo(0, 0);
                ctx.lineTo(element.width, element.height);
                ctx.moveTo(element.width, 0);
                ctx.lineTo(0, element.height);
                ctx.strokeStyle = '#9ca3af';
                ctx.stroke();
              }
              break;
            }
          }
          
          // استعادة حالة السياق
          ctx.restore();
        });
        
        // تحويل الـ canvas إلى URL للصورة
        const mimeType = format === 'png' ? 'image/png' : 'image/jpeg';
        const dataUrl = canvas.toDataURL(mimeType, quality / 100);
        resolve(dataUrl);
      })
      .catch(error => {
        console.error('خطأ في تحويل التصميم إلى صورة:', error);
        reject(error);
      });
  });
};

export const generateDesignsFromData = async (
  design: Design, 
  excelData: ExcelData, 
  rowIndices: number[]
): Promise<GeneratedDesign[]> => {
  const generatedDesigns: GeneratedDesign[] = [];
  
  for (const rowIndex of rowIndices) {
    const rowData = excelData.rows[rowIndex];
    
    // إنشاء نسخة عميقة من التصميم
    const designCopy: Design = JSON.parse(JSON.stringify(design));
    
    // تطبيق البيانات على كل عنصر
    designCopy.elements = designCopy.elements.map(element => 
      applyDataToElement(element, rowData)
    );
    
    // تحويل التصميم إلى صورة
    try {
      const imageUrl = await designToImage(designCopy, 'png', 90);
      
      const generatedDesign: GeneratedDesign = {
        id: uuidv4(),
        preview: imageUrl,
        rowIndex,
        downloadUrl: imageUrl
      };
      
      generatedDesigns.push(generatedDesign);
    } catch (error) {
      console.error('خطأ في توليد التصميم:', error);
    }
  }
  
  return generatedDesigns;
};

// حفظ التصميم كملف JSON
export const saveDesignAsJson = (design: Design, filename: string) => {
  const designJson = JSON.stringify(design, null, 2);
  const blob = new Blob([designJson], { type: 'application/json' });
  saveAs(blob, `${filename}.json`);
};

// حفظ التصميم كقالب
export const saveDesignAsTemplate = (design: Design, filename: string) => {
  // في التطبيق الحقيقي، قد يكون هناك تنسيق خاص للقوالب
  // هنا نستخدم نفس تنسيق JSON مع إضافة بعض البيانات الوصفية
  const template = {
    ...design,
    isTemplate: true,
    createdAt: new Date().toISOString(),
    version: '1.0'
  };
  
  // حفظ القالب في localStorage
  const templates = JSON.parse(localStorage.getItem('designTemplates') || '[]');
  templates.push(template);
  localStorage.setItem('designTemplates', JSON.stringify(templates));
  
  // تنزيل القالب كملف
  const templateJson = JSON.stringify(template, null, 2);
  const blob = new Blob([templateJson], { type: 'application/json' });
  saveAs(blob, `${filename}.template.json`);
};

// تحميل القوالب المحفوظة
export const loadTemplates = (): Promise<Design[]> => {
  return new Promise((resolve) => {
    const templates = JSON.parse(localStorage.getItem('designTemplates') || '[]');
    resolve(templates);
  });
};

// حذف قالب محفوظ
export const deleteTemplate = (templateId: string): Promise<boolean> => {
  return new Promise((resolve) => {
    const templates = JSON.parse(localStorage.getItem('designTemplates') || '[]');
    const filteredTemplates = templates.filter((template: Design) => template.id !== templateId);
    localStorage.setItem('designTemplates', JSON.stringify(filteredTemplates));
    resolve(true);
  });
};

// تطبيق قالب
export const applyTemplate = (template: Design): Design => {
  // إنشاء نسخة من القالب مع معرف جديد
  return {
    ...template,
    id: uuidv4(),
    name: `${template.name} (نسخة)`,
    isTemplate: false
  };
};

// تصدير التصميم كصورة
export const exportDesignAsImage = async (design: Design, format: 'png' | 'jpeg', quality: number, filename: string) => {
  try {
    // تحويل التصميم إلى صورة
    const dataUrl = await designToImage(design, format, quality);
    
    // تنزيل الصورة
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `${filename}.${format}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    return true;
  } catch (error) {
    console.error('خطأ في تصدير التصميم:', error);
    return false;
  }
};

// تصدير التصميم كملف PDF
export const exportDesignAsPdf = async (design: Design, filename: string) => {
  try {
    // تحويل التصميم إلى صورة أولاً
    const imageUrl = await designToImage(design, 'png', 100);
    
    // إنشاء عنصر canvas مؤقت
    const canvas = document.createElement('canvas');
    canvas.width = design.width;
    canvas.height = design.height;
    const ctx = canvas.getContext('2d');
    
    if (!ctx) {
      throw new Error('فشل إنشاء سياق الرسم');
    }
    
    // تحميل الصورة على الـ canvas
    const img = new Image();
    img.src = imageUrl;
    
    await new Promise<void>((resolve, reject) => {
      img.onload = () => {
        ctx.drawImage(img, 0, 0);
        resolve();
      };
      img.onerror = () => reject(new Error('فشل تحميل الصورة'));
    });
    
    // تحويل الـ canvas إلى PDF باستخدام jsPDF
    // هنا نستخدم طريقة بسيطة لتصدير الصورة كـ PDF
    // في التطبيق الحقيقي، يمكن استخدام مكتبة مثل jsPDF
    
    // تنزيل الصورة كبديل مؤقت
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `${filename}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    return true;
  } catch (error) {
    console.error('خطأ في تصدير التصميم كـ PDF:', error);
    return false;
  }
};

// تنزيل جميع التصاميم المولدة كملف مضغوط
export const downloadAllGeneratedDesigns = async (designs: GeneratedDesign[], format: 'png' | 'jpeg', filename: string) => {
  try {
    const zip = new JSZip();
    
    // إضافة كل تصميم إلى الملف المضغوط
    for (let i = 0; i < designs.length; i++) {
      const design = designs[i];
      
      // تحويل Data URL إلى Blob
      const response = await fetch(design.downloadUrl);
      const blob = await response.blob();
      
      // إضافة الملف إلى الملف المضغوط
      zip.file(`${filename}_${i + 1}.${format}`, blob);
    }
    
    // إنشاء الملف المضغوط وتنزيله
    const content = await zip.generateAsync({ type: 'blob' });
    saveAs(content, `${filename}_all.zip`);
    
    return true;
  } catch (error) {
    console.error('خطأ في تنزيل التصاميم:', error);
    return false;
  }
};

// تنزيل تصميم واحد من التصاميم المولدة
export const downloadSingleGeneratedDesign = async (design: GeneratedDesign, format: 'png' | 'jpeg', filename: string) => {
  try {
    // تحويل Data URL إلى Blob
    const response = await fetch(design.downloadUrl);
    const blob = await response.blob();
    
    // تنزيل الملف
    saveAs(blob, `${filename}_${design.rowIndex + 1}.${format}`);
    
    return true;
  } catch (error) {
    console.error('خطأ في تنزيل التصميم:', error);
    return false;
  }
};