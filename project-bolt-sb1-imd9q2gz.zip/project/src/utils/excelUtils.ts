import * as XLSX from 'xlsx';
import { ExcelData } from '../types';

export const parseExcelFile = (file: File): Promise<ExcelData> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        
        const sheetNames = workbook.SheetNames;
        const activeSheet = sheetNames[0];
        const worksheet = workbook.Sheets[activeSheet];
        
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        const headers = jsonData.length > 0 ? Object.keys(jsonData[0]) : [];
        
        resolve({
          headers,
          rows: jsonData as Record<string, string | number>[],
          fileName: file.name,
          sheetNames,
          activeSheet
        });
      } catch (error) {
        console.error('خطأ في تحليل ملف Excel:', error);
        reject(error);
      }
    };
    
    reader.onerror = (error) => {
      console.error('خطأ في قراءة الملف:', error);
      reject(error);
    };
    
    reader.readAsArrayBuffer(file);
  });
};

export const changeActiveSheet = (workbook: XLSX.WorkBook, sheetName: string): ExcelData => {
  const worksheet = workbook.Sheets[sheetName];
  const jsonData = XLSX.utils.sheet_to_json(worksheet);
  const headers = jsonData.length > 0 ? Object.keys(jsonData[0]) : [];
  
  return {
    headers,
    rows: jsonData as Record<string, string | number>[],
    fileName: 'workbook.xlsx', // This would be replaced with the actual filename
    sheetNames: workbook.SheetNames,
    activeSheet: sheetName
  };
};

export const formatCellValue = (value: string | number, format?: string): string => {
  if (value === undefined || value === null) {
    return '';
  }
  
  if (!format) {
    return String(value);
  }
  
  try {
    // Handle different format types
    switch (format) {
      case 'date': {
        const date = new Date(value.toString());
        if (isNaN(date.getTime())) return String(value);
        return date.toLocaleDateString('ar-SA');
      }
      
      case 'currency': {
        const num = typeof value === 'string' ? parseFloat(value) : value;
        if (isNaN(num)) return String(value);
        return new Intl.NumberFormat('ar-SA', { 
          style: 'currency', 
          currency: 'SAR' 
        }).format(num);
      }
      
      case 'number': {
        const num = typeof value === 'string' ? parseFloat(value) : value;
        if (isNaN(num)) return String(value);
        return new Intl.NumberFormat('ar-SA').format(num);
      }
      
      case 'percentage': {
        const num = typeof value === 'string' ? parseFloat(value) : value;
        if (isNaN(num)) return String(value);
        return new Intl.NumberFormat('ar-SA', { 
          style: 'percent',
          minimumFractionDigits: 2
        }).format(num / 100);
      }
      
      default:
        return String(value);
    }
  } catch (error) {
    console.error('Error formatting cell value:', error);
    return String(value);
  }
};

// استخراج قيم فريدة من عمود معين
export const getUniqueColumnValues = (data: Record<string, string | number>[], columnName: string): (string | number)[] => {
  const values = data.map(row => row[columnName]).filter(value => value !== undefined);
  return [...new Set(values)];
};

// تصفية البيانات حسب قيمة عمود
export const filterDataByColumn = (data: Record<string, string | number>[], columnName: string, value: string | number): Record<string, string | number>[] => {
  return data.filter(row => row[columnName] === value);
};

// تحويل قيم العمود إلى تنسيق محدد
export const formatColumnValues = (data: Record<string, string | number>[], columnName: string, format: string): Record<string, string | number>[] => {
  return data.map(row => {
    if (row[columnName] !== undefined) {
      const formattedValue = formatCellValue(row[columnName], format);
      return { ...row, [columnName]: formattedValue };
    }
    return row;
  });
};

// التحقق من صحة بيانات Excel
export const validateExcelData = (data: ExcelData): { isValid: boolean; errors: string[] } => {
  const errors: string[] = [];
  
  // التحقق من وجود بيانات
  if (!data.rows || data.rows.length === 0) {
    errors.push('ملف Excel فارغ أو لا يحتوي على بيانات');
  }
  
  // التحقق من وجود أعمدة
  if (!data.headers || data.headers.length === 0) {
    errors.push('ملف Excel لا يحتوي على أعمدة');
  }
  
  // التحقق من تنسيق البيانات
  data.rows.forEach((row, index) => {
    // التحقق من وجود قيم فارغة في الأعمدة المهمة
    data.headers.forEach(header => {
      if (row[header] === undefined || row[header] === null || row[header] === '') {
        errors.push(`الصف ${index + 1}: قيمة فارغة في العمود "${header}"`);
      }
    });
  });
  
  return {
    isValid: errors.length === 0,
    errors
  };
};

// تحويل ملف Excel إلى CSV
export const convertExcelToCSV = (data: ExcelData): string => {
  const headers = data.headers.join(',');
  const rows = data.rows.map(row => {
    return data.headers.map(header => {
      const value = row[header];
      // تغليف القيم التي تحتوي على فواصل بعلامات اقتباس
      if (typeof value === 'string' && value.includes(',')) {
        return `"${value}"`;
      }
      return value !== undefined ? value : '';
    }).join(',');
  }).join('\n');
  
  return `${headers}\n${rows}`;
};

// تحويل ملف Excel إلى JSON
export const convertExcelToJSON = (data: ExcelData): string => {
  return JSON.stringify(data.rows, null, 2);
};