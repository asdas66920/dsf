import React from 'react';
import { DesignProvider } from './context/DesignContext';
import MainLayout from './components/layout/MainLayout';
import ErrorBoundary from './components/common/ErrorBoundary';

const App: React.FC = () => {
  return (
    <ErrorBoundary>
      <DesignProvider>
        <MainLayout />
      </DesignProvider>
    </ErrorBoundary>
  );
};

export default App;