import React from 'react';
import { CanvasElement } from '../types';
import { Layers, ChevronUp, ChevronDown, Eye, EyeOff, Trash2, Settings } from 'lucide-react';

interface LayersPanelProps {
  elements: CanvasElement[];
  selectedElement: CanvasElement | null;
  onSelectElement: (element: CanvasElement) => void;
  onUpdateElement: (element: CanvasElement) => void;
  onDeleteElement: (elementId: string) => void;
  onReorderElements: (elements: CanvasElement[]) => void;
}

const LayersPanel: React.FC<LayersPanelProps> = ({
  elements,
  selectedElement,
  onSelectElement,
  onUpdateElement,
  onDeleteElement,
  onReorderElements,
}) => {
  // ترتيب العناصر حسب zIndex بترتيب تنازلي (الطبقة العليا أولاً)
  const sortedElements = [...elements].sort((a, b) => b.zIndex - a.zIndex);

  const handleMoveUp = (element: CanvasElement) => {
    const index = sortedElements.findIndex((e) => e.id === element.id);
    if (index <= 0) return; // بالفعل في الأعلى
    
    const newElements = [...sortedElements];
    const currentZIndex = newElements[index].zIndex;
    const upperZIndex = newElements[index - 1].zIndex;
    
    newElements[index].zIndex = upperZIndex + 1;
    
    onReorderElements(newElements);
  };

  const handleMoveDown = (element: CanvasElement) => {
    const index = sortedElements.findIndex((e) => e.id === element.id);
    if (index >= sortedElements.length - 1) return; // بالفعل في الأسفل
    
    const newElements = [...sortedElements];
    const currentZIndex = newElements[index].zIndex;
    const lowerZIndex = newElements[index + 1].zIndex;
    
    newElements[index].zIndex = lowerZIndex - 1;
    
    onReorderElements(newElements);
  };

  const handleToggleVisibility = (element: CanvasElement) => {
    onUpdateElement({
      ...element,
      visible: !element.visible,
    });
  };

  const handleEditElement = (element: CanvasElement) => {
    onSelectElement(element);
  };

  return (
    <div className="h-full overflow-hidden flex flex-col">
      <div className="p-4 border-b flex items-center">
        <Layers className="h-5 w-5 ml-2" />
        <h3 className="text-lg font-semibold">الطبقات</h3>
      </div>
      
      <div className="overflow-y-auto flex-grow scrollbar-thin">
        {sortedElements.length === 0 ? (
          <div className="p-4 text-center text-gray-500">
            لا توجد طبقات
          </div>
        ) : (
          <ul>
            {sortedElements.map((element) => (
              <li
                key={element.id}
                className={`layer-item ${selectedElement?.id === element.id ? 'active bg-blue-50 border-r-4 border-blue-500' : ''}`}
                onClick={() => onSelectElement(element)}
              >
                <div className="flex-grow truncate">
                  <span className="font-medium">{element.name}</span>
                  <span className="text-xs text-gray-500 block">
                    {element.type === 'text' ? 'نص' : 
                     element.type === 'image' ? 'صورة' : 
                     element.type === 'shape' ? 
                      (element.shapeType === 'rect' ? 'مستطيل' : 
                       element.shapeType === 'circle' ? 'دائرة' : 
                       element.shapeType === 'ellipse' ? 'بيضاوي' : 'خط') : ''}
                  </span>
                </div>
                <div className="flex items-center space-x-1 space-x-reverse">
                  <button
                    className="btn btn-icon btn-secondary"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleEditElement(element);
                    }}
                    title="تعديل الخصائص"
                  >
                    <Settings className="h-4 w-4" />
                  </button>
                  <button
                    className="btn btn-icon btn-secondary"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleVisibility(element);
                    }}
                    title={element.visible ? 'إخفاء' : 'إظهار'}
                  >
                    {element.visible ? (
                      <Eye className="h-4 w-4" />
                    ) : (
                      <EyeOff className="h-4 w-4" />
                    )}
                  </button>
                  <button
                    className="btn btn-icon btn-secondary"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleMoveUp(element);
                    }}
                    title="نقل لأعلى"
                  >
                    <ChevronUp className="h-4 w-4" />
                  </button>
                  <button
                    className="btn btn-icon btn-secondary"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleMoveDown(element);
                    }}
                    title="نقل لأسفل"
                  >
                    <ChevronDown className="h-4 w-4" />
                  </button>
                  <button
                    className="btn btn-icon btn-danger"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteElement(element.id);
                    }}
                    title="حذف"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default LayersPanel;