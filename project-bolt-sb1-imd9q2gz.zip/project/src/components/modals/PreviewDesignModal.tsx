import React, { useState, useEffect } from 'react';
import { Design, ExcelData } from '../../types';
import { X, ArrowRight, ArrowLeft, Download, Maximize2, Minimize2, RefreshCw } from 'lucide-react';
import { designToImage } from '../../utils/designUtils';
import { LoadingSpinner } from '../../components';
import { applyDataToElement } from '../../utils/designUtils';

interface PreviewDesignModalProps {
  isOpen: boolean;
  onClose: () => void;
  design: Design;
  excelData: ExcelData;
  onGenerate?: () => void;
}

const PreviewDesignModal: React.FC<PreviewDesignModalProps> = ({
  isOpen,
  onClose,
  design,
  excelData,
  onGenerate
}) => {
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [currentRowIndex, setCurrentRowIndex] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    if (isOpen && excelData.rows.length > 0) {
      generatePreview();
    }
  }, [isOpen, currentRowIndex]);

  const generatePreview = async () => {
    if (!excelData.rows[currentRowIndex]) return;
    
    setIsLoading(true);
    
    try {
      // إنشاء نسخة من التصميم
      const designCopy: Design = JSON.parse(JSON.stringify(design));
      
      // تطبيق بيانات الصف الحالي على التصميم
      const rowData = excelData.rows[currentRowIndex];
      designCopy.elements = designCopy.elements.map(element => 
        applyDataToElement(element, rowData)
      );
      
      // تحويل التصميم إلى صورة
      const imageUrl = await designToImage(designCopy, 'png', 100);
      setPreviewImage(imageUrl);
    } catch (error) {
      console.error('خطأ في إنشاء المعاينة:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePrevRow = () => {
    if (currentRowIndex > 0) {
      setCurrentRowIndex(currentRowIndex - 1);
    }
  };

  const handleNextRow = () => {
    if (currentRowIndex < excelData.rows.length - 1) {
      setCurrentRowIndex(currentRowIndex + 1);
    }
  };

  const handleDownload = () => {
    if (!previewImage) return;
    
    // تنزيل الصورة
    const link = document.createElement('a');
    link.href = previewImage;
    link.download = `preview_row_${currentRowIndex + 1}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  if (!isOpen) return null;

  const modalClasses = isFullscreen 
    ? "fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4" 
    : "fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4";

  const contentClasses = isFullscreen
    ? "bg-white rounded-lg w-full h-full max-w-none max-h-none flex flex-col overflow-hidden"
    : "bg-white rounded-lg w-3/4 max-w-4xl max-h-[90vh] flex flex-col overflow-hidden";

  return (
    <div className={modalClasses}>
      <div className={contentClasses}>
        <div className="flex justify-between items-center p-4 border-b">
          <h3 className="text-xl font-bold">معاينة التصميم</h3>
          <div className="flex items-center space-x-2 space-x-reverse">
            <button
              className="btn btn-secondary btn-sm"
              onClick={toggleFullscreen}
              title={isFullscreen ? "إلغاء ملء الشاشة" : "ملء الشاشة"}
            >
              {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </button>
            <button
              className="btn btn-secondary btn-sm"
              onClick={onClose}
              title="إغلاق"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
        
        <div className="flex justify-between items-center p-4 bg-gray-50 border-b">
          <div className="flex items-center">
            <button
              className="btn btn-secondary btn-sm"
              onClick={handlePrevRow}
              disabled={currentRowIndex === 0}
            >
              <ArrowRight className="h-4 w-4" />
            </button>
            <span className="mx-2 text-sm">
              صف {currentRowIndex + 1} من {excelData.rows.length}
            </span>
            <button
              className="btn btn-secondary btn-sm"
              onClick={handleNextRow}
              disabled={currentRowIndex === excelData.rows.length - 1}
            >
              <ArrowLeft className="h-4 w-4" />
            </button>
          </div>
          
          <div className="flex items-center space-x-2 space-x-reverse">
            <button
              className="btn btn-secondary btn-sm"
              onClick={generatePreview}
              title="تحديث المعاينة"
            >
              <RefreshCw className="h-4 w-4" />
            </button>
            <button
              className="btn btn-secondary btn-sm"
              onClick={handleDownload}
              disabled={!previewImage}
              title="تنزيل المعاينة"
            >
              <Download className="h-4 w-4" />
            </button>
            {onGenerate && (
              <button
                className="btn btn-primary btn-sm"
                onClick={onGenerate}
              >
                توليد التصاميم
              </button>
            )}
          </div>
        </div>
        
        <div className="flex-grow overflow-auto bg-gray-100 p-4 flex items-center justify-center">
          {isLoading ? (
            <div className="text-center">
              <LoadingSpinner size="lg" color="blue" />
              <p className="mt-4 text-gray-500">جاري إنشاء المعاينة...</p>
            </div>
          ) : previewImage ? (
            <div className="relative">
              <img 
                src={previewImage} 
                alt="معاينة التصميم" 
                className="max-w-full max-h-full object-contain"
                style={{ transform: `scale(${scale})` }}
              />
              <div className="absolute bottom-4 left-4 bg-white rounded-lg shadow-md p-2 flex items-center">
                <button
                  className="btn btn-secondary btn-sm"
                  onClick={() => setScale(Math.max(0.1, scale - 0.1))}
                  title="تصغير"
                >
                  -
                </button>
                <span className="mx-2 text-sm">{Math.round(scale * 100)}%</span>
                <button
                  className="btn btn-secondary btn-sm"
                  onClick={() => setScale(Math.min(2, scale + 0.1))}
                  title="تكبير"
                >
                  +
                </button>
                <button
                  className="btn btn-secondary btn-sm mr-2"
                  onClick={() => setScale(1)}
                  title="إعادة ضبط"
                >
                  <RefreshCw className="h-3 w-3" />
                </button>
              </div>
            </div>
          ) : (
            <div className="text-center">
              <p className="text-gray-500">لا توجد معاينة متاحة</p>
            </div>
          )}
        </div>
        
        {excelData.rows[currentRowIndex] && (
          <div className="p-4 border-t bg-gray-50">
            <h4 className="text-sm font-medium mb-2">بيانات الصف {currentRowIndex + 1}:</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
              {excelData.headers.slice(0, 8).map(header => (
                <div key={header} className="overflow-hidden">
                  <span className="font-medium">{header}: </span>
                  <span className="text-gray-600">{String(excelData.rows[currentRowIndex][header] || '')}</span>
                </div>
              ))}
              {excelData.headers.length > 8 && (
                <div className="text-blue-500">
                  +{excelData.headers.length - 8} حقول أخرى
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PreviewDesignModal;