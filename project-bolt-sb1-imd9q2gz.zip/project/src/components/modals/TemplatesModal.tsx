import React, { useState, useEffect } from 'react';
import { Design } from '../../types';
import { loadTemplates, applyTemplate } from '../../utils/designUtils';
import { FileText, Check, AlertCircle, Search, Trash2 } from 'lucide-react';
import { useNotification } from '../../context';
import { LoadingSpinner } from '../../components';

interface TemplatesModalProps {
  onClose: () => void;
  onApplyTemplate: (template: Design) => void;
  onDeleteTemplate: (templateId: string) => void;
}

const TemplatesModal: React.FC<TemplatesModalProps> = ({
  onClose,
  onApplyTemplate,
  onDeleteTemplate
}) => {
  const [templates, setTemplates] = useState<Design[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  const { showNotification } = useNotification();

  useEffect(() => {
    // تحميل القوالب المحفوظة
    const loadSavedTemplates = async () => {
      setIsLoading(true);
      try {
        const savedTemplates = await loadTemplates();
        setTemplates(savedTemplates);
      } catch (error) {
        console.error('فشل تحميل القوالب:', error);
        showNotification('فشل تحميل القوالب', 'error');
      } finally {
        setIsLoading(false);
      }
    };

    loadSavedTemplates();
  }, []);

  const handleApplyTemplate = () => {
    if (!selectedTemplate) return;
    
    const template = templates.find(t => t.id === selectedTemplate);
    if (!template) return;
    
    onApplyTemplate(template);
    onClose();
  };

  const handleDeleteTemplate = (templateId: string) => {
    onDeleteTemplate(templateId);
    setTemplates(templates.filter(t => t.id !== templateId));
    showNotification('تم حذف القالب بنجاح', 'success');
  };

  const filteredTemplates = templates.filter(template => 
    template.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg w-3/4 max-w-4xl max-h-[80vh] flex flex-col">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">القوالب المحفوظة</h2>
          <div className="relative">
            <input
              type="text"
              className="text-input pr-8"
              placeholder="بحث في القوالب..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          </div>
        </div>
        
        <div className="overflow-y-auto flex-grow">
          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <LoadingSpinner size="lg" text="جاري تحميل القوالب..." />
            </div>
          ) : filteredTemplates.length === 0 ? (
            <div className="text-center py-8">
              <FileText className="h-12 w-12 mx-auto text-gray-300 mb-2" />
              <p className="text-gray-500">لا توجد قوالب محفوظة</p>
              {searchTerm && <p className="text-sm text-gray-400 mt-1">جرب البحث بكلمات أخرى</p>}
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-4">
              {filteredTemplates.map(template => (
                <div 
                  key={template.id}
                  className={`border rounded-lg overflow-hidden cursor-pointer transition-all ${
                    selectedTemplate === template.id ? 'border-blue-500 ring-2 ring-blue-200' : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedTemplate(template.id)}
                >
                  <div className="aspect-w-16 aspect-h-9 bg-gray-100 flex items-center justify-center">
                    {/* هنا يمكن إضافة معاينة للقالب في المستقبل */}
                    <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                      <FileText className="h-8 w-8 text-gray-400" />
                    </div>
                  </div>
                  <div className="p-3">
                    <div className="flex justify-between items-center">
                      <h3 className="font-medium truncate">{template.name}</h3>
                      <button
                        className="btn btn-icon btn-danger"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteTemplate(template.id);
                        }}
                        title="حذف القالب"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {template.width} × {template.height} | {template.elements.length} عناصر
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        <div className="flex justify-between mt-4 pt-4 border-t">
          <button
            className="btn btn-secondary"
            onClick={onClose}
          >
            إلغاء
          </button>
          <button
            className="btn btn-primary"
            onClick={handleApplyTemplate}
            disabled={!selectedTemplate}
          >
            <Check className="h-4 w-4 ml-1" />
            استخدام القالب
          </button>
        </div>
      </div>
    </div>
  );
};

export default TemplatesModal;