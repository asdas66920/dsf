import React from 'react';
import { X, Code, BookOpen, Info, Check } from 'lucide-react';

interface HandlebarsHelpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const HandlebarsHelpModal: React.FC<HandlebarsHelpModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg w-3/4 max-w-4xl max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 ml-3">
              <Code className="h-5 w-5" />
            </div>
            <h2 className="text-xl font-bold">دليل استخدام قوالب Handlebars</h2>
          </div>
          <button
            className="btn btn-secondary"
            onClick={onClose}
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <div className="flex items-start">
            <Info className="h-5 w-5 text-blue-500 ml-2 mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-blue-700 mb-1">ما هي قوالب Handlebars؟</h3>
              <p className="text-blue-600 text-sm">
                Handlebars هي مكتبة لإنشاء قوالب في JavaScript تتيح لك إنشاء محتوى ديناميكي باستخدام عناصر تحكم منطقية مثل الشروط والحلقات. يمكنك استخدامها لإنشاء تصاميم معقدة تعتمد على بيانات Excel.
              </p>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <h3 className="font-semibold text-lg mb-3 flex items-center">
            <BookOpen className="h-5 w-5 text-green-500 ml-2" />
            الأساسيات
          </h3>
          <div className="bg-white rounded-lg shadow-sm p-4 border border-gray-200">
            <h4 className="font-medium text-gray-700 mb-2">المتغيرات الأساسية</h4>
            <div className="bg-gray-50 p-3 rounded-md mb-3 font-mono text-sm">
              <p className="mb-2 text-gray-700">الوصول إلى قيمة:</p>
              <code className="bg-gray-100 px-2 py-1 rounded text-gray-800 block mb-2">{'{{row.الاسم}}'}</code>
              
              <p className="mb-2 text-gray-700">الوصول إلى قيمة مع تنسيق:</p>
              <code className="bg-gray-100 px-2 py-1 rounded text-gray-800 block">{'{{formatDate row.تاريخ_الميلاد "short"}}'}</code>
            </div>

            <h4 className="font-medium text-gray-700 mb-2">الشروط</h4>
            <div className="bg-gray-50 p-3 rounded-md mb-3 font-mono text-sm">
              <p className="mb-2 text-gray-700">شرط بسيط:</p>
              <code className="bg-gray-100 px-2 py-1 rounded text-gray-800 block mb-2">
                {'{{#if row.متاح}}متاح{{else}}غير متاح{{/if}}'}
              </code>
              
              <p className="mb-2 text-gray-700">شرط مع مقارنة:</p>
              <code className="bg-gray-100 px-2 py-1 rounded text-gray-800 block">
                {'{{#if (ifCond row.العمر ">" 18)}}بالغ{{else}}قاصر{{/if}}'}
              </code>
            </div>

            <h4 className="font-medium text-gray-700 mb-2">الحلقات</h4>
            <div className="bg-gray-50 p-3 rounded-md font-mono text-sm">
              <p className="mb-2 text-gray-700">التكرار على مصفوفة:</p>
              <code className="bg-gray-100 px-2 py-1 rounded text-gray-800 block">
                {'{{#each row.المنتجات}}\n  - {{this.الاسم}}: {{formatCurrency this.السعر}}\n{{/each}}'}
              </code>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <h3 className="font-semibold text-lg mb-3">الدوال المساعدة المتاحة</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-2 text-right">الدالة</th>
                  <th className="border border-gray-300 p-2 text-right">الوصف</th>
                  <th className="border border-gray-300 p-2 text-right">مثال</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-gray-300 p-2 font-mono">formatDate</td>
                  <td className="border border-gray-300 p-2">تنسيق التاريخ بأشكال مختلفة</td>
                  <td className="border border-gray-300 p-2 font-mono">{'{{formatDate row.التاريخ "long"}}'}</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2 font-mono">formatCurrency</td>
                  <td className="border border-gray-300 p-2">تنسيق الرقم كعملة</td>
                  <td className="border border-gray-300 p-2 font-mono">{'{{formatCurrency row.السعر "SAR"}}'}</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2 font-mono">formatNumber</td>
                  <td className="border border-gray-300 p-2">تنسيق الرقم مع تحديد عدد الأرقام العشرية</td>
                  <td className="border border-gray-300 p-2 font-mono">{'{{formatNumber row.القيمة 2}}'}</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2 font-mono">formatPercent</td>
                  <td className="border border-gray-300 p-2">تنسيق الرقم كنسبة مئوية</td>
                  <td className="border border-gray-300 p-2 font-mono">{'{{formatPercent row.النسبة}}'}</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2 font-mono">truncate</td>
                  <td className="border border-gray-300 p-2">اختصار النص إلى طول محدد</td>
                  <td className="border border-gray-300 p-2 font-mono">{'{{truncate row.الوصف 50}}'}</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2 font-mono">uppercase</td>
                  <td className="border border-gray-300 p-2">تحويل النص إلى حروف كبيرة</td>
                  <td className="border border-gray-300 p-2 font-mono">{'{{uppercase row.الاسم}}'}</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2 font-mono">lowercase</td>
                  <td className="border border-gray-300 p-2">تحويل النص إلى حروف صغيرة</td>
                  <td className="border border-gray-300 p-2 font-mono">{'{{lowercase row.الاسم}}'}</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2 font-mono">ifCond</td>
                  <td className="border border-gray-300 p-2">مقارنة قيمتين باستخدام عامل مقارنة</td>
                  <td className="border border-gray-300 p-2 font-mono">{'{{#if (ifCond row.العمر ">=" 18)}}...{{/if}}'}</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2 font-mono">add, subtract, multiply, divide</td>
                  <td className="border border-gray-300 p-2">عمليات حسابية أساسية</td>
                  <td className="border border-gray-300 p-2 font-mono">{'{{add row.السعر row.الضريبة}}'}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="mb-6">
          <h3 className="font-semibold text-lg mb-3">أمثلة متقدمة</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white rounded-lg shadow-sm p-4 border border-gray-200">
              <h4 className="font-medium text-gray-700 mb-2">بطاقة عضوية</h4>
              <div className="bg-gray-50 p-3 rounded-md font-mono text-sm">
                <code className="block text-gray-800 whitespace-pre-wrap">
                  {'رقم العضوية: {{row.رقم_العضوية}}\n\nالاسم: {{row.الاسم}}\n\nتاريخ الانضمام: {{formatDate row.تاريخ_الانضمام "long"}}\n\n{{#if (ifCond row.نوع_العضوية "==" "ذهبية")}}\n  عضوية ذهبية - خصم {{row.نسبة_الخصم}}%\n{{else}}\n  عضوية عادية\n{{/if}}'}
                </code>
              </div>
            </div>
            <div className="bg-white rounded-lg shadow-sm p-4 border border-gray-200">
              <h4 className="font-medium text-gray-700 mb-2">فاتورة</h4>
              <div className="bg-gray-50 p-3 rounded-md font-mono text-sm">
                <code className="block text-gray-800 whitespace-pre-wrap">
                  {'العميل: {{row.اسم_العميل}}\nرقم الفاتورة: {{row.رقم_الفاتورة}}\nالتاريخ: {{formatDate row.تاريخ_الفاتورة}}\n\nالإجمالي: {{formatCurrency row.المبلغ}}\nالضريبة ({{row.نسبة_الضريبة}}%): {{formatCurrency (multiply row.المبلغ (divide row.نسبة_الضريبة 100))}}\nالمجموع: {{formatCurrency (add row.المبلغ (multiply row.المبلغ (divide row.نسبة_الضريبة 100)))}}'}
                </code>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <h3 className="font-semibold text-lg mb-3 flex items-center">
            <Check className="h-5 w-5 text-green-500 ml-2" />
            نصائح وإرشادات
          </h3>
          <ul className="list-disc list-inside space-y-2 text-gray-700">
            <li>استخدم <code className="bg-gray-100 px-1 rounded">row.اسم_العمود</code> للوصول إلى قيم الأعمدة في ملف Excel.</li>
            <li>يمكنك دمج عدة دوال معًا، مثل: <code className="bg-gray-100 px-1 rounded">{'{{formatCurrency (add row.السعر row.الضريبة)}}'}</code></li>
            <li>استخدم الشروط المنطقية لعرض محتوى مختلف بناءً على قيم البيانات.</li>
            <li>تأكد من إغلاق جميع الأقواس والوسوم بشكل صحيح.</li>
            <li>يمكنك استخدام <code className="bg-gray-100 px-1 rounded">\n</code> لإضافة سطر جديد في النص.</li>
            <li>اختبر القوالب المعقدة على مجموعة صغيرة من البيانات قبل تطبيقها على مجموعة كبيرة.</li>
          </ul>
        </div>

        <div className="text-center">
          <button
            className="btn btn-primary"
            onClick={onClose}
          >
            فهمت
          </button>
        </div>
      </div>
    </div>
  );
};

export default HandlebarsHelpModal;