import React, { useState } from 'react';
import { Design } from '../../types';
import { Save, FileDown, Share2, Copy, Check, AlertCircle } from 'lucide-react';
import { useNotification } from '../../context';

interface SaveDesignModalProps {
  design: Design;
  onClose: () => void;
  onSave: (name: string, format: string) => void;
  onExport: (format: string) => void;
  onDuplicate: () => void;
}

const SaveDesignModal: React.FC<SaveDesignModalProps> = ({
  design,
  onClose,
  onSave,
  onExport,
  onDuplicate
}) => {
  const [designName, setDesignName] = useState(design.name);
  const [saveFormat, setSaveFormat] = useState('json');
  const [exportFormat, setExportFormat] = useState('png');
  
  const { showNotification } = useNotification();

  const handleSave = () => {
    if (!designName.trim()) {
      showNotification('يرجى إدخال اسم للتصميم', 'error');
      return;
    }
    
    onSave(designName, saveFormat);
    onClose();
  };

  const handleExport = () => {
    if (!designName.trim()) {
      showNotification('يرجى إدخال اسم للتصميم', 'error');
      return;
    }
    
    onExport(exportFormat);
    onClose();
  };

  const handleDuplicate = () => {
    onDuplicate();
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg w-1/2 max-w-xl">
        <h2 className="text-xl font-bold mb-4">حفظ التصميم</h2>
        
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            اسم التصميم
          </label>
          <input
            type="text"
            className="text-input w-full"
            value={designName}
            onChange={(e) => setDesignName(e.target.value)}
          />
        </div>
        
        <div className="grid grid-cols-1 gap-4 mb-6">
          <div className="border rounded-lg p-4">
            <div className="flex items-center mb-2">
              <Save className="h-5 w-5 ml-2 text-blue-500" />
              <h3 className="font-semibold">حفظ التصميم</h3>
            </div>
            <p className="text-sm text-gray-500 mb-3">
              حفظ التصميم الحالي للاستخدام لاحقاً
            </p>
            <div className="flex items-center mb-2">
              <label className="block text-sm font-medium text-gray-700 ml-2">
                تنسيق الحفظ:
              </label>
              <select
                className="select-input"
                value={saveFormat}
                onChange={(e) => setSaveFormat(e.target.value)}
              >
                <option value="json">JSON</option>
                <option value="template">قالب</option>
              </select>
            </div>
            <button
              className="btn btn-primary w-full"
              onClick={handleSave}
            >
              حفظ التصميم
            </button>
          </div>
          
          <div className="border rounded-lg p-4">
            <div className="flex items-center mb-2">
              <FileDown className="h-5 w-5 ml-2 text-green-500" />
              <h3 className="font-semibold">تصدير التصميم</h3>
            </div>
            <p className="text-sm text-gray-500 mb-3">
              تصدير التصميم كصورة أو ملف PDF
            </p>
            <div className="flex items-center mb-2">
              <label className="block text-sm font-medium text-gray-700 ml-2">
                تنسيق التصدير:
              </label>
              <select
                className="select-input"
                value={exportFormat}
                onChange={(e) => setExportFormat(e.target.value)}
              >
                <option value="png">PNG</option>
                <option value="jpeg">JPEG</option>
                <option value="pdf">PDF</option>
              </select>
            </div>
            <button
              className="btn btn-secondary w-full"
              onClick={handleExport}
            >
              تصدير التصميم
            </button>
          </div>
          
          <div className="border rounded-lg p-4">
            <div className="flex items-center mb-2">
              <Copy className="h-5 w-5 ml-2 text-purple-500" />
              <h3 className="font-semibold">نسخ التصميم</h3>
            </div>
            <p className="text-sm text-gray-500 mb-3">
              إنشاء نسخة جديدة من التصميم الحالي
            </p>
            <button
              className="btn btn-secondary w-full"
              onClick={handleDuplicate}
            >
              نسخ التصميم
            </button>
          </div>
        </div>
        
        <div className="flex justify-end">
          <button
            className="btn btn-secondary"
            onClick={onClose}
          >
            إلغاء
          </button>
        </div>
      </div>
    </div>
  );
};

export default SaveDesignModal;