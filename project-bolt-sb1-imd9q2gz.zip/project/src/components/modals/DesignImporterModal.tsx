import React from 'react';
import DesignImporter from '../DesignImporter';
import { useDesign } from '../../context/DesignContext';

const DesignImporterModal: React.FC = () => {
  const { showDesignImporter, setShowDesignImporter, handleDesignImported } = useDesign();

  if (!showDesignImporter) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg w-1/2 max-w-xl">
        <h2 className="text-xl font-bold mb-4">استيراد تصميم</h2>
        <DesignImporter onDesignImported={handleDesignImported} />
        <div className="mt-4 flex justify-end">
          <button
            className="btn btn-secondary"
            onClick={() => setShowDesignImporter(false)}
          >
            إلغاء
          </button>
        </div>
      </div>
    </div>
  );
};

export default DesignImporterModal;