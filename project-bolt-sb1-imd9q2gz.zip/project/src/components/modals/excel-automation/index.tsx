import React, { useState, useEffect, useRef } from 'react';
import { CanvasElement, Design, ExcelData } from '../../../types';
import { useNotification } from '../../../context';
import ModalHeader from './ModalHeader';
import TabNavigation from './TabNavigation';
import ElementSelector from './ElementSelector';
import ColumnSelector from './ColumnSelector';
import BindingPreview from './BindingPreview';
import ColumnSettings from './ColumnSettings';
import ModalFooter from './ModalFooter';
import HandlebarsHelpModal from '../HandlebarsHelpModal';

interface ExcelAutomationModalProps {
  isOpen: boolean;
  onClose: () => void;
  design: Design;
  excelData: ExcelData;
  onUpdateElement: (element: CanvasElement) => void;
}

const ExcelAutomationModal: React.FC<ExcelAutomationModalProps> = ({
  isOpen,
  onClose,
  design,
  excelData,
  onUpdateElement,
}) => {
  const [selectedElement, setSelectedElement] = useState<CanvasElement | null>(null);
  const [selectedColumns, setSelectedColumns] = useState<string[]>([]);
  const [activeColumnSettings, setActiveColumnSettings] = useState<string | null>(null);
  const [previewScale, setPreviewScale] = useState(0.5);
  const [columnSettings, setColumnSettings] = useState<Record<string, {
    x: number;
    y: number;
    width?: number;
    height?: number;
    rotation?: number;
    fontSize?: number;
    fontFamily?: string;
    textColor?: string;
    textAlign?: 'left' | 'center' | 'right';
    format?: string;
    useTemplate?: boolean;
    template?: string;
  }>>({});
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [activeTab, setActiveTab] = useState<'columns' | 'preview' | 'settings'>('columns');
  const [previewRowIndex, setPreviewRowIndex] = useState(0);
  const [showGrid, setShowGrid] = useState(true);
  const [showBindingLines, setShowBindingLines] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showElementSelector, setShowElementSelector] = useState(true);
  const [showHandlebarsHelp, setShowHandlebarsHelp] = useState(false);
  
  const { showNotification } = useNotification();
  const modalRef = useRef<HTMLDivElement>(null);
  const stageRef = useRef<any>(null);

  // إعادة تعيين الحالة عند تغيير العنصر المحدد
  useEffect(() => {
    if (selectedElement) {
      // استخراج الأعمدة المرتبطة بالعنصر المحدد
      const bindings = selectedElement.dataBinding 
        ? (Array.isArray(selectedElement.dataBinding) 
          ? selectedElement.dataBinding 
          : [selectedElement.dataBinding])
        : [];
      
      const columns = bindings.map(binding => binding.column).filter(Boolean) as string[];
      setSelectedColumns(columns);
      
      // إعداد إعدادات الأعمدة من الروابط الموجودة
      const settings: Record<string, any> = {};
      bindings.forEach(binding => {
        if (binding.column) {
          settings[binding.column] = {
            x: binding.position?.x || 0,
            y: binding.position?.y || 0,
            width: selectedElement.width,
            height: selectedElement.height,
            rotation: selectedElement.rotation,
            fontSize: binding.fontSize || (selectedElement.type === 'text' ? (selectedElement as any).fontSize : undefined),
            fontFamily: binding.fontFamily || (selectedElement.type === 'text' ? (selectedElement as any).fontFamily : undefined),
            textColor: binding.textColor || (selectedElement.type === 'text' ? (selectedElement as any).fill : undefined),
            textAlign: binding.textAlign || (selectedElement.type === 'text' ? (selectedElement as any).align : undefined),
            format: binding.format,
            useTemplate: binding.useTemplate || false,
            template: binding.template || ''
          };
        }
      });
      setColumnSettings(settings);
    } else {
      setSelectedColumns([]);
      setColumnSettings({});
      setActiveColumnSettings(null);
    }
  }, [selectedElement]);

  // تطبيق وضع ملء الشاشة
  useEffect(() => {
    const handleEscapeKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isFullscreen) {
        setIsFullscreen(false);
      }
    };

    document.addEventListener('keydown', handleEscapeKey);
    return () => {
      document.removeEventListener('keydown', handleEscapeKey);
    };
  }, [isFullscreen]);

  if (!isOpen) return null;

  const handleElementSelect = (element: CanvasElement) => {
    setSelectedElement(element);
    setActiveTab('columns');
  };

  // تحديد المواضع الافتراضية للأعمدة المرتبطة
  const getDefaultPositionForColumn = (columnIndex: number, elementWidth: number, elementHeight: number): { x: number, y: number } => {
    const padding = 20;
    
    switch (columnIndex) {
      case 0: // العمود الأول - جهة اليمين من أعلى
        return { x: padding, y: padding };
      case 1: // العمود الثاني - جهة اليمين من أسفل
        return { x: padding, y: elementHeight - padding };
      case 2: // العمود الثالث - وسط الطبقة
        return { x: elementWidth / 2, y: elementHeight / 2 };
      case 3: // العمود الرابع - جهة اليسار من أعلى
        return { x: elementWidth - padding, y: padding };
      case 4: // العمود الخامس - جهة اليسار من أسفل
        return { x: elementWidth - padding, y: elementHeight - padding };
      default: // للأعمدة الإضافية، نضعها في مواقع متباعدة
        return { 
          x: padding + ((columnIndex % 3) * (elementWidth - 2 * padding) / 2), 
          y: padding + (Math.floor(columnIndex / 3) % 3) * (elementHeight - 2 * padding) / 2 
        };
    }
  };

  const handleColumnSelect = (column: string) => {
    if (selectedColumns.includes(column)) {
      setSelectedColumns(selectedColumns.filter(col => col !== column));
      
      // إزالة إعدادات العمود
      const newSettings = { ...columnSettings };
      delete newSettings[column];
      setColumnSettings(newSettings);
      
      if (activeColumnSettings === column) {
        setActiveColumnSettings(null);
      }
    } else {
      const newSelectedColumns = [...selectedColumns, column];
      setSelectedColumns(newSelectedColumns);
      
      // تحديد الموضع الافتراضي بناءً على ترتيب العمود
      const columnIndex = newSelectedColumns.length - 1;
      const elementWidth = selectedElement?.width || 800;
      const elementHeight = selectedElement?.height || 600;
      const defaultPosition = getDefaultPositionForColumn(columnIndex, elementWidth, elementHeight);
      
      // إضافة إعدادات افتراضية للعمود
      setColumnSettings({
        ...columnSettings,
        [column]: {
          x: defaultPosition.x,
          y: defaultPosition.y,
          width: selectedElement?.width || 100,
          height: selectedElement?.height || 30,
          rotation: selectedElement?.rotation || 0,
          fontSize: 25, // حجم الخط الافتراضي 25
          fontFamily: selectedElement?.type === 'text' ? (selectedElement as any).fontFamily : 'Tajawal',
          textColor: '#00AA00', // اللون الأخضر الافتراضي
          textAlign: 'right',
          useTemplate: false,
          template: ''
        }
      });
      
      // تعيين العمود النشط
      setActiveColumnSettings(column);
      setActiveTab('settings');
    }
  };

  const handleColumnSettingChange = (column: string, property: string, value: any) => {
    setColumnSettings({
      ...columnSettings,
      [column]: {
        ...columnSettings[column],
        [property]: value
      }
    });
  };

  const handleSaveBindings = () => {
    if (!selectedElement) return;
    
    // إنشاء روابط البيانات من الإعدادات
    const bindings = selectedColumns.map(column => {
      const settings = columnSettings[column];
      
      const binding: any = {
        column,
        position: {
          x: settings.x,
          y: settings.y
        }
      };
      
      // إضافة خصائص التنسيق إذا كانت موجودة
      if (settings.fontSize) binding.fontSize = settings.fontSize;
      if (settings.fontFamily) binding.fontFamily = settings.fontFamily;
      if (settings.textColor) binding.textColor = settings.textColor;
      if (settings.textAlign) binding.textAlign = settings.textAlign;
      if (settings.format) binding.format = settings.format;
      
      // إضافة خصائص قالب Handlebars إذا كانت موجودة
      if (settings.useTemplate !== undefined) binding.useTemplate = settings.useTemplate;
      if (settings.template) binding.template = settings.template;
      
      return binding;
    });
    
    // تحديث العنصر
    const updatedElement = {
      ...selectedElement,
      dataBinding: bindings.length === 1 ? bindings[0] : bindings,
      // تأكد من أن العرض والارتفاع يتم تحديثهما بشكل صحيح
      width: selectedElement.width,
      height: selectedElement.height
    };
    
    onUpdateElement(updatedElement);
    showNotification('تم حفظ إعدادات الربط بنجاح', 'success');
    onClose();
  };

  const handleSaveColumnSettings = () => {
    if (!activeColumnSettings) return;
    showNotification(`تم حفظ إعدادات العمود ${activeColumnSettings} بنجاح`, 'success');
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  const handleNextPreviewRow = () => {
    if (previewRowIndex < excelData.rows.length - 1) {
      setPreviewRowIndex(previewRowIndex + 1);
    }
  };

  const handlePrevPreviewRow = () => {
    if (previewRowIndex > 0) {
      setPreviewRowIndex(previewRowIndex - 1);
    }
  };

  const filteredColumns = excelData.headers.filter(header => 
    header.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const modalClasses = isFullscreen 
    ? "fixed inset-0 bg-white z-50 flex flex-col" 
    : "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50";

  const contentClasses = isFullscreen
    ? "w-full h-full flex flex-col"
    : "bg-white p-6 rounded-lg w-[1000px] h-[800px] max-h-[90vh] overflow-hidden flex flex-col";

  return (
    <div className={modalClasses}>
      <div ref={modalRef} className={contentClasses}>
        <ModalHeader 
          toggleFullscreen={toggleFullscreen} 
          isFullscreen={isFullscreen} 
          onClose={onClose} 
        />
        
        <TabNavigation 
          activeTab={activeTab} 
          setActiveTab={setActiveTab} 
          hasActiveColumn={!!activeColumnSettings} 
        />
        
        <div className="flex-grow overflow-hidden flex">
          {activeTab === 'columns' && (
            <div className="w-full h-full flex">
              {/* القائمة الرئيسية */}
              <div className="w-1/3 border-l overflow-y-auto bg-gray-50">
                {showElementSelector && (
                  <ElementSelector 
                    design={design} 
                    selectedElement={selectedElement} 
                    onElementSelect={handleElementSelect} 
                    setShowElementSelector={setShowElementSelector} 
                  />
                )}
                
                {selectedElement && (
                  <ColumnSelector 
                    excelData={excelData}
                    selectedColumns={selectedColumns}
                    onColumnSelect={handleColumnSelect}
                    searchTerm={searchTerm}
                    setSearchTerm={setSearchTerm}
                    filteredColumns={filteredColumns}
                    activeColumnSettings={activeColumnSettings}
                    setActiveColumnSettings={setActiveColumnSettings}
                    setActiveTab={setActiveTab}
                  />
                )}
              </div>
              
              {/* منطقة المعاينة */}
              <div className="flex-grow p-4 overflow-y-auto">
                <BindingPreview 
                  selectedElement={selectedElement}
                  design={design}
                  excelData={excelData}
                  previewRowIndex={previewRowIndex}
                  handlePrevPreviewRow={handlePrevPreviewRow}
                  handleNextPreviewRow={handleNextPreviewRow}
                  previewScale={previewScale}
                  setPreviewScale={setPreviewScale}
                  showGrid={showGrid}
                  setShowGrid={setShowGrid}
                  showBindingLines={showBindingLines}
                  setShowBindingLines={setShowBindingLines}
                  stageRef={stageRef}
                  selectedColumns={selectedColumns}
                  columnSettings={columnSettings}
                  activeColumnSettings={activeColumnSettings}
                  setActiveColumnSettings={setActiveColumnSettings}
                  setActiveTab={setActiveTab}
                  handleColumnSettingChange={handleColumnSettingChange}
                />
              </div>
            </div>
          )}
          
          {activeTab === 'preview' && (
            <div className="w-full h-full">
              <BindingPreview 
                selectedElement={selectedElement}
                design={design}
                excelData={excelData}
                previewRowIndex={previewRowIndex}
                handlePrevPreviewRow={handlePrevPreviewRow}
                handleNextPreviewRow={handleNextPreviewRow}
                previewScale={previewScale}
                setPreviewScale={setPreviewScale}
                showGrid={showGrid}
                setShowGrid={setShowGrid}
                showBindingLines={showBindingLines}
                setShowBindingLines={setShowBindingLines}
                stageRef={stageRef}
                selectedColumns={selectedColumns}
                columnSettings={columnSettings}
                activeColumnSettings={activeColumnSettings}
                setActiveColumnSettings={setActiveColumnSettings}
                setActiveTab={setActiveTab}
                handleColumnSettingChange={handleColumnSettingChange}
              />
            </div>
          )}
          
          {activeTab === 'settings' && (
            <div className="w-full h-full p-4 overflow-y-auto">
              <ColumnSettings 
                activeColumnSettings={activeColumnSettings}
                columnSettings={columnSettings}
                handleColumnSettingChange={handleColumnSettingChange}
                handleSaveColumnSettings={handleSaveColumnSettings}
                setActiveTab={setActiveTab}
                excelData={excelData}
                previewRowIndex={previewRowIndex}
              />
            </div>
          )}
        </div>
        
        <ModalFooter 
          selectedColumns={selectedColumns}
          selectedElement={selectedElement}
          handleSaveBindings={handleSaveBindings}
          onClose={onClose}
        />
        
        <HandlebarsHelpModal isOpen={showHandlebarsHelp} onClose={() => setShowHandlebarsHelp(false)} />
      </div>
    </div>
  );
};

export default ExcelAutomationModal;