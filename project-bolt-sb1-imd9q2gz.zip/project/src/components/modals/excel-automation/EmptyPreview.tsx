import React from 'react';
import { Layers, Eye, Link, FileSpreadsheet, ArrowRight, Lightbulb } from 'lucide-react';

interface EmptyPreviewProps {
  setActiveTab: (tab: 'columns' | 'preview' | 'settings') => void;
}

const EmptyPreview: React.FC<EmptyPreviewProps> = ({ setActiveTab }) => {
  return (
    <div className="flex flex-col items-center justify-center h-full bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg p-8">
      <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white mb-4 shadow-lg">
        <Layers className="h-10 w-10" />
      </div>
      <p className="text-gray-800 text-xl font-bold mb-2">يرجى اختيار عنصر من القائمة</p>
      <p className="text-gray-600 text-sm text-center mb-6 max-w-md">
        اختر عنصراً من قائمة العناصر لبدء ربطه بأعمدة البيانات. يمكنك ربط النصوص والصور والأشكال بالبيانات من ملف Excel.
      </p>
      
      <div className="flex flex-col items-center bg-white p-6 rounded-lg shadow-md border border-gray-100 w-full max-w-md">
        <div className="flex items-center mb-4 w-full">
          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 ml-3 shadow-sm">
            <Layers className="h-5 w-5" />
          </div>
          <div>
            <span className="font-medium text-gray-800">اختر عنصراً من قائمة العناصر</span>
            <p className="text-xs text-gray-500 mt-1">حدد النص أو الصورة أو الشكل الذي تريد ربطه بالبيانات</p>
          </div>
        </div>
        <div className="flex items-center mb-4 w-full">
          <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-500 ml-3 shadow-sm">
            <FileSpreadsheet className="h-5 w-5" />
          </div>
          <div>
            <span className="font-medium text-gray-800">حدد الأعمدة التي تريد ربطها بالعنصر</span>
            <p className="text-xs text-gray-500 mt-1">اختر عمود أو أكثر من ملف Excel لربطه بالعنصر المحدد</p>
          </div>
        </div>
        <div className="flex items-center w-full">
          <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-500 ml-3 shadow-sm">
            <Link className="h-5 w-5" />
          </div>
          <div>
            <span className="font-medium text-gray-800">اضبط إعدادات كل عمود وموضعه</span>
            <p className="text-xs text-gray-500 mt-1">حدد موضع وتنسيق كل عمود على التصميم</p>
          </div>
        </div>
      </div>
      
      <div className="mt-8 bg-gradient-to-r from-amber-50 to-yellow-50 p-4 rounded-lg border border-amber-100 flex items-start max-w-md">
        <Lightbulb className="h-5 w-5 text-amber-500 mt-0.5 ml-3 flex-shrink-0" />
        <div>
          <p className="text-amber-800 font-medium mb-1">نصيحة</p>
          <p className="text-amber-700 text-sm">
            يمكنك ربط عدة أعمدة بنفس العنصر، وتحديد موضع كل عمود بشكل مستقل على التصميم. هذا مفيد لإنشاء تصاميم معقدة مثل البطاقات والشهادات.
          </p>
        </div>
      </div>
      
      <button
        className="btn btn-primary mt-6 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 border-0 shadow-md"
        onClick={() => setActiveTab('columns')}
      >
        <ArrowRight className="h-4 w-4 ml-2" />
        اختيار عنصر وبدء الربط
      </button>
    </div>
  );
};

export default EmptyPreview;