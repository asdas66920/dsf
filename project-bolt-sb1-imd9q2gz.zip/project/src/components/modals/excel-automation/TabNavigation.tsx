import React from 'react';
import { Columns, Eye, Settings } from 'lucide-react';

interface TabNavigationProps {
  activeTab: 'columns' | 'preview' | 'settings';
  setActiveTab: (tab: 'columns' | 'preview' | 'settings') => void;
  hasActiveColumn: boolean;
}

const TabNavigation: React.FC<TabNavigationProps> = ({ activeTab, setActiveTab, hasActiveColumn }) => {
  return (
    <div className="flex border-b mb-4 bg-gray-50 rounded-lg overflow-hidden">
      <button
        className={`flex-1 py-3 px-4 text-center rounded-t-lg flex items-center justify-center ${
          activeTab === 'columns' 
            ? 'bg-white text-blue-600 border-b-2 border-blue-500 shadow-sm' 
            : 'text-gray-600 hover:bg-gray-100'
        }`}
        onClick={() => setActiveTab('columns')}
      >
        <Columns className="h-5 w-5 ml-2" />
        الأعمدة والعناصر
      </button>
      <button
        className={`flex-1 py-3 px-4 text-center rounded-t-lg flex items-center justify-center ${
          activeTab === 'preview' 
            ? 'bg-white text-blue-600 border-b-2 border-blue-500 shadow-sm' 
            : 'text-gray-600 hover:bg-gray-100'
        }`}
        onClick={() => setActiveTab('preview')}
      >
        <Eye className="h-5 w-5 ml-2" />
        المعاينة
      </button>
      <button
        className={`flex-1 py-3 px-4 text-center rounded-t-lg flex items-center justify-center ${
          activeTab === 'settings' 
            ? 'bg-white text-blue-600 border-b-2 border-blue-500 shadow-sm' 
            : 'text-gray-600 hover:bg-gray-100'
        }`}
        onClick={() => setActiveTab('settings')}
        disabled={!hasActiveColumn}
      >
        <Settings className="h-5 w-5 ml-2" />
        خصائص العمود
      </button>
    </div>
  );
};

export default TabNavigation;