import React from 'react';
import { CanvasElement } from '../../../types';
import { Save } from 'lucide-react';

interface ModalFooterProps {
  selectedColumns: string[];
  selectedElement: CanvasElement | null;
  handleSaveBindings: () => void;
  onClose: () => void;
}

const ModalFooter: React.FC<ModalFooterProps> = ({
  selectedColumns,
  selectedElement,
  handleSaveBindings,
  onClose,
}) => {
  return (
    <div className="flex justify-between mt-4 pt-4 border-t">
      <button
        className="btn btn-secondary"
        onClick={onClose}
      >
        إلغاء
      </button>
      <div className="flex items-center">
        {selectedColumns.length > 0 && (
          <div className="ml-4 bg-blue-50 px-3 py-1 rounded-full flex items-center">
            <span className="text-sm text-blue-700 ml-1">الأعمدة المختارة:</span>
            <span className="font-bold text-blue-700">{selectedColumns.length}</span>
          </div>
        )}
        <button
          className="btn btn-primary"
          onClick={handleSaveBindings}
          disabled={!selectedElement || selectedColumns.length === 0}
        >
          <Save className="h-4 w-4 ml-2" />
          حفظ إعدادات الربط
        </button>
      </div>
    </div>
  );
};

export default ModalFooter;