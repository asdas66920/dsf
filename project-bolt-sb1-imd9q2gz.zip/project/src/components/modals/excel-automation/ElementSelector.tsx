import React from 'react';
import { CanvasElement, Design } from '../../../types';
import { Layers, ArrowRight, Type, Square, Image } from 'lucide-react';

interface ElementSelectorProps {
  design: Design;
  selectedElement: CanvasElement | null;
  onElementSelect: (element: CanvasElement) => void;
  setShowElementSelector: (show: boolean) => void;
}

const ElementSelector: React.FC<ElementSelectorProps> = ({
  design,
  selectedElement,
  onElementSelect,
  setShowElementSelector,
}) => {
  return (
    <div className="p-4 border-b">
      <div className="flex justify-between items-center mb-3">
        <h3 className="font-semibold flex items-center">
          <Layers className="h-5 w-5 text-blue-500 ml-2" />
          اختر عنصر
        </h3>
        <button
          className="btn btn-icon btn-secondary btn-sm"
          onClick={() => setShowElementSelector(!true)}
          title="إخفاء قائمة العناصر"
        >
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>
      <div className="max-h-60 overflow-y-auto bg-white rounded-lg shadow-sm">
        {design.elements.length === 0 ? (
          <div className="p-4 text-center text-gray-500">
            لا توجد عناصر في التصميم
          </div>
        ) : (
          design.elements.map(element => (
            <div
              key={element.id}
              className={`p-3 border-b cursor-pointer flex items-center ${
                selectedElement?.id === element.id 
                  ? 'bg-blue-50 border-r-2 border-blue-500' 
                  : 'hover:bg-gray-50'
              }`}
              onClick={() => onElementSelect(element)}
            >
              {element.type === 'text' ? (
                <Type className="h-4 w-4 text-blue-500 ml-2" />
              ) : element.type === 'shape' ? (
                <Square className="h-4 w-4 text-green-500 ml-2" />
              ) : (
                <Image className="h-4 w-4 text-purple-500 ml-2" />
              )}
              <span className="flex-grow truncate">{element.name}</span>
              {element.dataBinding && (
                <div className="flex items-center text-xs text-blue-500 bg-blue-50 px-2 py-1 rounded-full">
                  <Link className="h-3 w-3 ml-1" />
                  {Array.isArray(element.dataBinding) 
                    ? element.dataBinding.length 
                    : 1}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default ElementSelector;