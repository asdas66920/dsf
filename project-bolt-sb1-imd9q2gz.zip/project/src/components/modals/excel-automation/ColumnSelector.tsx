import React from 'react';
import { ExcelData } from '../../../types';
import { Table, Check, X, Settings, Search } from 'lucide-react';

interface ColumnSelectorProps {
  excelData: ExcelData;
  selectedColumns: string[];
  onColumnSelect: (column: string) => void;
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  filteredColumns: string[];
  activeColumnSettings: string | null;
  setActiveColumnSettings: (column: string | null) => void;
  setActiveTab: (tab: 'columns' | 'preview' | 'settings') => void;
}

const ColumnSelector: React.FC<ColumnSelectorProps> = ({
  excelData,
  selectedColumns,
  onColumnSelect,
  searchTerm,
  setSearchTerm,
  filteredColumns,
  activeColumnSettings,
  setActiveColumnSettings,
  setActiveTab,
}) => {
  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-3">
        <h3 className="font-semibold flex items-center">
          <Table className="h-5 w-5 text-green-500 ml-2" />
          اختر أعمدة للربط
        </h3>
        <div className="flex items-center">
          <button
            className="btn btn-primary btn-sm ml-2"
            onClick={() => {
              // اختيار جميع الأعمدة
              excelData.headers.forEach(header => {
                if (!selectedColumns.includes(header)) {
                  onColumnSelect(header);
                }
              });
            }}
            title="اختيار الكل"
          >
            <Check className="h-4 w-4" />
          </button>
          <button
            className="btn btn-secondary btn-sm"
            onClick={() => {
              // إلغاء اختيار جميع الأعمدة
              selectedColumns.forEach(column => {
                onColumnSelect(column);
              });
            }}
            title="إلغاء الكل"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
      
      <div className="mb-4 relative">
        <input
          type="text"
          className="text-input pr-8 w-full"
          placeholder="بحث في الأعمدة..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
          <Search className="h-4 w-4 text-gray-400" />
        </div>
      </div>
      
      <div className="max-h-96 overflow-y-auto bg-white rounded-lg shadow-sm">
        {filteredColumns.length === 0 ? (
          <div className="p-4 text-center text-gray-500">
            لا توجد أعمدة مطابقة للبحث
          </div>
        ) : (
          filteredColumns.map(header => (
            <div
              key={header}
              className={`flex items-center p-3 border-b hover:bg-gray-50 ${
                selectedColumns.includes(header) ? 'bg-blue-50' : ''
              }`}
            >
              <input
                type="checkbox"
                id={`column-${header}`}
                checked={selectedColumns.includes(header)}
                onChange={() => onColumnSelect(header)}
                className="ml-2 h-4 w-4 text-blue-600 focus:ring-blue-500 rounded"
              />
              <label
                htmlFor={`column-${header}`}
                className="cursor-pointer flex-grow truncate"
              >
                {header}
              </label>
              {selectedColumns.includes(header) && (
                <button
                  className="btn btn-icon btn-sm text-blue-500 hover:text-blue-700"
                  onClick={() => {
                    setActiveColumnSettings(header);
                    setActiveTab('settings');
                  }}
                  title="إعدادات العمود"
                >
                  <Settings className="h-4 w-4" />
                </button>
              )}
            </div>
          ))
        )}
      </div>
      
      {selectedColumns.length > 0 && (
        <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-100">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-blue-700">الأعمدة المختارة</span>
            <span className="bg-blue-500 text-white text-xs px-2 py-1 rounded-full">{selectedColumns.length}</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {selectedColumns.map(column => (
              <div 
                key={column} 
                className={`bg-white px-2 py-1 rounded-full text-xs border ${
                  activeColumnSettings === column 
                    ? 'border-blue-500 text-blue-700' 
                    : 'border-blue-200 text-blue-600'
                } flex items-center`}
              >
                {column}
                <button
                  className="mr-1 text-red-500 hover:text-red-700"
                  onClick={() => onColumnSelect(column)}
                  title="إزالة"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ColumnSelector;