import React from 'react';
import { Link, X, Maximize2, Minimize2 } from 'lucide-react';

interface ModalHeaderProps {
  toggleFullscreen: () => void;
  isFullscreen: boolean;
  onClose: () => void;
}

const ModalHeader: React.FC<ModalHeaderProps> = ({ toggleFullscreen, isFullscreen, onClose }) => {
  return (
    <div className="flex justify-between items-center mb-4 border-b pb-4">
      <div className="flex items-center">
        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 ml-3">
          <Link className="h-6 w-6" />
        </div>
        <div>
          <h2 className="text-xl font-bold">إعدادات ربط وأتمتة Excel</h2>
          <p className="text-sm text-gray-500">ربط عناصر التصميم بأعمدة البيانات لتوليد تصاميم متعددة</p>
        </div>
      </div>
      <div className="flex items-center space-x-2 space-x-reverse">
        <button
          className="btn btn-secondary btn-sm"
          onClick={toggleFullscreen}
          title={isFullscreen ? "تصغير" : "تكبير"}
        >
          {isFullscreen ? <Minimize2 className="h-5 w-5" /> : <Maximize2 className="h-5 w-5" />}
        </button>
        <button
          className="btn btn-icon btn-secondary"
          onClick={onClose}
        >
          <X className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
};

export default ModalHeader;