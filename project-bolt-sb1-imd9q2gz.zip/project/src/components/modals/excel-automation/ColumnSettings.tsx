import React, { useState } from 'react';
import { ExcelData } from '../../../types';
import { FileSpreadsheet, Move, Type, Sliders, Eye, Save, Code, HelpCircle, AlignRight, AlignCenter, AlignLeft, Palette, RotateCw, ArrowUp, ArrowDown, ArrowLeft, ArrowRight, Maximize, Minimize, Copy, Trash2, RefreshCw, Layers, Lock, Unlock } from 'lucide-react';
import { formatCellValue } from '../../../utils/excelUtils';
import HandlebarsHelpModal from '../HandlebarsHelpModal';

interface ColumnSettingsProps {
  activeColumnSettings: string | null;
  columnSettings: Record<string, any>;
  handleColumnSettingChange: (column: string, property: string, value: any) => void;
  handleSaveColumnSettings: () => void;
  setActiveTab: (tab: 'columns' | 'preview' | 'settings') => void;
  excelData: ExcelData;
  previewRowIndex: number;
}

const ColumnSettings: React.FC<ColumnSettingsProps> = ({
  activeColumnSettings,
  columnSettings,
  handleColumnSettingChange,
  handleSaveColumnSettings,
  setActiveTab,
  excelData,
  previewRowIndex,
}) => {
  const [showHandlebarsHelp, setShowHandlebarsHelp] = useState(false);
  const [showAdvancedSettings, setShowAdvancedSettings] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const [showColorPalette, setShowColorPalette] = useState(false);
  const [showFontSelector, setShowFontSelector] = useState(false);

  // مجموعة من الألوان المقترحة
  const suggestedColors = [
    '#00AA00', '#3b82f6', '#ef4444', '#f59e0b', '#10b981', 
    '#8b5cf6', '#ec4899', '#6b7280', '#000000', '#ffffff'
  ];

  // مجموعة من الخطوط المقترحة
  const suggestedFonts = [
    'Tajawal', 'Arial', 'Helvetica', 'Tahoma', 'Verdana', 
    'Times New Roman', 'Courier New', 'Georgia', 'Segoe UI', 'Roboto'
  ];

  if (!activeColumnSettings) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-8 bg-gray-50 rounded-lg">
        <div className="w-16 h-16 rounded-full bg-gray-200 flex items-center justify-center text-gray-400 mb-4">
          <FileSpreadsheet className="h-8 w-8" />
        </div>
        <p className="text-gray-500 text center mb-4">يرجى اختيار عمود من القائمة لعرض إعداداته</p>
        <button
          className="btn btn-primary"
          onClick={() => setActiveTab('columns')}
        >
          <FileSpreadsheet className="h-4 w-4 ml-2" />
          اختيار عمود
        </button>
      </div>
    );
  }
  
  const settings = columnSettings[activeColumnSettings];

  // تحريك العمود بمقدار محدد
  const moveColumn = (direction: 'up' | 'down' | 'left' | 'right', amount: number = 10) => {
    if (isLocked) return;
    
    switch (direction) {
      case 'up':
        handleColumnSettingChange(activeColumnSettings, 'y', settings.y - amount);
        break;
      case 'down':
        handleColumnSettingChange(activeColumnSettings, 'y', settings.y + amount);
        break;
      case 'left':
        handleColumnSettingChange(activeColumnSettings, 'x', settings.x - amount);
        break;
      case 'right':
        handleColumnSettingChange(activeColumnSettings, 'x', settings.x + amount);
        break;
    }
  };

  // نسخ إعدادات العمود
  const copyColumnSettings = () => {
    navigator.clipboard.writeText(JSON.stringify(settings, null, 2))
      .then(() => alert('تم نسخ إعدادات العمود إلى الحافظة'))
      .catch(err => console.error('فشل نسخ الإعدادات:', err));
  };

  // إعادة ضبط إعدادات العمود
  const resetColumnSettings = () => {
    if (confirm('هل أنت متأكد من إعادة ضبط إعدادات هذا العمود؟')) {
      handleColumnSettingChange(activeColumnSettings, 'fontSize', 25);
      handleColumnSettingChange(activeColumnSettings, 'textColor', '#00AA00');
      handleColumnSettingChange(activeColumnSettings, 'fontFamily', 'Tajawal');
      handleColumnSettingChange(activeColumnSettings, 'textAlign', 'right');
      handleColumnSettingChange(activeColumnSettings, 'rotation', 0);
      handleColumnSettingChange(activeColumnSettings, 'format', '');
      handleColumnSettingChange(activeColumnSettings, 'useTemplate', false);
      handleColumnSettingChange(activeColumnSettings, 'template', '');
    }
  };
  
  return (
    <div className="column-settings h-full overflow-y-auto">
      <div className="sticky top-0 bg-white z-10 border-b pb-4 mb-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 ml-3">
              <FileSpreadsheet className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">إعدادات العمود: {activeColumnSettings}</h3>
              <p className="text-sm text-gray-500">ضبط موضع وتنسيق العمود على التصميم</p>
            </div>
          </div>
          <div className="flex items-center">
            <button
              className="btn btn-secondary ml-2"
              onClick={() => setIsLocked(!isLocked)}
              title={isLocked ? "إلغاء قفل الموضع" : "قفل الموضع"}
            >
              {isLocked ? <Lock className="h-4 w-4" /> : <Unlock className="h-4 w-4" />}
            </button>
            <button
              className="btn btn-secondary ml-2"
              onClick={copyColumnSettings}
              title="نسخ الإعدادات"
            >
              <Copy className="h-4 w-4" />
            </button>
            <button
              className="btn btn-secondary ml-2"
              onClick={resetColumnSettings}
              title="إعادة ضبط الإعدادات"
            >
              <RefreshCw className="h-4 w-4" />
            </button>
            <button
              className="btn btn-primary"
              onClick={handleSaveColumnSettings}
            >
              <Save className="h-4 w-4 ml-2" />
              حفظ إعدادات العمود
            </button>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm p-4 mb-4 border border-gray-100">
        <div className="flex items-center mb-3 pb-2 border-b">
          <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 ml-2">
            <Move className="h-4 w-4" />
          </div>
          <h4 className="font-medium">الموضع والحجم</h4>
        </div>
        
        {/* أزرار التحكم بالموضع */}
        <div className="grid grid-cols-3 gap-2 mb-4">
          <div></div>
          <button
            className="btn btn-secondary btn-sm"
            onClick={() => moveColumn('up')}
            disabled={isLocked}
          >
            <ArrowUp className="h-4 w-4" />
          </button>
          <div></div>
          
          <button
            className="btn btn-secondary btn-sm"
            onClick={() => moveColumn('left')}
            disabled={isLocked}
          >
            <ArrowRight className="h-4 w-4" />
          </button>
          <div className="flex items-center justify-center">
            <span className="text-xs text-gray-500">تحريك</span>
          </div>
          <button
            className="btn btn-secondary btn-sm"
            onClick={() => moveColumn('right')}
            disabled={isLocked}
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
          
          <div></div>
          <button
            className="btn btn-secondary btn-sm"
            onClick={() => moveColumn('down')}
            disabled={isLocked}
          >
            <ArrowDown className="h-4 w-4" />
          </button>
          <div></div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-xs text-gray-500 mb-1">X</label>
            <div className="flex items-center">
              <button
                className="btn btn-secondary btn-sm p-1"
                onClick={() => handleColumnSettingChange(activeColumnSettings, 'x', settings.x - 10)}
                disabled={isLocked}
              >
                -
              </button>
              <input
                type="number"
                className="number-input mx-1"
                value={settings.x}
                onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'x', parseInt(e.target.value) || 0)}
                disabled={isLocked}
              />
              <button
                className="btn btn-secondary btn-sm p-1"
                onClick={() => handleColumnSettingChange(activeColumnSettings, 'x', settings.x + 10)}
                disabled={isLocked}
              >
                +
              </button>
            </div>
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1">Y</label>
            <div className="flex items-center">
              <button
                className="btn btn-secondary btn-sm p-1"
                onClick={() => handleColumnSettingChange(activeColumnSettings, 'y', settings.y - 10)}
                disabled={isLocked}
              >
                -
              </button>
              <input
                type="number"
                className="number-input mx-1"
                value={settings.y}
                onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'y', parseInt(e.target.value) || 0)}
                disabled={isLocked}
              />
              <button
                className="btn btn-secondary btn-sm p-1"
                onClick={() => handleColumnSettingChange(activeColumnSettings, 'y', settings.y + 10)}
                disabled={isLocked}
              >
                +
              </button>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-xs text-gray-500 mb-1">العرض</label>
            <div className="flex items-center">
              <button
                className="btn btn-secondary btn-sm p-1"
                onClick={() => handleColumnSettingChange(activeColumnSettings, 'width', (settings.width || 100) - 10)}
              >
                <Minimize className="h-4 w-4" />
              </button>
              <input
                type="number"
                className="number-input mx-1"
                value={settings.width || 100}
                onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'width', parseInt(e.target.value) || 100)}
              />
              <button
                className="btn btn-secondary btn-sm p-1"
                onClick={() => handleColumnSettingChange(activeColumnSettings, 'width', (settings.width || 100) + 10)}
              >
                <Maximize className="h-4 w-4" />
              </button>
            </div>
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1">الارتفاع</label>
            <div className="flex items-center">
              <button
                className="btn btn-secondary btn-sm p-1"
                onClick={() => handleColumnSettingChange(activeColumnSettings, 'height', (settings.height || 30) - 10)}
              >
                <Minimize className="h-4 w-4" />
              </button>
              <input
                type="number"
                className="number-input mx-1"
                value={settings.height || 30}
                onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'height', parseInt(e.target.value) || 30)}
              />
              <button
                className="btn btn-secondary btn-sm p-1"
                onClick={() => handleColumnSettingChange(activeColumnSettings, 'height', (settings.height || 30) + 10)}
              >
                <Maximize className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
        
        <div className="mb-2">
          <label className="block text-xs text-gray-500 mb-1">الدوران: {settings.rotation || 0}°</label>
          <div className="flex items-center">
            <input
              type="range"
              className="range-input flex-grow"
              min="0"
              max="360"
              value={settings.rotation || 0}
              onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'rotation', parseInt(e.target.value) || 0)}
            />
            <div className="flex items-center mr-2">
              <button
                className="btn btn-secondary btn-sm p-1"
                onClick={() => handleColumnSettingChange(activeColumnSettings, 'rotation', (settings.rotation || 0) - 15)}
              >
                <RotateCw className="h-4 w-4" />
              </button>
              <input
                type="number"
                className="number-input w-16 mx-1"
                value={settings.rotation || 0}
                onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'rotation', parseInt(e.target.value) || 0)}
              />
              <button
                className="btn btn-secondary btn-sm p-1"
                onClick={() => handleColumnSettingChange(activeColumnSettings, 'rotation', (settings.rotation || 0) + 15)}
              >
                <RotateCw className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm p-4 mb-4 border border-gray-100">
        <div className="flex items-center mb-3 pb-2 border-b">
          <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-500 ml-2">
            <Type className="h-4 w-4" />
          </div>
          <h4 className="font-medium">خصائص النص</h4>
        </div>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-xs text-gray-500 mb-1">حجم الخط</label>
            <div className="flex items-center">
              <button
                className="btn btn-secondary btn-sm p-1"
                onClick={() => handleColumnSettingChange(activeColumnSettings, 'fontSize', (settings.fontSize || 25) - 2)}
              >
                -
              </button>
              <input
                type="number"
                className="number-input mx-1"
                value={settings.fontSize || 25}
                onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'fontSize', parseInt(e.target.value) || 25)}
              />
              <button
                className="btn btn-secondary btn-sm p-1"
                onClick={() => handleColumnSettingChange(activeColumnSettings, 'fontSize', (settings.fontSize || 25) + 2)}
              >
                +
              </button>
            </div>
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1">نوع الخط</label>
            <div className="relative">
              <select
                className="select-input"
                value={settings.fontFamily || 'Tajawal'}
                onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'fontFamily', e.target.value)}
              >
                <option value="Tajawal">Tajawal</option>
                <option value="Arial">Arial</option>
                <option value="Helvetica">Helvetica</option>
                <option value="Tahoma">Tahoma</option>
                <option value="Verdana">Verdana</option>
                <option value="Times New Roman">Times New Roman</option>
                <option value="Courier New">Courier New</option>
                <option value="Georgia">Georgia</option>
                <option value="Segoe UI">Segoe UI</option>
                <option value="Roboto">Roboto</option>
              </select>
              <button
                className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                onClick={() => setShowFontSelector(!showFontSelector)}
              >
                <Layers className="h-4 w-4" />
              </button>
            </div>
            
            {/* اختيار سريع للخطوط */}
            {showFontSelector && (
              <div className="mt-2 bg-gray-50 p-2 rounded-md border border-gray-200 grid grid-cols-2 gap-2">
                {suggestedFonts.map(font => (
                  <button
                    key={font}
                    className={`btn btn-sm ${settings.fontFamily === font ? 'btn-primary' : 'btn-secondary'}`}
                    onClick={() => {
                      handleColumnSettingChange(activeColumnSettings, 'fontFamily', font);
                      setShowFontSelector(false);
                    }}
                    style={{ fontFamily: font }}
                  >
                    {font}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
        
        <div className="mb-4">
          <label className="block text-xs text-gray-500 mb-1">لون النص</label>
          <div className="flex items-center">
            <input
              type="color"
              className="color-picker w-10 h-10 rounded-md ml-2"
              value={settings.textColor || '#00AA00'}
              onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'textColor', e.target.value)}
            />
            <input
              type="text"
              className="text-input flex-grow"
              value={settings.textColor || '#00AA00'}
              onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'textColor', e.target.value)}
            />
            <button
              className="btn btn-secondary btn-sm mr-2"
              onClick={() => setShowColorPalette(!showColorPalette)}
            >
              <Palette className="h-4 w-4" />
            </button>
          </div>
          
          {/* لوحة ألوان سريعة */}
          {showColorPalette && (
            <div className="mt-2 bg-gray-50 p-2 rounded-md border border-gray-200 flex flex-wrap gap-2">
              {suggestedColors.map(color => (
                <button
                  key={color}
                  className="w-8 h-8 rounded-md border border-gray-300"
                  style={{ backgroundColor: color }}
                  onClick={() => {
                    handleColumnSettingChange(activeColumnSettings, 'textColor', color);
                    setShowColorPalette(false);
                  }}
                  title={color}
                />
              ))}
            </div>
          )}
        </div>
        
        <div className="mb-2">
          <label className="block text-xs text-gray-500 mb-1">محاذاة النص</label>
          <div className="flex">
            <button
              className={`btn flex-1 ${settings.textAlign === 'right' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => handleColumnSettingChange(activeColumnSettings, 'textAlign', 'right')}
            >
              <AlignRight className="h-4 w-4 ml-1" />
              يمين
            </button>
            <button
              className={`btn flex-1 mx-1 ${settings.textAlign === 'center' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => handleColumnSettingChange(activeColumnSettings, 'textAlign', 'center')}
            >
              <AlignCenter className="h-4 w-4 ml-1" />
              وسط
            </button>
            <button
              className={`btn flex-1 ${settings.textAlign === 'left' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => handleColumnSettingChange(activeColumnSettings, 'textAlign', 'left')}
            >
              <AlignLeft className="h-4 w-4 ml-1" />
              يسار
            </button>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow-sm p-4 mb-4 border border-gray-100">
        <div className="flex items-center justify-between mb-3 pb-2 border-b">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center text-green-500 ml-2">
              <Sliders className="h-4 w-4" />
            </div>
            <h4 className="font-medium">تنسيق البيانات</h4>
          </div>
          <div className="flex items-center">
            <div className="flex items-center">
              <input
                type="checkbox"
                id="use-template"
                className="ml-2"
                checked={settings.useTemplate || false}
                onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'useTemplate', e.target.checked)}
              />
              <label htmlFor="use-template" className="text-xs text-gray-700">
                استخدام قالب Handlebars
              </label>
            </div>
            <button
              className="btn btn-icon btn-secondary btn-sm mr-2"
              onClick={() => setShowHandlebarsHelp(true)}
              title="مساعدة حول قوالب Handlebars"
            >
              <HelpCircle className="h-4 w-4" />
            </button>
          </div>
        </div>
        
        {settings.useTemplate ? (
          <div className="mb-4">
            <label className="block text-xs text-gray-500 mb-1">قالب Handlebars</label>
            <div className="relative">
              <textarea
                className="text-input p-2 rounded w-full border border-gray-300 font-mono text-sm"
                value={settings.template || ''}
                onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'template', e.target.value)}
                rows={4}
                dir="ltr"
                placeholder="مثال: {{#if (ifCond row.العمر '>' 18)}}بالغ{{else}}قاصر{{/if}}"
              />
              <Code className="absolute top-2 left-2 h-4 w-4 text-gray-400" />
            </div>
            <div className="mt-1 bg-blue-50 p-3 rounded-md border border-blue-100">
              <p className="text-xs text-blue-700 mb-1">يمكنك استخدام الدوال التالية:</p>
              <ul className="text-xs text-blue-600 list-disc list-inside">
                <li>{"{{formatDate value format}}"}: لتنسيق التاريخ</li>
                <li>{"{{formatCurrency value}}"}: لتنسيق العملة</li>
                <li>{"{{#if (ifCond value operator value2)}}"}: للشروط المنطقية</li>
                <li>
                  <button
                    className="text-blue-700 underline"
                    onClick={() => setShowHandlebarsHelp(true)}
                  >
                    عرض المزيد من المساعدة...
                  </button>
                </li>
              </ul>
            </div>
          </div>
        ) : (
          <div className="mb-4">
            <label className="block text-xs text-gray-500 mb-1">نوع التنسيق</label>
            <select
              className="select-input"
              value={settings.format || ''}
              onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'format', e.target.value)}
            >
              <option value="">بدون تنسيق</option>
              <option value="date">تاريخ</option>
              <option value="currency">عملة</option>
              <option value="number">رقم</option>
              <option value="percentage">نسبة مئوية</option>
            </select>
          </div>
        )}
        
        <button
          className="btn btn-secondary w-full"
          onClick={() => setShowAdvancedSettings(!showAdvancedSettings)}
        >
          {showAdvancedSettings ? 'إخفاء الإعدادات المتقدمة' : 'عرض الإعدادات المتقدمة'}
        </button>
        
        {showAdvancedSettings && (
          <div className="mt-4 bg-gray-50 p-3 rounded-md border border-gray-200">
            <h5 className="font-medium text-sm mb-2">إعدادات متقدمة</h5>
            
            <div className="mb-2">
              <label className="block text-xs text-gray-500 mb-1">الطبقة (Z-Index)</label>
              <input
                type="number"
                className="number-input"
                value={settings.zIndex || 0}
                onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'zIndex', parseInt(e.target.value) || 0)}
              />
            </div>
            
            <div className="mb-2">
              <label className="block text-xs text-gray-500 mb-1">الشفافية</label>
              <div className="flex items-center">
                <input
                  type="range"
                  className="range-input flex-grow"
                  min="0"
                  max="1"
                  step="0.1"
                  value={settings.opacity || 1}
                  onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'opacity', parseFloat(e.target.value))}
                />
                <span className="mr-2">{Math.round((settings.opacity || 1) * 100)}%</span>
              </div>
            </div>
            
            <div className="mb-2">
              <label className="block text-xs text-gray-500 mb-1">تباعد الأسطر</label>
              <div className="flex items-center">
                <input
                  type="range"
                  className="range-input flex-grow"
                  min="0.5"
                  max="3"
                  step="0.1"
                  value={settings.lineHeight || 1.2}
                  onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'lineHeight', parseFloat(e.target.value))}
                />
                <span className="mr-2">{settings.lineHeight || 1.2}</span>
              </div>
            </div>
            
            <div className="mb-2">
              <label className="block text-xs text-gray-500 mb-1">نمط الخط</label>
              <div className="flex">
                <button
                  className={`btn flex-1 ${settings.fontStyle === 'normal' ? 'btn-primary' : 'btn-secondary'}`}
                  onClick={() => handleColumnSettingChange(activeColumnSettings, 'fontStyle', 'normal')}
                >
                  عادي
                </button>
                <button
                  className={`btn flex-1 mx-1 ${settings.fontStyle === 'bold' ? 'btn-primary' : 'btn-secondary'}`}
                  onClick={() => handleColumnSettingChange(activeColumnSettings, 'fontStyle', 'bold')}
                >
                  <strong>غامق</strong>
                </button>
                <button
                  className={`btn flex-1 ${settings.fontStyle === 'italic' ? 'btn-primary' : 'btn-secondary'}`}
                  onClick={() => handleColumnSettingChange(activeColumnSettings, 'fontStyle', 'italic')}
                >
                  <em>مائل</em>
                </button>
              </div>
            </div>
            
            <div className="mb-2">
              <label className="block text-xs text-gray-500 mb-1">زخرفة النص</label>
              <div className="flex">
                <button
                  className={`btn flex-1 ${settings.textDecoration === '' ? 'btn-primary' : 'btn-secondary'}`}
                  onClick={() => handleColumnSettingChange(activeColumnSettings, 'textDecoration', '')}
                >
                  بدون
                </button>
                <button
                  className={`btn flex-1 mx-1 ${settings.textDecoration === 'underline' ? 'btn-primary' : 'btn-secondary'}`}
                  onClick={() => handleColumnSettingChange(activeColumnSettings, 'textDecoration', 'underline')}
                >
                  <span style={{ textDecoration: 'underline' }}>تحته خط</span>
                </button>
                <button
                  className={`btn flex-1 ${settings.textDecoration === 'line-through' ? 'btn-primary' : 'btn-secondary'}`}
                  onClick={() => handleColumnSettingChange(activeColumnSettings, 'textDecoration', 'line-through')}
                >
                  <span style={{ textDecoration: 'line-through' }}>يتوسطه خط</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
      
      <div className="bg-white rounded-lg shadow-sm p-4 mb-4 border border-gray-100">
        <div className="flex items-center mb-3 pb-2 border-b">
          <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-500 ml-2">
            <Eye className="h-4 w-4" />
          </div>
          <h4 className="font-medium">معاينة</h4>
        </div>
        <div className="bg-gray-50 p-4 rounded-md">
          <div className="bg-white p-4 rounded-md shadow-sm">
            <p style={{
              fontSize: `${settings.fontSize || 25}px`,
              fontFamily: settings.fontFamily || 'Tajawal',
              color: settings.textColor || '#00AA00',
              textAlign: settings.textAlign || 'right' as any,
              fontStyle: settings.fontStyle || 'normal',
              textDecoration: settings.textDecoration || 'none',
              lineHeight: settings.lineHeight || 1.2,
              opacity: settings.opacity || 1,
              transform: `rotate(${settings.rotation || 0}deg)`
            }}>
              {settings.useTemplate ? (
                <span className="text-blue-600 font-mono">سيتم تطبيق قالب Handlebars عند التوليد</span>
              ) : (
                excelData.rows[previewRowIndex] && activeColumnSettings
                  ? formatCellValue(excelData.rows[previewRowIndex][activeColumnSettings], settings.format)
                  : 'نموذج نص'
              )}
            </p>
          </div>
          
          <div className="mt-4 text-center">
            <button
              className="btn btn-primary"
              onClick={() => setActiveTab('preview')}
            >
              <Eye className="h-4 w-4 ml-2" />
              العودة إلى المعاينة
            </button>
          </div>
        </div>
      </div>
      
      <HandlebarsHelpModal isOpen={showHandlebarsHelp} onClose={() => setShowHandlebarsHelp(false)} />
    </div>
  );
};

export default ColumnSettings;