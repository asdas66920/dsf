import React, { useRef, useEffect, useState } from 'react';
import { CanvasElement, Design, ExcelData } from '../../../types';
import { Eye, LayoutGrid, Link as LinkIcon, ArrowRight, ArrowLeft, ZoomIn, ZoomOut, RotateCcw, Grid, Ruler, Crosshair, Move, Layers, Palette, Type, AlignCenter, AlignLeft, AlignRight, Sliders, Info, CheckCircle, AlertTriangle, HelpCircle, Maximize2, Minimize2, RefreshCw, Lock, Unlock, Copy, Download, Lightbulb } from 'lucide-react';
import { Stage, Layer, Rect, Text, Circle, Image, Line, Group, Transformer, Arrow } from 'react-konva';
import useImage from 'use-image';
import { formatCellValue } from '../../../utils/excelUtils';
import EmptyPreview from './EmptyPreview';

interface BindingPreviewProps {
  selectedElement: CanvasElement | null;
  design: Design;
  excelData: ExcelData;
  previewRowIndex: number;
  handlePrevPreviewRow: () => void;
  handleNextPreviewRow: () => void;
  previewScale: number;
  setPreviewScale: (scale: number) => void;
  showGrid: boolean;
  setShowGrid: (show: boolean) => void;
  showBindingLines: boolean;
  setShowBindingLines: (show: boolean) => void;
  stageRef: React.RefObject<any>;
  selectedColumns: string[];
  columnSettings: Record<string, any>;
  activeColumnSettings: string | null;
  setActiveColumnSettings: (column: string | null) => void;
  setActiveTab: (tab: 'columns' | 'preview' | 'settings') => void;
  handleColumnSettingChange: (column: string, property: string, value: any) => void;
}

const BindingPreview: React.FC<BindingPreviewProps> = ({
  selectedElement,
  design,
  excelData,
  previewRowIndex,
  handlePrevPreviewRow,
  handleNextPreviewRow,
  previewScale,
  setPreviewScale,
  showGrid,
  setShowGrid,
  showBindingLines,
  setShowBindingLines,
  stageRef,
  selectedColumns,
  columnSettings,
  activeColumnSettings,
  setActiveColumnSettings,
  setActiveTab,
  handleColumnSettingChange,
}) => {
  const [showRulers, setShowRulers] = useState(false);
  const [showCrosshair, setShowCrosshair] = useState(false);
  const [snapToGrid, setSnapToGrid] = useState(false);
  const [gridSize, setGridSize] = useState(20);
  const [showLayerOrder, setShowLayerOrder] = useState(false);
  const [showColumnLabels, setShowColumnLabels] = useState(true);
  const [highlightActiveColumn, setHighlightActiveColumn] = useState(true);
  const [showElementBounds, setShowElementBounds] = useState(true);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [transformerRef, setTransformerRef] = useState<any>(null);
  const [showTips, setShowTips] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showColorPalette, setShowColorPalette] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const [showHelpTooltip, setShowHelpTooltip] = useState<string | null>(null);
  const [showAnimations, setShowAnimations] = useState(true);
  const [showPerformanceStats, setShowPerformanceStats] = useState(false);
  const [fps, setFps] = useState(0);
  const [renderTime, setRenderTime] = useState(0);
  const [showSmartGuides, setShowSmartGuides] = useState(true);
  const [smartGuides, setSmartGuides] = useState<{horizontal: number[], vertical: number[]}>({
    horizontal: [],
    vertical: []
  });
  
  // مجموعة من الألوان المقترحة
  const suggestedColors = [
    '#00AA00', '#3b82f6', '#ef4444', '#f59e0b', '#10b981', 
    '#8b5cf6', '#ec4899', '#6b7280', '#000000', '#ffffff'
  ];

  // قياس الأداء
  useEffect(() => {
    if (!showPerformanceStats) return;
    
    let frameCount = 0;
    let lastTime = performance.now();
    
    const measureFps = () => {
      frameCount++;
      const now = performance.now();
      
      if (now - lastTime >= 1000) {
        setFps(Math.round(frameCount * 1000 / (now - lastTime)));
        frameCount = 0;
        lastTime = now;
      }
      
      requestAnimationFrame(measureFps);
    };
    
    const frameId = requestAnimationFrame(measureFps);
    
    return () => {
      cancelAnimationFrame(frameId);
    };
  }, [showPerformanceStats]);

  // قياس وقت الرسم
  useEffect(() => {
    if (!showPerformanceStats || !stageRef.current) return;
    
    const stage = stageRef.current;
    const originalDraw = stage.batchDraw;
    
    stage.batchDraw = function() {
      const startTime = performance.now();
      const result = originalDraw.call(this);
      const endTime = performance.now();
      setRenderTime(endTime - startTime);
      return result;
    };
    
    return () => {
      stage.batchDraw = originalDraw;
    };
  }, [showPerformanceStats, stageRef]);

  // تفعيل وضع ملء الشاشة
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      const container = document.querySelector('.preview-container');
      if (container && container.requestFullscreen) {
        container.requestFullscreen().catch(err => {
          console.error(`خطأ في تفعيل وضع ملء الشاشة: ${err.message}`);
        });
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
  };

  if (!selectedElement) {
    return <EmptyPreview setActiveTab={setActiveTab} />;
  }

  // رسم شبكة خلفية للمعاينة
  const renderGrid = () => {
    if (!showGrid) return null;
    
    const width = design.width;
    const height = design.height;
    
    const horizontalLines = [];
    const verticalLines = [];
    
    for (let i = 0; i <= width; i += gridSize) {
      horizontalLines.push(
        <Line
          key={`h-${i}`}
          points={[i, 0, i, height]}
          stroke="#ddd"
          strokeWidth={0.5}
          opacity={0.5}
          perfectDrawEnabled={false}
        />
      );
    }
    
    for (let i = 0; i <= height; i += gridSize) {
      verticalLines.push(
        <Line
          key={`v-${i}`}
          points={[0, i, width, i]}
          stroke="#ddd"
          strokeWidth={0.5}
          opacity={0.5}
          perfectDrawEnabled={false}
        />
      );
    }
    
    return (
      <Group>
        {horizontalLines}
        {verticalLines}
      </Group>
    );
  };

  // رسم المساطر
  const renderRulers = () => {
    if (!showRulers) return null;
    
    const width = design.width;
    const height = design.height;
    const rulerSize = 20;
    
    return (
      <Group>
        {/* المسطرة الأفقية */}
        <Rect
          x={0}
          y={0}
          width={width}
          height={rulerSize}
          fill="#f0f0f0"
          stroke="#ccc"
          strokeWidth={0.5}
          perfectDrawEnabled={false}
        />
        
        {/* علامات المسطرة الأفقية */}
        {Array.from({ length: Math.ceil(width / 10) }, (_, i) => (
          <Group key={`h-mark-${i}`} perfectDrawEnabled={false}>
            <Line
              points={[i * 10, 0, i * 10, i % 10 === 0 ? rulerSize : rulerSize / 2]}
              stroke="#666"
              strokeWidth={0.5}
              perfectDrawEnabled={false}
            />
            {i % 10 === 0 && (
              <Text
                x={i * 10 + 2}
                y={2}
                text={`${i * 10}`}
                fontSize={8}
                fill="#666"
                perfectDrawEnabled={false}
              />
            )}
          </Group>
        ))}
        
        {/* المسطرة العمودية */}
        <Rect
          x={0}
          y={0}
          width={rulerSize}
          height={height}
          fill="#f0f0f0"
          stroke="#ccc"
          strokeWidth={0.5}
          perfectDrawEnabled={false}
        />
        
        {/* علامات المسطرة العمودية */}
        {Array.from({ length: Math.ceil(height / 10) }, (_, i) => (
          <Group key={`v-mark-${i}`} perfectDrawEnabled={false}>
            <Line
              points={[0, i * 10, i % 10 === 0 ? rulerSize : rulerSize / 2, i * 10]}
              stroke="#666"
              strokeWidth={0.5}
              perfectDrawEnabled={false}
            />
            {i % 10 === 0 && (
              <Text
                x={2}
                y={i * 10 + 2}
                text={`${i * 10}`}
                fontSize={8}
                fill="#666"
                perfectDrawEnabled={false}
              />
            )}
          </Group>
        ))}
      </Group>
    );
  };

  // رسم خطوط التقاطع
  const renderCrosshair = () => {
    if (!showCrosshair) return null;
    
    return (
      <Group>
        <Line
          points={[0, mousePosition.y, design.width, mousePosition.y]}
          stroke="rgba(0, 100, 255, 0.5)"
          strokeWidth={0.5}
          dash={[2, 2]}
          perfectDrawEnabled={false}
        />
        <Line
          points={[mousePosition.x, 0, mousePosition.x, design.height]}
          stroke="rgba(0, 100, 255, 0.5)"
          strokeWidth={0.5}
          dash={[2, 2]}
          perfectDrawEnabled={false}
        />
        
        {/* عرض إحداثيات الماوس */}
        <Rect
          x={mousePosition.x + 5}
          y={mousePosition.y + 5}
          width={70}
          height={20}
          fill="rgba(0, 0, 0, 0.7)"
          cornerRadius={3}
          perfectDrawEnabled={false}
        />
        <Text
          x={mousePosition.x + 10}
          y={mousePosition.y + 10}
          text={`X: ${Math.round(mousePosition.x)}, Y: ${Math.round(mousePosition.y)}`}
          fontSize={10}
          fill="white"
          perfectDrawEnabled={false}
        />
      </Group>
    );
  };

  // رسم خطوط الربط بين العنصر والأعمدة
  const renderBindingLines = () => {
    if (!showBindingLines || !selectedElement) return null;
    
    return selectedColumns.map(column => {
      const settings = columnSettings[column];
      if (!settings) return null;
      
      const isActive = activeColumnSettings === column;
      
      return (
        <Group key={`binding-line-${column}`}>
          <Line
            points={[
              selectedElement.x + selectedElement.width / 2,
              selectedElement.y + selectedElement.height / 2,
              settings.x,
              settings.y
            ]}
            stroke={isActive ? "#3b82f6" : "#94a3b8"}
            strokeWidth={isActive ? 1.5 : 1}
            dash={[5, 2]}
            opacity={isActive ? 0.9 : 0.6}
            perfectDrawEnabled={false}
          />
          
          {/* سهم في نهاية الخط */}
          {isActive && (
            <Arrow
              points={[
                selectedElement.x + selectedElement.width / 2,
                selectedElement.y + selectedElement.height / 2,
                settings.x,
                settings.y
              ]}
              pointerLength={10}
              pointerWidth={10}
              fill={isActive ? "#3b82f6" : "#94a3b8"}
              stroke={isActive ? "#3b82f6" : "#94a3b8"}
              strokeWidth={isActive ? 1.5 : 1}
              opacity={isActive ? 0.9 : 0.6}
              perfectDrawEnabled={false}
            />
          )}
        </Group>
      );
    });
  };

  // رسم حدود العنصر المحدد
  const renderElementBounds = () => {
    if (!showElementBounds || !selectedElement) return null;
    
    return (
      <Rect
        x={selectedElement.x}
        y={selectedElement.y}
        width={selectedElement.width}
        height={selectedElement.height}
        stroke="#3b82f6"
        strokeWidth={1}
        dash={[3, 3]}
        fill="transparent"
        perfectDrawEnabled={false}
      />
    );
  };

  // رسم ترتيب الطبقات
  const renderLayerOrder = () => {
    if (!showLayerOrder) return null;
    
    return selectedColumns.map((column, index) => {
      const settings = columnSettings[column];
      if (!settings) return null;
      
      return (
        <Group key={`layer-order-${column}`}>
          <Circle
            x={settings.x - 15}
            y={settings.y - 15}
            radius={8}
            fill="#3b82f6"
            stroke="white"
            strokeWidth={1}
            perfectDrawEnabled={false}
          />
          <Text
            x={settings.x - 15 - 3}
            y={settings.y - 15 - 4}
            text={`${index + 1}`}
            fontSize={10}
            fill="white"
            align="center"
            perfectDrawEnabled={false}
          />
        </Group>
      );
    });
  };

  // رسم العنصر المحدد في المعاينة
  const renderElementPreview = (element: CanvasElement) => {
    switch (element.type) {
      case 'text':
        return (
          <Text
            x={element.x}
            y={element.y}
            text={(element as any).text}
            fontSize={(element as any).fontSize / previewScale}
            fontFamily={(element as any).fontFamily}
            fill={(element as any).fill}
            width={element.width / previewScale}
            height={element.height / previewScale}
            align={(element as any).align}
            opacity={0.5}
            perfectDrawEnabled={false}
          />
        );
      case 'shape':
        return (
          <Rect
            x={element.x}
            y={element.y}
            width={element.width / previewScale}
            height={element.height / previewScale}
            fill={element.type === 'shape' ? (element as any).fill : '#e5e7eb'}
            opacity={0.5}
            perfectDrawEnabled={false}
          />
        );
      case 'image':
        return (
          <ImagePreview
            src={element.type === 'image' ? (element as any).src : ''}
            x={element.x}
            y={element.y}
            width={element.width / previewScale}
            height={element.height / previewScale}
            opacity={0.5}
          />
        );
      default:
        return null;
    }
  };

  // رسم الخطوط الذكية
  const renderSmartGuides = () => {
    if (!showSmartGuides) return null;
    
    return (
      <Group>
        {smartGuides.horizontal.map((y, index) => (
          <Line
            key={`h-guide-${index}`}
            points={[0, y, design.width, y]}
            stroke="#10b981"
            strokeWidth={1}
            dash={[4, 4]}
            opacity={0.8}
            perfectDrawEnabled={false}
          />
        ))}
        {smartGuides.vertical.map((x, index) => (
          <Line
            key={`v-guide-${index}`}
            points={[x, 0, x, design.height]}
            stroke="#10b981"
            strokeWidth={1}
            dash={[4, 4]}
            opacity={0.8}
            perfectDrawEnabled={false}
          />
        ))}
      </Group>
    );
  };

  // تحديث موضع الماوس
  const handleMouseMove = (e: any) => {
    const stage = stageRef.current;
    if (!stage) return;
    
    const pointerPosition = stage.getPointerPosition();
    if (!pointerPosition) return;
    
    const scale = stage.scaleX();
    
    const newPosition = {
      x: (pointerPosition.x - stage.x()) / scale,
      y: (pointerPosition.y - stage.y()) / scale
    };
    
    setMousePosition(newPosition);
    
    // تحديث الخطوط الذكية
    if (showSmartGuides && activeColumnSettings) {
      const settings = columnSettings[activeColumnSettings];
      if (!settings) return;
      
      const horizontalGuides = [];
      const verticalGuides = [];
      
      // إضافة خطوط للعنصر المحدد
      if (selectedElement) {
        // خطوط أفقية
        horizontalGuides.push(selectedElement.y); // أعلى
        horizontalGuides.push(selectedElement.y + selectedElement.height / 2); // وسط
        horizontalGuides.push(selectedElement.y + selectedElement.height); // أسفل
        
        // خطوط عمودية
        verticalGuides.push(selectedElement.x); // يسار
        verticalGuides.push(selectedElement.x + selectedElement.width / 2); // وسط
        verticalGuides.push(selectedElement.x + selectedElement.width); // يمين
      }
      
      // إضافة خطوط للأعمدة الأخرى
      selectedColumns.forEach(column => {
        if (column === activeColumnSettings) return;
        
        const colSettings = columnSettings[column];
        if (!colSettings) return;
        
        horizontalGuides.push(colSettings.y);
        verticalGuides.push(colSettings.x);
      });
      
      // تحديث الخطوط الذكية
      setSmartGuides({
        horizontal: horizontalGuides,
        vertical: verticalGuides
      });
    }
  };

  // تطبيق التحديثات على العمود عند السحب
  const handleDragColumn = (column: string, e: any) => {
    let { x, y } = e.target.position();
    
    // تطبيق التقريب إلى الشبكة إذا كان مفعلاً
    if (snapToGrid) {
      x = Math.round(x / gridSize) * gridSize;
      y = Math.round(y / gridSize) * gridSize;
      e.target.position({ x, y });
    }
    
    // تطبيق التقريب إلى الخطوط الذكية
    if (showSmartGuides) {
      const snapThreshold = 5;
      
      // التقريب إلى الخطوط الأفقية
      for (const guideY of smartGuides.horizontal) {
        if (Math.abs(y - guideY) < snapThreshold) {
          y = guideY;
          e.target.y(y);
          break;
        }
      }
      
      // التقريب إلى الخطوط العمودية
      for (const guideX of smartGuides.vertical) {
        if (Math.abs(x - guideX) < snapThreshold) {
          x = guideX;
          e.target.x(x);
          break;
        }
      }
    }
    
    handleColumnSettingChange(column, 'x', x);
    handleColumnSettingChange(column, 'y', y);
  };

  // رسائل إرشادية للخطوات التالية
  const renderNextStepsTips = () => {
    if (!showTips) return null;
    
    return (
      <div className="absolute bottom-4 right-4 bg-gradient-to-r from-blue-500 to-indigo-600 text-white p-4 rounded-lg shadow-lg max-w-xs animate-pulse-slow">
        <div className="flex items-start mb-2">
          <Lightbulb className="h-5 w-5 text-yellow-300 mt-0.5 ml-2 flex-shrink-0" />
          <div>
            <h4 className="font-bold text-sm">نصائح للخطوات التالية</h4>
            <p className="text-xs opacity-90">اسحب نقاط الربط لتحديد موضع كل عمود على التصميم</p>
          </div>
        </div>
        <div className="flex justify-end mt-2">
          <button 
            className="text-xs bg-white bg-opacity-20 hover:bg-opacity-30 px-2 py-1 rounded transition-colors"
            onClick={() => setShowTips(false)}
          >
            إخفاء
          </button>
        </div>
      </div>
    );
  };

  // رسم إحصائيات الأداء
  const renderPerformanceStats = () => {
    if (!showPerformanceStats) return null;
    
    return (
      <div className="absolute top-4 left-4 bg-black bg-opacity-70 text-white p-2 rounded text-xs">
        <div className="flex items-center mb-1">
          <div className={`w-2 h-2 rounded-full mr-1 ${fps > 50 ? 'bg-green-500' : fps > 30 ? 'bg-yellow-500' : 'bg-red-500'}`}></div>
          <span>FPS: {fps}</span>
        </div>
        <div>وقت الرسم: {renderTime.toFixed(2)}ms</div>
      </div>
    );
  };

  // رسم مساعدة للمستخدم
  const renderHelpTooltip = () => {
    if (!showHelpTooltip) return null;
    
    return (
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-black bg-opacity-80 text-white p-4 rounded-lg shadow-lg max-w-md z-50">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-bold flex items-center">
            <HelpCircle className="h-5 w-5 text-blue-400 ml-2" />
            مساعدة
          </h3>
          <button 
            className="text-gray-400 hover:text-white"
            onClick={() => setShowHelpTooltip(null)}
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        {showHelpTooltip === 'grid' && (
          <div>
            <p className="mb-2">تتيح لك الشبكة تنظيم العناصر بدقة على التصميم. يمكنك تغيير حجم الشبكة وتفعيل خاصية التقريب إلى الشبكة لتسهيل المحاذاة.</p>
            <div className="bg-gray-800 p-2 rounded mt-2">
              <p className="text-sm text-gray-300">اضغط على زر <span className="bg-gray-700 px-1 rounded">تفعيل التقريب إلى الشبكة</span> لجعل العناصر تلتصق تلقائيًا بخطوط الشبكة.</p>
            </div>
          </div>
        )}
        
        {showHelpTooltip === 'rulers' && (
          <div>
            <p className="mb-2">المساطر تساعدك على قياس المسافات والأبعاد بدقة على التصميم. تظهر المساطر على حواف التصميم وتعرض القياسات بالبكسل.</p>
            <div className="bg-gray-800 p-2 rounded mt-2">
              <p className="text-sm text-gray-300">استخدم المساطر مع خطوط التقاطع للحصول على قياسات دقيقة لموضع المؤشر.</p>
            </div>
          </div>
        )}
        
        {showHelpTooltip === 'crosshair' && (
          <div>
            <p className="mb-2">خطوط التقاطع تتبع حركة المؤشر وتعرض خطوطًا أفقية وعمودية تساعدك على محاذاة العناصر بدقة. كما تعرض إحداثيات الموضع الحالي للمؤشر.</p>
            <div className="bg-gray-800 p-2 rounded mt-2">
              <p className="text-sm text-gray-300">مثالية للمحاذاة الدقيقة وتحديد المواضع بالضبط على التصميم.</p>
            </div>
          </div>
        )}
        
        {showHelpTooltip === 'smartGuides' && (
          <div>
            <p className="mb-2">الخطوط الذكية تظهر تلقائيًا عند سحب العناصر لمساعدتك على محاذاتها مع عناصر أخرى. تساعدك على إنشاء تصميم متناسق ومنظم.</p>
            <div className="bg-gray-800 p-2 rounded mt-2">
              <p className="text-sm text-gray-300">العناصر ستلتصق تلقائيًا بالخطوط الذكية عند اقترابها منها، مما يسهل المحاذاة الدقيقة.</p>
            </div>
          </div>
        )}
        
        <div className="mt-3 text-center">
          <button 
            className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm transition-colors"
            onClick={() => setShowHelpTooltip(null)}
          >
            فهمت
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="preview-container relative border rounded-lg overflow-hidden bg-gradient-to-br from-gray-50 to-gray-100 mb-4 h-full">
      <div className="flex justify-between items-center p-3 bg-white border-b shadow-sm">
        <div className="flex items-center">
          <h3 className="text-lg font-semibold ml-2 text-gray-800">معاينة الربط</h3>
          <div className="flex items-center space-x-1 space-x-reverse">
            <button
              className={`btn btn-sm ${showGrid ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'} ml-1 relative group`}
              onClick={() => setShowGrid(!showGrid)}
              title={showGrid ? "إخفاء الشبكة" : "إظهار الشبكة"}
              onMouseEnter={() => setShowHelpTooltip('grid')}
              onMouseLeave={() => setShowHelpTooltip(null)}
            >
              <LayoutGrid className="h-4 w-4" />
            </button>
            <button
              className={`btn btn-sm ${showBindingLines ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'} ml-1`}
              onClick={() => setShowBindingLines(!showBindingLines)}
              title={showBindingLines ? "إخفاء خطوط الربط" : "إظهار خطوط الربط"}
            >
              <LinkIcon className="h-4 w-4" />
            </button>
            <button
              className={`btn btn-sm ${showRulers ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'} ml-1 relative group`}
              onClick={() => setShowRulers(!showRulers)}
              title={showRulers ? "إخفاء المساطر" : "إظهار المساطر"}
              onMouseEnter={() => setShowHelpTooltip('rulers')}
              onMouseLeave={() => setShowHelpTooltip(null)}
            >
              <Ruler className="h-4 w-4" />
            </button>
            <button
              className={`btn btn-sm ${showCrosshair ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'} ml-1 relative group`}
              onClick={() => setShowCrosshair(!showCrosshair)}
              title={showCrosshair ? "إخفاء خطوط التقاطع" : "إظهار خطوط التقاطع"}
              onMouseEnter={() => setShowHelpTooltip('crosshair')}
              onMouseLeave={() => setShowHelpTooltip(null)}
            >
              <Crosshair className="h-4 w-4" />
            </button>
            <button
              className={`btn btn-sm ${snapToGrid ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'} ml-1`}
              onClick={() => setSnapToGrid(!snapToGrid)}
              title={snapToGrid ? "إلغاء التقريب إلى الشبكة" : "تفعيل التقريب إلى الشبكة"}
            >
              <Grid className="h-4 w-4" />
            </button>
            <button
              className={`btn btn-sm ${showSmartGuides ? 'bg-green-500 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'} ml-1 relative group`}
              onClick={() => setShowSmartGuides(!showSmartGuides)}
              title={showSmartGuides ? "إخفاء الخطوط الذكية" : "إظهار الخطوط الذكية"}
              onMouseEnter={() => setShowHelpTooltip('smartGuides')}
              onMouseLeave={() => setShowHelpTooltip(null)}
            >
              <Move className="h-4 w-4" />
            </button>
            <button
              className={`btn btn-sm ${showLayerOrder ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'} ml-1`}
              onClick={() => setShowLayerOrder(!showLayerOrder)}
              title={showLayerOrder ? "إخفاء ترتيب الطبقات" : "إظهار ترتيب الطبقات"}
            >
              <Layers className="h-4 w-4" />
            </button>
            <button
              className={`btn btn-sm ${isLocked ? 'bg-red-500 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'} ml-1`}
              onClick={() => setIsLocked(!isLocked)}
              title={isLocked ? "إلغاء قفل المواضع" : "قفل المواضع"}
            >
              {isLocked ? <Lock className="h-4 w-4" /> : <Unlock className="h-4 w-4" />}
            </button>
          </div>
        </div>
        <div className="flex items-center">
          <div className="flex items-center bg-white rounded-md shadow-sm px-2 py-1 ml-4 border">
            <button
              className="btn btn-icon btn-sm text-gray-500 hover:text-gray-700"
              onClick={handlePrevPreviewRow}
              disabled={previewRowIndex === 0}
            >
              <ArrowRight className="h-4 w-4" />
            </button>
            <span className="mx-2 text-sm">
              صف {previewRowIndex + 1} من {excelData.rows.length}
            </span>
            <button
              className="btn btn-icon btn-sm text-gray-500 hover:text-gray-700"
              onClick={handleNextPreviewRow}
              disabled={previewRowIndex === excelData.rows.length - 1}
            >
              <ArrowLeft className="h-4 w-4" />
            </button>
          </div>
          <div className="flex items-center">
            <button
              className="btn btn-secondary btn-sm"
              onClick={() => setPreviewScale(Math.max(0.1, previewScale - 0.1))}
            >
              <ZoomOut className="h-4 w-4" />
            </button>
            <span className="mx-2 text-sm font-medium">{Math.round(previewScale * 100)}%</span>
            <button
              className="btn btn-secondary btn-sm"
              onClick={() => setPreviewScale(Math.min(2, previewScale + 0.1))}
            >
              <ZoomIn className="h-4 w-4" />
            </button>
            <button
              className="btn btn-secondary btn-sm mr-2"
              onClick={() => setPreviewScale(1)}
              title="إعادة ضبط التكبير"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
            <button
              className="btn btn-secondary btn-sm"
              onClick={toggleFullscreen}
              title={isFullscreen ? "الخروج من وضع ملء الشاشة" : "تفعيل وضع ملء الشاشة"}
            >
              {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* شريط أدوات إضافي للتحكم بالعمود */}
      {activeColumnSettings && (
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg shadow-sm p-2 m-3 flex items-center justify-between border border-blue-100">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 ml-2">
              <Type className="h-4 w-4" />
            </div>
            <span className="text-sm font-medium ml-2 text-blue-800">العمود النشط: <span className="font-bold">{activeColumnSettings}</span></span>
            <div className="flex items-center space-x-1 space-x-reverse mr-4">
              <button
                className={`btn btn-sm ${columnSettings[activeColumnSettings]?.textAlign === 'right' ? 'bg-blue-500 text-white' : 'bg-white text-gray-700 hover:bg-gray-100'} ml-1`}
                onClick={() => handleColumnSettingChange(activeColumnSettings, 'textAlign', 'right')}
                title="محاذاة لليمين"
              >
                <AlignRight className="h-4 w-4" />
              </button>
              <button
                className={`btn btn-sm ${columnSettings[activeColumnSettings]?.textAlign === 'center' ? 'bg-blue-500 text-white' : 'bg-white text-gray-700 hover:bg-gray-100'} ml-1`}
                onClick={() => handleColumnSettingChange(activeColumnSettings, 'textAlign', 'center')}
                title="محاذاة للوسط"
              >
                <AlignCenter className="h-4 w-4" />
              </button>
              <button
                className={`btn btn-sm ${columnSettings[activeColumnSettings]?.textAlign === 'left' ? 'bg-blue-500 text-white' : 'bg-white text-gray-700 hover:bg-gray-100'} ml-1`}
                onClick={() => handleColumnSettingChange(activeColumnSettings, 'textAlign', 'left')}
                title="محاذاة لليسار"
              >
                <AlignLeft className="h-4 w-4" />
              </button>
            </div>
          </div>
          <div className="flex items-center">
            <div className="flex items-center ml-4">
              <span className="text-sm ml-1 text-gray-700">حجم الخط:</span>
              <input
                type="number"
                className="number-input w-16 text-sm border border-gray-300 rounded px-2 py-1"
                value={columnSettings[activeColumnSettings]?.fontSize || 25}
                onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'fontSize', parseInt(e.target.value) || 25)}
                min="8"
                max="72"
              />
            </div>
            <div className="flex items-center ml-4 relative">
              <span className="text-sm ml-1 text-gray-700">اللون:</span>
              <div className="relative">
                <input
                  type="color"
                  className="color-picker w-8 h-8 rounded-md cursor-pointer"
                  value={columnSettings[activeColumnSettings]?.textColor || '#00AA00'}
                  onChange={(e) => handleColumnSettingChange(activeColumnSettings, 'textColor', e.target.value)}
                />
                <button
                  className="absolute -top-1 -right-1 bg-white rounded-full w-4 h-4 flex items-center justify-center shadow-sm border border-gray-200"
                  onClick={() => setShowColorPalette(!showColorPalette)}
                >
                  <Palette className="h-3 w-3 text-gray-500" />
                </button>
              </div>
              
              {/* لوحة ألوان سريعة */}
              {showColorPalette && (
                <div className="absolute top-full right-0 mt-1 bg-white p-2 rounded-md border border-gray-200 shadow-lg z-10 flex flex-wrap gap-1 w-32">
                  {suggestedColors.map(color => (
                    <button
                      key={color}
                      className="w-6 h-6 rounded-md border border-gray-300 transition-transform hover:scale-110"
                      style={{ backgroundColor: color }}
                      onClick={() => {
                        handleColumnSettingChange(activeColumnSettings, 'textColor', color);
                        setShowColorPalette(false);
                      }}
                      title={color}
                    />
                  ))}
                </div>
              )}
            </div>
            <button
              className="btn btn-primary btn-sm mr-2 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 border-0"
              onClick={() => setActiveTab('settings')}
            >
              <Sliders className="h-4 w-4 ml-1" />
              إعدادات متقدمة
            </button>
          </div>
        </div>
      )}

      {/* إعدادات الشبكة */}
      {showGrid && (
        <div className="bg-white rounded-lg shadow-sm p-2 m-3 flex items-center flex-wrap border border-gray-200">
          <div className="flex items-center ml-4">
            <span className="text-sm ml-2 text-gray-700">حجم الشبكة:</span>
            <input
              type="range"
              className="range-input w-32"
              min="5"
              max="50"
              step="5"
              value={gridSize}
              onChange={(e) => setGridSize(parseInt(e.target.value))}
            />
            <span className="text-sm mr-2 min-w-[40px] text-center font-medium">{gridSize}px</span>
          </div>
          
          <div className="mr-4 flex items-center">
            <input
              type="checkbox"
              id="show-column-labels"
              className="ml-1"
              checked={showColumnLabels}
              onChange={(e) => setShowColumnLabels(e.target.checked)}
            />
            <label htmlFor="show-column-labels" className="text-sm text-gray-700">إظهار أسماء الأعمدة</label>
          </div>
          
          <div className="mr-4 flex items-center">
            <input
              type="checkbox"
              id="highlight-active-column"
              className="ml-1"
              checked={highlightActiveColumn}
              onChange={(e) => setHighlightActiveColumn(e.target.checked)}
            />
            <label htmlFor="highlight-active-column" className="text-sm text-gray-700">تمييز العمود النشط</label>
          </div>
          
          <div className="mr-4 flex items-center">
            <input
              type="checkbox"
              id="show-element-bounds"
              className="ml-1"
              checked={showElementBounds}
              onChange={(e) => setShowElementBounds(e.target.checked)}
            />
            <label htmlFor="show-element-bounds" className="text-sm text-gray-700">إظهار حدود العنصر</label>
          </div>
          
          <div className="mr-4 flex items-center">
            <input
              type="checkbox"
              id="show-animations"
              className="ml-1"
              checked={showAnimations}
              onChange={(e) => setShowAnimations(e.target.checked)}
            />
            <label htmlFor="show-animations" className="text-sm text-gray-700">تفعيل الحركات</label>
          </div>
          
          <div className="mr-4 flex items-center">
            <input
              type="checkbox"
              id="show-performance"
              className="ml-1"
              checked={showPerformanceStats}
              onChange={(e) => setShowPerformanceStats(e.target.checked)}
            />
            <label htmlFor="show-performance" className="text-sm text-gray-700">إظهار إحصائيات الأداء</label>
          </div>
        </div>
      )}

      <div className="relative h-[calc(100%-3rem)] overflow-auto bg-white rounded-lg shadow-inner mx-3 mb-3" style={{ minHeight: '400px' }}>
        <Stage 
          ref={stageRef}
          width={design.width} 
          height={design.height} 
          scale={{ x: previewScale, y: previewScale }}
          className="bg-white"
          onMouseMove={handleMouseMove}
        >
          <Layer>
            {/* شبكة الخلفية */}
            {renderGrid()}
            
            {/* المساطر */}
            {renderRulers()}
            
            {/* خلفية التصميم */}
            <Rect
              x={0}
              y={0}
              width={design.width}
              height={design.height}
              fill={design.background}
              perfectDrawEnabled={false}
            />
            
            {/* الخطوط الذكية */}
            {renderSmartGuides()}
            
            {/* خطوط الربط */}
            {renderBindingLines()}
            
            {/* حدود العنصر المحدد */}
            {renderElementBounds()}
            
            {/* رسم العنصر الأساسي */}
            {renderElementPreview(selectedElement)}
            
            {/* رسم الأعمدة المرتبطة */}
             {selectedColumns.map(column => {
              const settings = columnSettings[column];
              const value = excelData.rows[previewRowIndex] ? excelData.rows[previewRowIndex][column] : undefined;
              const formattedValue = value !== undefined ? formatCellValue(value, settings.format) : column;
              const isActive = activeColumnSettings === column;
              
              return (
                <React.Fragment key={column}>
                  {/* نقطة موضع الربط */}
                  <Circle
                    x={settings.x}
                    y={settings.y}
                    radius={isActive && highlightActiveColumn ? 7 / previewScale : 5 / previewScale}
                    fill={isActive && highlightActiveColumn ? "rgba(59, 130, 246, 0.8)" : "rgba(59, 130, 246, 0.5)"}
                    stroke={isActive && highlightActiveColumn ? "#2563eb" : "#3b82f6"}
                    strokeWidth={(isActive && highlightActiveColumn ? 2 : 1) / previewScale}
                    onClick={() => {
                      setActiveColumnSettings(column);
                      setActiveTab('settings');
                    }}
                    draggable={!isLocked}
                    onDragMove={(e) => handleDragColumn(column, e)}
                    perfectDrawEnabled={false}
                    shadowColor={isActive ? "rgba(37, 99, 235, 0.5)" : undefined}
                    shadowBlur={isActive ? 10 : undefined}
                    shadowOpacity={isActive ? 0.5 : undefined}
                    shadowOffsetX={0}
                    shadowOffsetY={0}
                  />
                  
                  {/* نص العمود */}
                  <Text
                    x={settings.x}
                    y={settings.y}
                    text={formattedValue}
                    fontSize={settings.fontSize ? settings.fontSize / previewScale : 16 / previewScale}
                    fontFamily={settings.fontFamily || 'Tajawal'}
                    fill={settings.textColor || '#000000'}
                    align={settings.textAlign || 'right'}
                    width={settings.width ? settings.width / previewScale : undefined}
                    height={settings.height ? settings.height / previewScale : undefined}
                    rotation={settings.rotation || 0}
                    onClick={() => {
                      setActiveColumnSettings(column);
                      setActiveTab('settings');
                    }}
                    perfectDrawEnabled={false}
                    shadowColor={isActive ? "rgba(37, 99, 235, 0.3)" : undefined}
                    shadowBlur={isActive ? 5 : undefined}
                    shadowOpacity={isActive ? 0.5 : undefined}
                    shadowOffsetX={0}
                    shadowOffsetY={0}
                  />
                  
                  {/* اسم العمود */}
                  {showColumnLabels && (
                    <Group perfectDrawEnabled={false}>
                      <Rect
                        x={settings.x - 40}
                        y={settings.y - 25}
                        width={80}
                        height={20}
                        fill={isActive && highlightActiveColumn ? "rgba(37, 99, 235, 0.8)" : "rgba(59, 130, 246, 0.6)"}
                        cornerRadius={3}
                        perfectDrawEnabled={false}
                        shadowColor="rgba(0, 0, 0, 0.2)"
                        shadowBlur={3}
                        shadowOpacity={0.5}
                        shadowOffsetX={0}
                        shadowOffsetY={1}
                      />
                      <Text
                        x={settings.x - 35}
                        y={settings.y - 22}
                        text={column}
                        fontSize={10 / previewScale}
                        fill="white"
                        width={70}
                        align="center"
                        ellipsis={true}
                        perfectDrawEnabled={false}
                      />
                    </Group>
                  )}
                </React.Fragment>
              );
            })}
            
            {/* ترتيب الطبقات */}
            {renderLayerOrder()}
            
            {/* خطوط التقاطع */}
            {renderCrosshair()}
          </Layer>
        </Stage>
      </div>
      
      {/* رسائل إرشادية للخطوات التالية */}
      {renderNextStepsTips()}
      
      {/* إحصائيات الأداء */}
      {renderPerformanceStats()}
      
      {/* مساعدة للمستخدم */}
      {renderHelpTooltip()}
      
      {/* شريط معلومات في الأسفل */}
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-r from-gray-800 to-gray-900 text-white py-1 px-3 text-xs flex justify-between items-center">
        <div className="flex items-center">
          <Info className="h-3 w-3 ml-1 text-blue-400" />
          <span>اسحب نقاط الربط لتحديد موضع كل عمود على التصميم</span>
        </div>
        <div className="flex items-center">
          {selectedColumns.length > 0 ? (
            <>
              <CheckCircle className="h-3 w-3 ml-1 text-green-400" />
              <span>تم ربط {selectedColumns.length} أعمدة</span>
            </>
          ) : (
            <>
              <AlertTriangle className="h-3 w-3 ml-1 text-yellow-400" />
              <span>لم يتم ربط أي أعمدة بعد</span>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

// مكون لعرض الصورة في المعاينة
const ImagePreview = ({ src, x, y, width, height, opacity }: { src: string, x: number, y: number, width: number, height: number, opacity: number }) => {
  const [image] = useImage(src);
  return (
    <Image
      image={image}
      x={x}
      y={y}
      width={width}
      height={height}
      opacity={opacity}
      perfectDrawEnabled={false}
    />
  );
};

export default BindingPreview;