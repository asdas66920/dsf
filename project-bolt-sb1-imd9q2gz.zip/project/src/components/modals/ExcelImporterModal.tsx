import React from 'react';
import ExcelImporter from '../ExcelImporter';
import { useDesign } from '../../context/DesignContext';

const ExcelImporterModal: React.FC = () => {
  const { showExcelImporter, setShowExcelImporter, handleExcelImported } = useDesign();

  if (!showExcelImporter) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg w-1/2 max-w-xl">
        <h2 className="text-xl font-bold mb-4">استيراد ملف Excel</h2>
        <ExcelImporter onExcelImported={handleExcelImported} />
        <div className="mt-4 flex justify-end">
          <button
            className="btn btn-secondary"
            onClick={() => setShowExcelImporter(false)}
          >
            إلغاء
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExcelImporterModal;