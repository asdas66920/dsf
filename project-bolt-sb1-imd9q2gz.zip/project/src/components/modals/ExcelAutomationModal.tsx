import ExcelAutomationModal from './excel-automation';

export default ExcelAutomationModal;