import React from 'react';
import { FileSpreadsheet, Download, Info, Check } from 'lucide-react';
import * as XLSX from 'xlsx';

interface ExcelTemplateModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ExcelTemplateModal: React.FC<ExcelTemplateModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const downloadExcelTemplate = () => {
    // إنشاء بيانات Excel
    const excelData = [
      ['الاسم', 'البريد الإلكتروني', 'رقم الهاتف', 'المسمى الوظيفي', 'الشركة', 'العنوان', 'تاريخ الإصدار', 'رابط الصورة', 'رقم التسلسل'],
      ['أحمد محمد', 'ahmed@example.com', '+966501234567', 'مدير تنفيذي', 'شركة التقنية المتطورة', 'الرياض، المملكة العربية السعودية', '15/05/2025', 'https://images.unsplash.com/photo-1560250097-0b93528c311a', '12345'],
      ['سارة علي', 'sara@example.com', '+966501234568', 'مديرة تسويق', 'شركة الإبداع', 'جدة، المملكة العربية السعودية', '20/06/2025', 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2', '12346'],
      ['محمد خالد', 'mohammed@example.com', '+966501234569', 'مطور برمجيات', 'شركة البرمجيات الحديثة', 'الدمام، المملكة العربية السعودية', '25/07/2025', 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7', '12347']
    ];

    // إنشاء ورقة عمل
    const ws = XLSX.utils.aoa_to_sheet(excelData);
    
    // إنشاء ورقة تعليمات
    const instructionsData = [
      ['تعليمات استخدام نموذج البيانات'],
      [''],
      ['1. كيفية استخدام هذا النموذج:'],
      ['- أدخل بياناتك في الأعمدة المناسبة في ورقة "البيانات"'],
      ['- تأكد من الحفاظ على أسماء الأعمدة كما هي'],
      ['- يمكنك إضافة أعمدة جديدة حسب احتياجاتك'],
      [''],
      ['2. وصف الأعمدة:'],
      ['الاسم: اسم الشخص أو العنوان الرئيسي'],
      ['البريد الإلكتروني: عنوان البريد الإلكتروني'],
      ['رقم الهاتف: رقم الهاتف مع رمز الدولة'],
      ['المسمى الوظيفي: المسمى الوظيفي أو المنصب'],
      ['الشركة: اسم الشركة أو المؤسسة'],
      ['العنوان: العنوان البريدي'],
      ['تاريخ الإصدار: تاريخ إصدار الشهادة أو البطاقة'],
      ['رابط الصورة: رابط لصورة شخصية أو شعار (يجب أن يكون URL كامل)'],
      ['رقم التسلسل: رقم تسلسلي للبطاقة أو الشهادة']
    ];
    const wsInstructions = XLSX.utils.aoa_to_sheet(instructionsData);
    
    // إنشاء ورقة أمثلة
    const examplesData = [
      ['أمثلة على استخدام البيانات في التصميم'],
      [''],
      ['1. بطاقات أعمال:'],
      ['- استخدم الاسم والمسمى الوظيفي والشركة ورقم الهاتف والبريد الإلكتروني'],
      ['- يمكن استخدام رابط الصورة لشعار الشركة'],
      [''],
      ['2. شهادات:'],
      ['- استخدم الاسم وتاريخ الإصدار ورقم التسلسل'],
      ['- يمكن استخدام رابط الصورة لشعار المؤسسة أو توقيع'],
      [''],
      ['3. دعوات:'],
      ['- استخدم الاسم والعنوان والتاريخ'],
      ['- يمكن استخدام رابط الصورة لصورة المناسبة']
    ];
    const wsExamples = XLSX.utils.aoa_to_sheet(examplesData);
    
    // إنشاء ورقة الأخطاء الشائعة
    const errorsData = [
      ['الأخطاء الشائعة وكيفية تجنبها'],
      [''],
      ['1. تغيير أسماء الأعمدة:'],
      ['- لا تقم بتغيير أسماء الأعمدة الموجودة في الصف الأول'],
      ['- يمكنك إضافة أعمدة جديدة مع الحفاظ على الأعمدة الأصلية'],
      [''],
      ['2. روابط الصور:'],
      ['- تأكد من أن روابط الصور صحيحة وقابلة للوصول'],
      ['- يجب أن تبدأ الروابط بـ http:// أو https://'],
      ['- تأكد من أن الصور متاحة للاستخدام العام'],
      [''],
      ['3. تنسيق التواريخ:'],
      ['- استخدم تنسيق موحد للتواريخ مثل DD/MM/YYYY'],
      ['- تأكد من أن التواريخ صحيحة ومنطقية']
    ];
    const wsErrors = XLSX.utils.aoa_to_sheet(errorsData);
    
    // إنشاء مصنف عمل
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "البيانات");
    XLSX.utils.book_append_sheet(wb, wsInstructions, "تعليمات");
    XLSX.utils.book_append_sheet(wb, wsExamples, "أمثلة");
    XLSX.utils.book_append_sheet(wb, wsErrors, "الأخطاء الشائعة");
    
    // تعيين اتجاه الكتابة من اليمين إلى اليسار
    ws['!dir'] = 'rtl';
    wsInstructions['!dir'] = 'rtl';
    wsExamples['!dir'] = 'rtl';
    wsErrors['!dir'] = 'rtl';
    
    // تنزيل الملف
    XLSX.writeFile(wb, "نموذج-ملف-البيانات.xlsx");
    
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg w-3/4 max-w-3xl max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 ml-3">
              <FileSpreadsheet className="h-5 w-5" />
            </div>
            <h2 className="text-xl font-bold">نموذج ملف Excel للاستيراد</h2>
          </div>
          <button
            className="btn btn-secondary"
            onClick={onClose}
          >
            إغلاق
          </button>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <div className="flex items-start">
            <Info className="h-5 w-5 text-blue-500 ml-2 mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-blue-700 mb-1">تعليمات استخدام نموذج Excel</h3>
              <p className="text-blue-600 text-sm">
                استخدم هذا النموذج لإعداد بياناتك بالتنسيق الصحيح لاستيرادها في المنصة. يحتوي النموذج على أمثلة توضيحية وتعليمات مفصلة.
              </p>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <h3 className="font-semibold text-lg mb-3">محتويات النموذج</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border rounded-lg p-4 bg-gray-50">
              <h4 className="font-medium text-gray-700 mb-2 flex items-center">
                <Check className="h-4 w-4 text-green-500 ml-2" />
                ورقة البيانات الرئيسية
              </h4>
              <p className="text-sm text-gray-600">
                تحتوي على أعمدة البيانات الأساسية مع أمثلة توضيحية. استخدم هذه الورقة لإدخال بياناتك.
              </p>
            </div>
            <div className="border rounded-lg p-4 bg-gray-50">
              <h4 className="font-medium text-gray-700 mb-2 flex items-center">
                <Check className="h-4 w-4 text-green-500 ml-2" />
                ورقة التعليمات
              </h4>
              <p className="text-sm text-gray-600">
                تحتوي على شرح مفصل لكل عمود وكيفية إدخال البيانات بالشكل الصحيح.
              </p>
            </div>
            <div className="border rounded-lg p-4 bg-gray-50">
              <h4 className="font-medium text-gray-700 mb-2 flex items-center">
                <Check className="h-4 w-4 text-green-500 ml-2" />
                ورقة الأمثلة
              </h4>
              <p className="text-sm text-gray-600">
                تحتوي على أمثلة متنوعة لمختلف أنواع التصاميم والبيانات.
              </p>
            </div>
            <div className="border rounded-lg p-4 bg-gray-50">
              <h4 className="font-medium text-gray-700 mb-2 flex items-center">
                <Check className="h-4 w-4 text-green-500 ml-2" />
                ورقة الأخطاء الشائعة
              </h4>
              <p className="text-sm text-gray-600">
                توضح الأخطاء الشائعة عند إعداد البيانات وكيفية تجنبها.
              </p>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <h3 className="font-semibold text-lg mb-3">تنسيق البيانات المطلوب</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-2 text-right">اسم العمود</th>
                  <th className="border border-gray-300 p-2 text-right">نوع البيانات</th>
                  <th className="border border-gray-300 p-2 text-right">وصف</th>
                  <th className="border border-gray-300 p-2 text-right">مثال</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-gray-300 p-2">الاسم</td>
                  <td className="border border-gray-300 p-2">نص</td>
                  <td className="border border-gray-300 p-2">اسم الشخص أو العنوان</td>
                  <td className="border border-gray-300 p-2">أحمد محمد</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2">البريد الإلكتروني</td>
                  <td className="border border-gray-300 p-2">نص</td>
                  <td className="border border-gray-300 p-2">عنوان البريد الإلكتروني</td>
                  <td className="border border-gray-300 p-2">example@example.com</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2">رقم الهاتف</td>
                  <td className="border border-gray-300 p-2">نص</td>
                  <td className="border border-gray-300 p-2">رقم الهاتف مع رمز الدولة</td>
                  <td className="border border-gray-300 p-2">+966501234567</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2">المسمى الوظيفي</td>
                  <td className="border border-gray-300 p-2">نص</td>
                  <td className="border border-gray-300 p-2">المسمى الوظيفي أو المنصب</td>
                  <td className="border border-gray-300 p-2">مدير تنفيذي</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2">الشركة</td>
                  <td className="border border-gray-300 p-2">نص</td>
                  <td className="border border-gray-300 p-2">اسم الشركة أو المؤسسة</td>
                  <td className="border border-gray-300 p-2">شركة التقنية المتطورة</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2">العنوان</td>
                  <td className="border border-gray-300 p-2">نص</td>
                  <td className="border border-gray-300 p-2">العنوان البريدي</td>
                  <td className="border border-gray-300 p-2">الرياض، المملكة العربية السعودية</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2">تاريخ الإصدار</td>
                  <td className="border border-gray-300 p-2">تاريخ</td>
                  <td className="border border-gray-300 p-2">تاريخ إصدار الشهادة أو البطاقة</td>
                  <td className="border border-gray-300 p-2">15/05/2025</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2">رابط الصورة</td>
                  <td className="border border-gray-300 p-2">نص (URL)</td>
                  <td className="border border-gray-300 p-2">رابط لصورة شخصية أو شعار</td>
                  <td className="border border-gray-300 p-2">https://images.unsplash.com/photo-1560250097-0b93528c311a</td>
                </tr>
                <tr>
                  <td className="border border-gray-300 p-2">رقم التسلسل</td>
                  <td className="border border-gray-300 p-2">رقم</td>
                  <td className="border border-gray-300 p-2">رقم تسلسلي للبطاقة أو الشهادة</td>
                  <td className="border border-gray-300 p-2">12345</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="mb-6">
          <h3 className="font-semibold text-lg mb-3">إرشادات مهمة</h3>
          <ul className="list-disc list-inside space-y-2 text-gray-700">
            <li>تأكد من أن الصف الأول يحتوي على أسماء الأعمدة بالضبط كما هي موضحة في الجدول أعلاه.</li>
            <li>لا تقم بتغيير أسماء الأعمدة أو ترتيبها في النموذج.</li>
            <li>يمكنك إضافة أعمدة إضافية حسب احتياجاتك، وستظهر كخيارات إضافية عند ربط البيانات.</li>
            <li>تأكد من أن جميع البيانات المطلوبة مدخلة بشكل صحيح قبل الاستيراد.</li>
            <li>للحصول على أفضل النتائج، استخدم تنسيق Excel (.xlsx).</li>
            <li>يدعم النموذج اللغة العربية بشكل كامل، وتم ضبط اتجاه الكتابة من اليمين إلى اليسار.</li>
          </ul>
        </div>

        <div className="text-center">
          <button
            className="btn btn-primary"
            onClick={downloadExcelTemplate}
          >
            <Download className="h-5 w-5 ml-2" />
            تنزيل نموذج البيانات
          </button>
        </div>
      </div>
    </div>
  );
};

export default ExcelTemplateModal;