import React, { useState, useRef } from 'react';
import { Upload, Image as ImageIcon, AlertCircle } from 'lucide-react';

interface DesignImporterProps {
  onDesignImported: (file: File, width: number, height: number) => void;
}

const DesignImporter: React.FC<DesignImporterProps> = ({ onDesignImported }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      processFile(files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      processFile(files[0]);
    }
  };

  const processFile = (file: File) => {
    if (!file.type.match(/image\/(jpeg|jpg|png|svg\+xml)/)) {
      setError('يرجى تحميل صورة صالحة (.jpg, .png, .svg)');
      setPreview(null);
      return;
    }

    setError(null);
    
    // إنشاء معاينة للصورة وقراءة أبعادها
    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target && e.target.result) {
        const imageUrl = e.target.result as string;
        setPreview(imageUrl);
        
        // إنشاء صورة مؤقتة لمعرفة أبعاد الصورة
        const imgElement = document.createElement('img');
        imgElement.onload = () => {
          // تمرير أبعاد الصورة مع الملف
          onDesignImported(file, imgElement.width, imgElement.height);
        };
        imgElement.src = imageUrl;
      }
    };
    reader.readAsDataURL(file);
  };

  const handleButtonClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="w-full">
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center ${
          isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {preview ? (
          <div className="mb-4">
            <img 
              src={preview} 
              alt="معاينة التصميم" 
              className="max-h-48 mx-auto object-contain"
            />
          </div>
        ) : (
          <ImageIcon className="mx-auto h-12 w-12 text-gray-400" />
        )}
        
        <h3 className="mt-2 text-sm font-semibold text-gray-900">استيراد تصميم</h3>
        <p className="mt-1 text-xs text-gray-500">
          اسحب وأفلت صورة أو ملف SVG هنا، أو انقر لتحديد ملف
        </p>
        <div className="mt-4">
          <button
            type="button"
            className="btn btn-primary"
            onClick={handleButtonClick}
          >
            <Upload className="h-4 w-4 ml-2" />
            <span>تحميل تصميم</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            accept="image/jpeg,image/png,image/svg+xml"
            onChange={handleFileChange}
          />
        </div>
        {error && (
          <div className="mt-4 text-sm text-red-500 flex items-center justify-center">
            <AlertCircle className="h-4 w-4 ml-1" />
            {error}
          </div>
        )}
      </div>
    </div>
  );
};

export default DesignImporter;