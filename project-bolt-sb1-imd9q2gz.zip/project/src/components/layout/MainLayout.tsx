import React, { useState } from 'react';
import Toolbar from '../Toolbar';
import DesignCanvas from '../DesignCanvas';
import PropertyPanel from '../PropertyPanel';
import LayersPanel from '../LayersPanel';
import ExcelDataPanel from '../ExcelDataPanel';
import GenerationPanel from '../GenerationPanel';
import ExcelImporterModal from '../modals/ExcelImporterModal';
import DesignImporterModal from '../modals/DesignImporterModal';
import SaveDesignModal from '../modals/SaveDesignModal';
import TemplatesModal from '../modals/TemplatesModal';
import ExcelTemplateModal from '../modals/ExcelTemplateModal';
import { useDesign } from '../../context/DesignContext';

const MainLayout: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'layers' | 'properties' | 'excel'>('layers');
  
  const { 
    design, 
    selectedElement, 
    excelData, 
    showGenerationPanel,
    showSaveModal,
    showTemplatesModal,
    showExcelTemplateModal,
    canUndo,
    canRedo,
    setSelectedElement, 
    setShowSaveModal,
    setShowTemplatesModal,
    setShowExcelTemplateModal,
    handleAddText, 
    handleAddRect, 
    handleAddCircle, 
    handleAddImage, 
    handleDuplicate, 
    handleDelete, 
    handleUpdateElement, 
    handleReorderElements, 
    handleSave, 
    handleSaveDesign,
    handleExport, 
    handleExportDesign,
    handleDuplicateDesign,
    handleImportDesign, 
    handleImportExcel, 
    handleOpenTemplates,
    handleOpenExcelTemplate,
    handleApplyTemplate,
    handleDeleteTemplate,
    handleSelectSheet, 
    handleGenerate,
    handleUndo,
    handleRedo
  } = useDesign();

  // عند تحديد عنصر، ننتقل تلقائيًا إلى تبويب الخصائص
  React.useEffect(() => {
    if (selectedElement) {
      setActiveTab('properties');
    }
  }, [selectedElement]);

  // معاينة التصميم قبل التوليد
  const handlePreviewDesign = () => {
    // تنفيذ المعاينة من خلال GenerationPanel
    // هذه الدالة ستمرر إلى GenerationPanel
  };

  return (
    <div className="flex flex-col h-screen bg-gray-100">
      <Toolbar
        onAddText={handleAddText}
        onAddRect={handleAddRect}
        onAddCircle={handleAddCircle}
        onAddImage={handleAddImage}
        onDuplicate={handleDuplicate}
        onDelete={handleDelete}
        onSave={handleSave}
        onExport={handleExport}
        onImportDesign={handleImportDesign}
        onImportExcel={handleImportExcel}
        onOpenTemplates={handleOpenTemplates}
        onUndo={handleUndo}
        onRedo={handleRedo}
        canUndo={canUndo}
        canRedo={canRedo}
        selectedElement={selectedElement}
        design={design}
      />
      
      <div className="flex flex-1 overflow-hidden">
        <div className="w-64 bg-white overflow-y-auto flex flex-col">
          {/* تبويبات للتنقل بين الطبقات والخصائص */}
          <div className="flex border-b">
            <button
              className={`flex-1 py-2 px-4 text-center ${activeTab === 'layers' ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-500' : 'text-gray-600 hover:bg-gray-50'}`}
              onClick={() => setActiveTab('layers')}
            >
              الطبقات
            </button>
            <button
              className={`flex-1 py-2 px-4 text-center ${activeTab === 'properties' ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-500' : 'text-gray-600 hover:bg-gray-50'}`}
              onClick={() => setActiveTab('properties')}
              disabled={!selectedElement}
            >
              الخصائص
            </button>
            {excelData && (
              <button
                className={`flex-1 py-2 px-4 text-center ${activeTab === 'excel' ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-500' : 'text-gray-600 hover:bg-gray-50'}`}
                onClick={() => setActiveTab('excel')}
              >
                البيانات
              </button>
            )}
          </div>
          
          {/* عرض المحتوى حسب التبويب النشط */}
          <div className="flex-grow overflow-y-auto">
            {activeTab === 'layers' && (
              <LayersPanel
                elements={design.elements}
                selectedElement={selectedElement}
                onSelectElement={setSelectedElement}
                onUpdateElement={handleUpdateElement}
                onDeleteElement={handleDelete}
                onReorderElements={handleReorderElements}
              />
            )}
            
            {activeTab === 'properties' && selectedElement && (
              <PropertyPanel
                selectedElement={selectedElement}
                onUpdateElement={handleUpdateElement}
                onDeleteElement={handleDelete}
                excelData={excelData}
              />
            )}
            
            {activeTab === 'excel' && excelData && (
              <div className="h-full flex flex-col">
                <div className="flex-none p-4">
                  <ExcelDataPanel
                    excelData={excelData}
                    onSelectSheet={handleSelectSheet}
                    onPreviewDesign={handlePreviewDesign}
                  />
                </div>
                
                {showGenerationPanel && (
                  <div className="flex-1 overflow-y-auto">
                    <GenerationPanel
                      design={design}
                      excelData={excelData}
                      onGenerate={handleGenerate}
                      onUpdateElement={handleUpdateElement}
                    />
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
        
        <div className="flex-1 p-4 overflow-hidden">
          <div className="h-full flex items-center justify-center">
            <DesignCanvas
              design={design}
              selectedElement={selectedElement}
              onSelectElement={setSelectedElement}
              onUpdateElement={handleUpdateElement}
            />
          </div>
        </div>
        
        <div className="w-80 bg-white overflow-y-auto">
          <PropertyPanel
            selectedElement={selectedElement}
            onUpdateElement={handleUpdateElement}
            onDeleteElement={handleDelete}
            excelData={excelData}
          />
        </div>
      </div>
      
      <ExcelImporterModal />
      <DesignImporterModal />
      
      {showSaveModal && (
        <SaveDesignModal
          design={design}
          onClose={() => setShowSaveModal(false)}
          onSave={handleSaveDesign}
          onExport={handleExportDesign}
          onDuplicate={handleDuplicateDesign}
        />
      )}

      {showTemplatesModal && (
        <TemplatesModal
          onClose={() => setShowTemplatesModal(false)}
          onApplyTemplate={handleApplyTemplate}
          onDeleteTemplate={handleDeleteTemplate}
        />
      )}

      {showExcelTemplateModal && (
        <ExcelTemplateModal
          isOpen={showExcelTemplateModal}
          onClose={() => setShowExcelTemplateModal(false)}
        />
      )}
    </div>
  );
};

export default MainLayout;