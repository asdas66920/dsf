import React, { useState, useEffect, useRef } from 'react';
import { Design, ExcelData, GenerationSettings, GeneratedDesign, CanvasElement } from '../types';
import { FileDown, Settings, Image as ImageIcon, Loader, Check, AlertCircle, Link, Eye, Table, RefreshCw, Columns, Search, Filter, ArrowRight, ArrowLeft, SlidersHorizontal, Zap, Cpu, Clock, BarChart2 } from 'lucide-react';
import { downloadAllGeneratedDesigns, downloadSingleGeneratedDesign, designToImage } from '../utils/designUtils';
import { LoadingSpinner } from '../components';
import { useNotification } from '../context';
import ExcelAutomationModal from './modals/excel-automation';

interface GenerationPanelProps {
  design: Design;
  excelData: ExcelData | null;
  onGenerate: (settings: GenerationSettings) => Promise<GeneratedDesign[]>;
  onUpdateElement: (element: CanvasElement) => void;
}

const GenerationPanel: React.FC<GenerationPanelProps> = ({
  design,
  excelData,
  onGenerate,
  onUpdateElement,
}) => {
  const [settings, setSettings] = useState<GenerationSettings>({
    outputFormat: 'png',
    quality: 90,
    generateFor: 'all',
    fileName: 'design',
  });
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedDesigns, setGeneratedDesigns] = useState<GeneratedDesign[]>([]);
  const [showSettings, setShowSettings] = useState(true);
  const [showAutomationModal, setShowAutomationModal] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(6);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDownloading, setIsDownloading] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewRowIndex, setPreviewRowIndex] = useState(0);
  const [performanceStats, setPerformanceStats] = useState({
    generationTime: 0,
    averageTimePerDesign: 0,
    memoryUsage: 0,
  });
  
  const { showNotification } = useNotification();
  const previewRef = useRef<HTMLDivElement>(null);

  // إعادة تعيين الصفحة الحالية عند تغيير البحث
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm]);

  // تحديث إحصائيات الأداء
  useEffect(() => {
    if (generatedDesigns.length > 0 && performanceStats.generationTime > 0) {
      setPerformanceStats(prev => ({
        ...prev,
        averageTimePerDesign: prev.generationTime / generatedDesigns.length,
      }));
    }
  }, [generatedDesigns, performanceStats.generationTime]);

  const handleSettingsChange = (key: keyof GenerationSettings, value: any) => {
    setSettings((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const handleGenerate = async () => {
    if (!excelData) return;
    
    setIsGenerating(true);
    const startTime = performance.now();
    
    try {
      const designs = await onGenerate(settings);
      setGeneratedDesigns(designs);
      setShowSettings(false);
      
      const endTime = performance.now();
      setPerformanceStats(prev => ({
        ...prev,
        generationTime: endTime - startTime,
        memoryUsage: window.performance && (performance as any).memory ? 
          Math.round((performance as any).memory.usedJSHeapSize / (1024 * 1024)) : 0,
      }));
      
      if (designs.length > 0) {
        showNotification('تم توليد التصاميم بنجاح', 'success');
      } else {
        showNotification('لم يتم توليد أي تصاميم', 'error');
      }
    } catch (error) {
      console.error('Error generating designs:', error);
      showNotification('حدث خطأ أثناء توليد التصاميم', 'error');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownloadAll = async () => {
    if (generatedDesigns.length === 0) return;
    
    setIsDownloading(true);
    
    try {
      const success = await downloadAllGeneratedDesigns(
        generatedDesigns,
        settings.outputFormat as 'png' | 'jpeg',
        settings.fileName
      );
      
      if (success) {
        showNotification('تم تنزيل جميع التصاميم بنجاح', 'success');
      } else {
        showNotification('حدث خطأ أثناء تنزيل التصاميم', 'error');
      }
    } catch (error) {
      showNotification('حدث خطأ أثناء تنزيل التصاميم', 'error');
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDownloadSingle = async (design: GeneratedDesign) => {
    try {
      const success = await downloadSingleGeneratedDesign(
        design,
        settings.outputFormat as 'png' | 'jpeg',
        settings.fileName
      );
      
      if (success) {
        showNotification(`تم تنزيل التصميم للصف ${design.rowIndex + 1} بنجاح`, 'success');
      } else {
        showNotification('حدث خطأ أثناء تنزيل التصميم', 'error');
      }
    } catch (error) {
      showNotification('حدث خطأ أثناء تنزيل التصميم', 'error');
    }
  };

  // معاينة التصميم قبل التوليد
  const handlePreviewDesign = async () => {
    if (!excelData || excelData.rows.length === 0) return;
    
    setPreviewLoading(true);
    setShowPreview(true);
    
    try {
      // استخدام نفس الدالة التي تستخدم لتوليد التصاميم ولكن لصف واحد فقط
      const previewImage = await designToImage(design, 'png', 100);
      setPreviewImage(previewImage);
    } catch (error) {
      console.error('Error generating preview:', error);
      showNotification('حدث خطأ أثناء إنشاء المعاينة', 'error');
    } finally {
      setPreviewLoading(false);
    }
  };

  // تغيير صف المعاينة
  const handleChangePreviewRow = (direction: 'next' | 'prev') => {
    if (!excelData) return;
    
    if (direction === 'next' && previewRowIndex < excelData.rows.length - 1) {
      setPreviewRowIndex(prev => prev + 1);
    } else if (direction === 'prev' && previewRowIndex > 0) {
      setPreviewRowIndex(prev => prev - 1);
    }
    
    // إعادة توليد المعاينة
    handlePreviewDesign();
  };

  // إغلاق نافذة المعاينة
  const handleClosePreview = () => {
    setShowPreview(false);
    setPreviewImage(null);
  };

  // تصفية التصاميم المولدة حسب البحث
  const filteredDesigns = generatedDesigns.filter(design => {
    if (!searchTerm || !excelData) return true;
    
    // البحث في بيانات الصف
    const rowData = excelData.rows[design.rowIndex];
    if (!rowData) return false;
    
    return Object.values(rowData).some(value => 
      String(value).toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  // تقسيم التصاميم إلى صفحات
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentDesigns = filteredDesigns.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(filteredDesigns.length / itemsPerPage);

  // التنقل بين الصفحات
  const paginate = (pageNumber: number) => setCurrentPage(pageNumber);
  const nextPage = () => setCurrentPage(prev => Math.min(prev + 1, totalPages));
  const prevPage = () => setCurrentPage(prev => Math.max(prev - 1, 1));

  // عرض عدد الروابط في التصميم
  const getBindingCount = (element: CanvasElement) => {
    if (!element.dataBinding) return 0;
    return Array.isArray(element.dataBinding) ? element.dataBinding.length : 1;
  };

  // حساب إجمالي عدد الروابط في التصميم
  const getTotalBindings = () => {
    return design.elements.reduce((total, element) => {
      return total + getBindingCount(element);
    }, 0);
  };

  // التحقق من وجود روابط في التصميم
  const hasBindings = getTotalBindings() > 0;

  if (!excelData) {
    return (
      <div className="p-8 text-center bg-gray-50 rounded-lg shadow-sm">
        <FileDown className="h-16 w-16 text-gray-300 mx-auto mb-4" />
        <h3 className="text-xl font-bold text-gray-700 mb-2">يرجى استيراد ملف Excel أولاً</h3>
        <p className="text-gray-500 mb-6">لتوليد التصاميم، يجب استيراد ملف Excel يحتوي على البيانات المطلوبة</p>
        <button className="btn btn-primary">
          <Table className="h-5 w-5 ml-2" />
          استيراد ملف Excel
        </button>
      </div>
    );
  }

  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 ml-3">
            <RefreshCw className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-xl font-bold">توليد التصاميم</h3>
            <p className="text-sm text-gray-500">
              {excelData.rows.length} صف, {excelData.headers.length} عمود
            </p>
          </div>
        </div>
        <div className="flex space-x-2 space-x-reverse">
          <button
            className="btn btn-secondary"
            onClick={() => setShowSettings(!showSettings)}
          >
            {showSettings ? 'إخفاء الإعدادات' : 'عرض الإعدادات'}
          </button>
          <button
            className="btn btn-secondary"
            onClick={handlePreviewDesign}
            title="معاينة التصميم قبل التوليد"
          >
            <Eye className="h-5 w-5 ml-2" />
            معاينة التصميم
          </button>
          <button
            className="btn btn-primary"
            onClick={() => setShowAutomationModal(true)}
          >
            <Link className="h-5 w-5 ml-2" />
            إعدادات الربط والأتمتة
          </button>
        </div>
      </div>
      
      {!hasBindings && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6 flex items-center">
          <AlertCircle className="h-6 w-6 text-amber-500 ml-3 flex-shrink-0" />
          <div>
            <h4 className="font-semibold text-amber-700 mb-1">لم يتم ربط أي عناصر بالبيانات</h4>
            <p className="text-amber-600 text-sm">
              لتوليد تصاميم متعددة، يجب ربط عناصر التصميم بأعمدة البيانات. انقر على "إعدادات الربط والأتمتة" لإعداد الروابط.
            </p>
          </div>
        </div>
      )}
      
      {showSettings && (
        <div className="mb-6 bg-white p-6 rounded-lg shadow-sm border border-gray-100">
          <div className="flex items-center mb-4">
            <Settings className="h-5 w-5 text-blue-500 ml-2" />
            <h4 className="text-lg font-semibold">إعدادات التوليد</h4>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  تنسيق الإخراج
                </label>
                <select
                  className="select-input"
                  value={settings.outputFormat}
                  onChange={(e) => handleSettingsChange('outputFormat', e.target.value)}
                >
                  <option value="png">PNG</option>
                  <option value="jpeg">JPEG</option>
                  <option value="pdf">PDF</option>
                </select>
              </div>
              
              {settings.outputFormat !== 'pdf' && (
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    الجودة: {settings.quality}%
                  </label>
                  <div className="flex items-center">
                    <input
                      type="range"
                      className="range-input flex-grow"
                      min="10"
                      max="100"
                      value={settings.quality}
                      onChange={(e) => handleSettingsChange('quality', parseInt(e.target.value))}
                    />
                    <span className="mr-2 text-sm w-10 text-center">{settings.quality}%</span>
                  </div>
                </div>
              )}
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  تحسين الأداء
                </label>
                <div className="flex items-center mb-2">
                  <input
                    type="checkbox"
                    id="optimize-memory"
                    className="ml-2"
                    checked={settings.optimizeMemory || false}
                    onChange={(e) => handleSettingsChange('optimizeMemory', e.target.checked)}
                  />
                  <label htmlFor="optimize-memory" className="text-sm text-gray-600">
                    تحسين استخدام الذاكرة
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="parallel-processing"
                    className="ml-2"
                    checked={settings.parallelProcessing || false}
                    onChange={(e) => handleSettingsChange('parallelProcessing', e.target.checked)}
                  />
                  <label htmlFor="parallel-processing" className="text-sm text-gray-600">
                    معالجة متوازية (أسرع ولكن تستهلك ذاكرة أكثر)
                  </label>
                </div>
              </div>
            </div>
            
            <div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  توليد لـ
                </label>
                <select
                  className="select-input"
                  value={settings.generateFor}
                  onChange={(e) => handleSettingsChange('generateFor', e.target.value)}
                >
                  <option value="all">جميع الصفوف ({excelData.rows.length})</option>
                  <option value="selected">صفوف محددة</option>
                </select>
              </div>
              
              {settings.generateFor === 'selected' && (
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    نطاق الصفوف (مثال: 1-10)
                  </label>
                  <input
                    type="text"
                    className="text-input"
                    placeholder="1-10"
                    onChange={(e) => {
                      const range = e.target.value.split('-').map(Number);
                      if (range.length === 2 && !isNaN(range[0]) && !isNaN(range[1])) {
                        handleSettingsChange('selectedRange', [range[0] - 1, range[1] - 1]);
                      }
                    }}
                  />
                </div>
              )}
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  اسم الملف
                </label>
                <input
                  type="text"
                  className="text-input"
                  value={settings.fileName}
                  onChange={(e) => handleSettingsChange('fileName', e.target.value)}
                />
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  خيارات متقدمة
                </label>
                <div className="flex items-center mb-2">
                  <input
                    type="checkbox"
                    id="add-metadata"
                    className="ml-2"
                    checked={settings.addMetadata || false}
                    onChange={(e) => handleSettingsChange('addMetadata', e.target.checked)}
                  />
                  <label htmlFor="add-metadata" className="text-sm text-gray-600">
                    إضافة بيانات وصفية للملفات
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="create-log"
                    className="ml-2"
                    checked={settings.createLog || false}
                    onChange={(e) => handleSettingsChange('createLog', e.target.checked)}
                  />
                  <label htmlFor="create-log" className="text-sm text-gray-600">
                    إنشاء ملف سجل للتوليد
                  </label>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-4 flex justify-end">
            <button
              className="btn btn-primary w-64"
              onClick={handleGenerate}
              disabled={isGenerating || !hasBindings}
            >
              {isGenerating ? (
                <>
                  <LoadingSpinner size="sm" color="white" className="ml-2" />
                  جاري التوليد...
                </>
              ) : (
                <>
                  <ImageIcon className="h-5 w-5 ml-2" />
                  توليد التصاميم
                </>
              )}
            </button>
          </div>
          
          {!hasBindings && (
            <div className="mt-4 text-center text-sm text-red-500">
              يجب ربط عناصر التصميم بالبيانات أولاً قبل توليد التصاميم
            </div>
          )}
        </div>
      )}
      
      {generatedDesigns.length > 0 && (
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center">
              <Eye className="h-5 w-5 text-purple-500 ml-2" />
              <h4 className="font-semibold text-lg">التصاميم المولدة ({filteredDesigns.length})</h4>
            </div>
            <div className="flex items-center">
              <div className="relative ml-4">
                <input
                  type="text"
                  className="text-input pr-8"
                  placeholder="بحث في التصاميم..."
                  value={searchTerm}
                  onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setCurrentPage(1); // إعادة تعيين الصفحة عند البحث
                  }}
                />
                <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              </div>
              <button
                className="btn btn-primary"
                onClick={handleDownloadAll}
                disabled={isDownloading}
              >
                {isDownloading ? (
                  <>
                    <LoadingSpinner size="sm" color="white" className="ml-2" />
                    جاري التنزيل...
                  </>
                ) : (
                  <>
                    <FileDown className="h-5 w-5 ml-2" />
                    تنزيل الكل
                  </>
                )}
              </button>
            </div>
          </div>
          
          {/* إحصائيات الأداء */}
          <div className="mb-6 p-3 bg-blue-50 rounded-lg border border-blue-100 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 ml-3">
                <Clock className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xs text-blue-500">وقت التوليد الإجمالي</p>
                <p className="font-semibold text-blue-700">
                  {(performanceStats.generationTime / 1000).toFixed(2)} ثانية
                </p>
              </div>
            </div>
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-500 ml-3">
                <Zap className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xs text-green-500">متوسط الوقت لكل تصميم</p>
                <p className="font-semibold text-green-700">
                  {(performanceStats.averageTimePerDesign / 1000).toFixed(2)} ثانية
                </p>
              </div>
            </div>
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-500 ml-3">
                <Cpu className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xs text-purple-500">استخدام الذاكرة</p>
                <p className="font-semibold text-purple-700">
                  {performanceStats.memoryUsage > 0 
                    ? `${performanceStats.memoryUsage} ميجابايت` 
                    : 'غير متاح'}
                </p>
              </div>
            </div>
          </div>
          
          {filteredDesigns.length === 0 ? (
            <div className="text-center py-12 bg-gray-50 rounded-lg">
              <Search className="h-12 w-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500 mb-2">لا توجد نتائج مطابقة للبحث</p>
              <button
                className="btn btn-secondary mt-2"
                onClick={() => setSearchTerm('')}
              >
                مسح البحث
              </button>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
                {currentDesigns.map((design) => (
                  <div key={design.id} className="border rounded-lg overflow-hidden bg-white shadow-sm hover:shadow-md transition-shadow">
                    <div className="aspect-w-16 aspect-h-9 bg-gray-100 flex items-center justify-center relative group">
                      <img 
                        src={design.preview} 
                        alt={`تصميم للصف ${design.rowIndex + 1}`}
                        className="max-h-48 max-w-full object-contain"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                        <button
                          className="btn btn-primary"
                          onClick={() => handleDownloadSingle(design)}
                        >
                          <FileDown className="h-5 w-5 ml-2" />
                          تنزيل
                        </button>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="flex justify-between items-center mb-2">
                        <h5 className="font-semibold">الصف {design.rowIndex + 1}</h5>
                        <button
                          className="btn btn-secondary btn-sm"
                          onClick={() => handleDownloadSingle(design)}
                        >
                          <FileDown className="h-4 w-4 ml-1" />
                          تنزيل
                        </button>
                      </div>
                      <div className="text-xs text-gray-500">
                        {excelData.headers.slice(0, 3).map(header => {
                          const rowData = excelData.rows[design.rowIndex];
                          return rowData[header] ? (
                            <div key={header} className="truncate">
                              <span className="font-medium">{header}: </span>
                              {String(rowData[header]).substring(0, 20)}
                              {String(rowData[header]).length > 20 ? '...' : ''}
                            </div>
                          ) : null;
                        })}
                        {excelData.headers.length > 3 && (
                          <div className="text-blue-500">
                            +{excelData.headers.length - 3} حقول أخرى
                          </div>
                         )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* التنقل بين الصفحات */}
              {totalPages > 1 && (
                <div className="flex justify-center items-center mt-6">
                  <button
                    className="btn btn-secondary btn-sm ml-2"
                    onClick={prevPage}
                    disabled={currentPage === 1}
                  >
                    <ArrowRight className="h-4 w-4" />
                  </button>
                  
                  <div className="flex items-center mx-4">
                    {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                      // حساب أرقام الصفحات التي سيتم عرضها
                      let pageNum;
                      if (totalPages <= 5) {
                        pageNum = i + 1;
                      } else if (currentPage <= 3) {
                        pageNum = i + 1;
                      } else if (currentPage >= totalPages - 2) {
                        pageNum = totalPages - 4 + i;
                      } else {
                        pageNum = currentPage - 2 + i;
                      }
                      
                      return (
                        <button
                          key={pageNum}
                          className={`w-8 h-8 mx-1 rounded-full ${
                            currentPage === pageNum
                              ? 'bg-blue-500 text-white'
                              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                          }`}
                          onClick={() => paginate(pageNum)}
                        >
                          {pageNum}
                        </button>
                      );
                    })}
                  </div>
                  
                  <button
                    className="btn btn-secondary btn-sm mr-2"
                    onClick={nextPage}
                    disabled={currentPage === totalPages}
                  >
                    <ArrowLeft className="h-4 w-4" />
                  </button>
                </div>
              )}
              
              {/* إحصائيات إضافية */}
              <div className="mt-6 p-3 bg-gray-50 rounded-lg border border-gray-200">
                <div className="flex items-center mb-2">
                  <BarChart2 className="h-4 w-4 text-gray-500 ml-2" />
                  <h5 className="text-sm font-medium text-gray-700">إحصائيات التوليد</h5>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-gray-600">
                  <div>
                    <p>إجمالي التصاميم: <span className="font-medium">{generatedDesigns.length}</span></p>
                    <p>التصاميم المصفاة: <span className="font-medium">{filteredDesigns.length}</span></p>
                  </div>
                  <div>
                    <p>تنسيق الإخراج: <span className="font-medium">{settings.outputFormat.toUpperCase()}</span></p>
                    <p>الجودة: <span className="font-medium">{settings.quality}%</span></p>
                  </div>
                  <div>
                    <p>تاريخ التوليد: <span className="font-medium">{new Date().toLocaleDateString('ar-SA')}</span></p>
                    <p>الوقت: <span className="font-medium">{new Date().toLocaleTimeString('ar-SA')}</span></p>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      )}
      
      {/* نافذة معاينة التصميم */}
      {showPreview && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg w-3/4 max-w-4xl max-h-[90vh] flex flex-col">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold">معاينة التصميم</h3>
              <button
                className="btn btn-secondary"
                onClick={handleClosePreview}
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center">
                <button
                  className="btn btn-secondary btn-sm"
                  onClick={() => handleChangePreviewRow('prev')}
                  disabled={previewRowIndex === 0}
                >
                  <ArrowRight className="h-4 w-4" />
                </button>
                <span className="mx-2 text-sm">
                  صف {previewRowIndex + 1} من {excelData.rows.length}
                </span>
                <button
                  className="btn btn-secondary btn-sm"
                  onClick={() => handleChangePreviewRow('next')}
                  disabled={previewRowIndex === excelData.rows.length - 1}
                >
                  <ArrowLeft className="h-4 w-4" />
                </button>
              </div>
              
              <div>
                <button
                  className="btn btn-primary"
                  onClick={handleGenerate}
                  disabled={isGenerating || !hasBindings}
                >
                  <ImageIcon className="h-5 w-5 ml-2" />
                  توليد التصاميم
                </button>
              </div>
            </div>
            
            <div className="flex-grow overflow-auto bg-gray-100 rounded-lg p-4 flex items-center justify-center" ref={previewRef}>
              {previewLoading ? (
                <div className="text-center">
                  <LoadingSpinner size="lg" color="blue" />
                  <p className="mt-4 text-gray-500">جاري إنشاء المعاينة...</p>
                </div>
              ) : previewImage ? (
                <img 
                  src={previewImage} 
                  alt="معاينة التصميم" 
                  className="max-w-full max-h-full object-contain"
                />
              ) : (
                <div className="text-center">
                  <AlertCircle className="h-12 w-12 text-gray-300 mx-auto mb-2" />
                  <p className="text-gray-500">لا توجد معاينة متاحة</p>
                </div>
              )}
            </div>
            
            {previewImage && excelData.rows[previewRowIndex] && (
              <div className="mt-4 p-3 bg-gray-50 rounded-lg border border-gray-200">
                <h4 className="text-sm font-medium mb-2">بيانات الصف {previewRowIndex + 1}:</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                  {excelData.headers.slice(0, 8).map(header => (
                    <div key={header} className="overflow-hidden">
                      <span className="font-medium">{header}: </span>
                      <span className="text-gray-600">{String(excelData.rows[previewRowIndex][header] || '')}</span>
                    </div>
                  ))}
                  {excelData.headers.length > 8 && (
                    <div className="text-blue-500">
                      +{excelData.headers.length - 8} حقول أخرى
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      
      <ExcelAutomationModal
        isOpen={showAutomationModal}
        onClose={() => setShowAutomationModal(false)}
        design={design}
        excelData={excelData}
        onUpdateElement={onUpdateElement}
      />
    </div>
  );
};

export default GenerationPanel;