import React from 'react';

interface CanvasZoomInfoProps {
  scale: number;
  width: number;
  height: number;
}

const CanvasZoomInfo: React.FC<CanvasZoomInfoProps> = ({ scale, width, height }) => {
  return (
    <div className="absolute top-2 right-2 bg-white rounded-md shadow-sm px-2 py-1 text-xs text-gray-500">
      {Math.round(scale * 100)}% | {width} × {height}
    </div>
  );
};

export default CanvasZoomInfo;