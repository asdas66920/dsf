import React from 'react';
import { Circle } from 'react-konva';
import { CanvasElement, DataBinding } from '../../types';

interface DataBindingIndicatorProps {
  selectedElement: CanvasElement | null;
}

const DataBindingIndicator: React.FC<DataBindingIndicatorProps> = ({ selectedElement }) => {
  if (!selectedElement || !selectedElement.dataBinding) return null;
  
  const bindings: DataBinding[] = Array.isArray(selectedElement.dataBinding) 
    ? selectedElement.dataBinding 
    : [selectedElement.dataBinding];
  
  return (
    <>
      {bindings.map((binding, index) => {
        if (!binding.position) return null;
        
        return (
          <Circle
            key={`binding-pos-${index}`}
            x={binding.position.x}
            y={binding.position.y}
            radius={5}
            fill="rgba(59, 130, 246, 0.5)"
            stroke="#3b82f6"
            strokeWidth={1}
          />
        );
      })}
    </>
  );
};

export default DataBindingIndicator;