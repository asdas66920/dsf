import React, { useRef, useEffect } from 'react';
import { Rect, Circle, Ellipse, Line, Transformer } from 'react-konva';
import { ShapeElement } from '../../types';

interface KonvaShapeProps {
  element: ShapeElement;
  isSelected: boolean;
  onSelect: () => void;
  onChange: (newAttrs: any) => void;
  onContextMenu: (e: any) => void;
}

const KonvaShape: React.FC<KonvaShapeProps> = ({ element, isSelected, onSelect, onChange, onContextMenu }) => {
  const shapeRef = useRef<any>(null);
  const trRef = useRef<any>(null);

  useEffect(() => {
    if (isSelected && trRef.current) {
      // تحديث المحول ليتناسب مع العنصر المحدد
      trRef.current.nodes([shapeRef.current]);
      trRef.current.getLayer().batchDraw();
    }
  }, [isSelected]);

  const handleTransform = () => {
    const node = shapeRef.current;
    
    // نحصل على القيم الجديدة مباشرة من العقدة
    const newAttrs = {
      ...element,
      x: node.x(),
      y: node.y(),
      rotation: node.rotation(),
      // نحافظ على المقياس الحالي بدلاً من إعادة حسابه
      width: Math.max(5, node.width()),
      height: Math.max(5, node.height()),
    };
    
    onChange(newAttrs);
  };

  // إنشاء تأثير الظل إذا كان مفعلاً
  const getShadowProps = () => {
    if (element.shadow && element.shadow.enabled) {
      return {
        shadowColor: element.shadow.color,
        shadowBlur: element.shadow.blur,
        shadowOffsetX: element.shadow.offsetX,
        shadowOffsetY: element.shadow.offsetY,
        shadowOpacity: element.shadow.opacity,
      };
    }
    return {};
  };

  // إنشاء تأثير التدرج اللوني إذا كان مفعلاً
  const getFillProps = () => {
    if (element.gradient && element.gradient.enabled) {
      if (element.gradient.type === 'linear') {
        const angleRad = (element.gradient.angle * Math.PI) / 180;
        const startX = 0;
        const startY = 0;
        const endX = Math.cos(angleRad) * element.width;
        const endY = Math.sin(angleRad) * element.height;
        
        return {
          fillLinearGradientStartPoint: { x: startX, y: startY },
          fillLinearGradientEndPoint: { x: endX, y: endY },
          fillLinearGradientColorStops: [0, element.gradient.startColor, 1, element.gradient.endColor],
        };
      } else if (element.gradient.type === 'radial') {
        return {
          fillRadialGradientStartPoint: { x: element.width / 2, y: element.height / 2 },
          fillRadialGradientStartRadius: 0,
          fillRadialGradientEndPoint: { x: element.width / 2, y: element.height / 2 },
          fillRadialGradientEndRadius: Math.max(element.width, element.height) / 2,
          fillRadialGradientColorStops: [0, element.gradient.startColor, 1, element.gradient.endColor],
        };
      }
    }
    
    return { fill: element.fill };
  };

  // إنشاء نمط الحدود
  const getStrokeProps = () => {
    if (element.strokeStyle) {
      let dashArray;
      
      switch (element.strokeStyle) {
        case 'dashed':
          dashArray = [10, 5];
          break;
        case 'dotted':
          dashArray = [2, 2];
          break;
        default:
          dashArray = [];
      }
      
      return {
        dash: dashArray
      };
    }
    
    return {};
  };

  // تطبيق تأثير التمدد إذا كان مفعلاً
  const getStretchProps = () => {
    if (element.stretch && element.stretch.enabled) {
      if (element.stretch.direction === 'horizontal') {
        return {
          scaleX: element.stretch.factor,
          scaleY: 1
        };
      } else {
        return {
          scaleX: 1,
          scaleY: element.stretch.factor
        };
      }
    }
    
    return {};
  };

  // الحصول على خصائص زوايا المستطيل
  const getCornerRadius = () => {
    if (element.shapeType === 'rect') {
      // إذا كانت هناك قيم مخصصة لكل زاوية
      if (
        element.cornerRadiusTopRight !== undefined ||
        element.cornerRadiusTopLeft !== undefined ||
        element.cornerRadiusBottomRight !== undefined ||
        element.cornerRadiusBottomLeft !== undefined
      ) {
        return {
          cornerRadius: [
            element.cornerRadiusTopLeft || element.cornerRadius || 0,
            element.cornerRadiusTopRight || element.cornerRadius || 0,
            element.cornerRadiusBottomRight || element.cornerRadius || 0,
            element.cornerRadiusBottomLeft || element.cornerRadius || 0
          ]
        };
      }
      
      // إذا كانت هناك قيمة واحدة لجميع الزوايا
      if (element.cornerRadius) {
        return { cornerRadius: element.cornerRadius };
      }
    }
    
    return {};
  };

  const renderShape = () => {
    const shadowProps = getShadowProps();
    const fillProps = getFillProps();
    const strokeProps = getStrokeProps();
    const stretchProps = getStretchProps();
    const cornerProps = getCornerRadius();
    
    switch (element.shapeType) {
      case 'rect':
        return (
          <Rect
            ref={shapeRef}
            {...element}
            {...fillProps}
            {...shadowProps}
            {...strokeProps}
            {...stretchProps}
            {...cornerProps}
            draggable
            onClick={onSelect}
            onTap={onSelect}
            onContextMenu={onContextMenu}
            onDragStart={onSelect} // تحديد العنصر عند بدء السحب
            onDragEnd={(e) => {
              onChange({
                ...element,
                x: e.target.x(),
                y: e.target.y(),
              });
            }}
            onTransformEnd={handleTransform}
          />
        );
      case 'circle':
        return (
          <Circle
            ref={shapeRef}
            {...element}
            {...fillProps}
            {...shadowProps}
            {...strokeProps}
            {...stretchProps}
            radius={element.width / 2}
            draggable
            onClick={onSelect}
            onTap={onSelect}
            onContextMenu={onContextMenu}
            onDragStart={onSelect} // تحديد العنصر عند بدء السحب
            onDragEnd={(e) => {
              onChange({
                ...element,
                x: e.target.x(),
                y: e.target.y(),
              });
            }}
            onTransformEnd={handleTransform}
          />
        );
      case 'ellipse':
        return (
          <Ellipse
            ref={shapeRef}
            {...element}
            {...fillProps}
            {...shadowProps}
            {...strokeProps}
            {...stretchProps}
            radiusX={element.width / 2}
            radiusY={element.height / 2}
            draggable
            onClick={onSelect}
            onTap={onSelect}
            onContextMenu={onContextMenu}
            onDragStart={onSelect} // تحديد العنصر عند بدء السحب
            onDragEnd={(e) => {
              onChange({
                ...element,
                x: e.target.x(),
                y: e.target.y(),
              });
            }}
            onTransformEnd={handleTransform}
          />
        );
      case 'line':
        return (
          <Line
            ref={shapeRef}
            {...element}
            {...shadowProps}
            {...strokeProps}
            {...stretchProps}
            points={[0, 0, element.width, element.height]}
            draggable
            onClick={onSelect}
            onTap={onSelect}
            onContextMenu={onContextMenu}
            onDragStart={onSelect} // تحديد العنصر عند بدء السحب
            onDragEnd={(e) => {
              onChange({
                ...element,
                x: e.target.x(),
                y: e.target.y(),
              });
            }}
            onTransformEnd={handleTransform}
          />
        );
      default:
        return null;
    }
  };

  // إضافة تأثير الانعكاس إذا كان مفعلاً
  const renderReflection = () => {
    if (element.reflection && element.reflection.enabled) {
      const reflectionProps = {
        ...element,
        y: element.y + element.height + element.reflection.distance,
        scaleY: -1 * element.scaleY,
        opacity: element.opacity * element.reflection.opacity,
      };
      
      switch (element.shapeType) {
        case 'rect':
          return (
            <Rect
              {...reflectionProps}
              {...getFillProps()}
              {...getStrokeProps()}
              {...getCornerRadius()}
              listening={false}
            />
          );
        case 'circle':
          return (
            <Circle
              {...reflectionProps}
              {...getFillProps()}
              {...getStrokeProps()}
              radius={element.width / 2}
              listening={false}
            />
          );
        case 'ellipse':
          return (
            <Ellipse
              {...reflectionProps}
              {...getFillProps()}
              {...getStrokeProps()}
              radiusX={element.width / 2}
              radiusY={element.height / 2}
              listening={false}
            />
          );
        case 'line':
          return (
            <Line
              {...reflectionProps}
              {...getStrokeProps()}
              points={[0, 0, element.width, element.height]}
              listening={false}
            />
          );
        default:
          return null;
      }
    }
    
    return null;
  };

  return (
    <>
      {/* تأثير الانعكاس يجب أن يكون تحت الشكل الأصلي */}
      {renderReflection()}
      {renderShape()}
      {isSelected && (
        <Transformer
          ref={trRef}
          keepRatio={false}
          enabledAnchors={['top-left', 'top-right', 'bottom-left', 'bottom-right']}
          rotateEnabled={true}
          boundBoxFunc={(oldBox, newBox) => {
            // تحديد الحد الأدنى للحجم
            if (newBox.width < 5 || newBox.height < 5) {
              return oldBox;
            }
            return newBox;
          }}
        />
      )}
    </>
  );
};

export default KonvaShape;