import React from 'react';
import { Rect } from 'react-konva';

interface CanvasBackgroundProps {
  width: number;
  height: number;
  background: string;
}

const CanvasBackground: React.FC<CanvasBackgroundProps> = ({ width, height, background }) => {
  return (
    <Rect
      x={0}
      y={0}
      width={width}
      height={height}
      fill={background}
    />
  );
};

export default CanvasBackground;