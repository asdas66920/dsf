import React, { useRef, useEffect } from 'react';
import { Text, Transformer } from 'react-konva';
import { TextElement } from '../../types';

interface KonvaTextProps {
  element: TextElement;
  isSelected: boolean;
  onSelect: () => void;
  onChange: (newAttrs: any) => void;
  onContextMenu: (e: any) => void;
}

const KonvaText: React.FC<KonvaTextProps> = ({ element, isSelected, onSelect, onChange, onContextMenu }) => {
  const shapeRef = useRef<any>(null);
  const trRef = useRef<any>(null);

  useEffect(() => {
    if (isSelected && trRef.current) {
      // تحديث المحول ليتناسب مع العنصر المحدد
      trRef.current.nodes([shapeRef.current]);
      trRef.current.getLayer().batchDraw();
    }
  }, [isSelected]);

  const handleTransform = () => {
    const node = shapeRef.current;
    
    // نحصل على القيم الجديدة مباشرة من العقدة
    const newAttrs = {
      ...element,
      x: node.x(),
      y: node.y(),
      rotation: node.rotation(),
      // نحافظ على المقياس الحالي بدلاً من إعادة حسابه
      width: Math.max(5, node.width()),
      height: Math.max(5, node.height()),
    };
    
    onChange(newAttrs);
  };

  return (
    <>
      <Text
        ref={shapeRef}
        {...element}
        draggable
        onClick={onSelect}
        onTap={onSelect}
        onContextMenu={onContextMenu}
        onDragStart={onSelect} // تحديد العنصر عند بدء السحب
        onDragEnd={(e) => {
          onChange({
            ...element,
            x: e.target.x(),
            y: e.target.y(),
          });
        }}
        onTransformEnd={handleTransform}
      />
      {isSelected && (
        <Transformer
          ref={trRef}
          keepRatio={false}
          enabledAnchors={['top-left', 'top-right', 'bottom-left', 'bottom-right']}
          rotateEnabled={true}
          boundBoxFunc={(oldBox, newBox) => {
            // تحديد الحد الأدنى للحجم
            if (newBox.width < 5 || newBox.height < 5) {
              return oldBox;
            }
            return newBox;
          }}
        />
      )}
    </>
  );
};

export default KonvaText;