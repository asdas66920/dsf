import React from 'react';
import { CanvasElement } from '../../types';

interface ContextMenuProps {
  position: { x: number; y: number } | null;
  element: CanvasElement | null;
  onClose: () => void;
  onToggleVisibility: (element: CanvasElement) => void;
}

const ContextMenu: React.FC<ContextMenuProps> = ({
  position,
  element,
  onClose,
  onToggleVisibility,
}) => {
  if (!position || !element) return null;

  return (
    <div 
      className="context-menu"
      style={{
        position: 'absolute',
        top: position.y,
        left: position.x,
        zIndex: 1000,
      }}
    >
      <div className="bg-white rounded-md shadow-lg py-1 w-48">
        <div className="px-3 py-2 text-sm font-medium text-gray-700 border-b">
          {element.name}
        </div>
        <button 
          className="w-full text-right px-3 py-2 text-sm text-gray-700 hover:bg-gray-100"
          onClick={() => {
            onClose();
            // تعديل خصائص العنصر
            // هذا سيفتح لوحة الخصائص تلقائيًا لأن العنصر محدد بالفعل
          }}
        >
          تعديل الخصائص
        </button>
        <button 
          className="w-full text-right px-3 py-2 text-sm text-gray-700 hover:bg-gray-100"
          onClick={() => {
            onToggleVisibility(element);
            onClose();
          }}
        >
          {element.visible ? 'إخفاء' : 'إظهار'}
        </button>
        <button 
          className="w-full text-right px-3 py-2 text-sm text-red-600 hover:bg-gray-100"
          onClick={() => {
            // حذف العنصر
            // هنا نحتاج إلى تمرير دالة الحذف من الأب
            // لكن يمكن للمستخدم استخدام زر الحذف في لوحة الخصائص
            onClose();
          }}
        >
          حذف
        </button>
      </div>
    </div>
  );
};

export default ContextMenu;