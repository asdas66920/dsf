import React, { useState } from 'react';
import { 
  Type, 
  Square, 
  Circle, 
  Image as ImageIcon, 
  Copy, 
  Trash2, 
  Save, 
  Download, 
  Upload,
  FileSpreadsheet,
  FileText,
  Undo,
  Redo,
  FileDown,
  Code,
  HelpCircle
} from 'lucide-react';
import { CanvasElement, Design } from '../types';
import * as XLSX from 'xlsx';
import HandlebarsHelpModal from './modals/HandlebarsHelpModal';

interface ToolbarProps {
  onAddText: () => void;
  onAddRect: () => void;
  onAddCircle: () => void;
  onAddImage: () => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onSave: () => void;
  onExport: () => void;
  onImportDesign: () => void;
  onImportExcel: () => void;
  onOpenTemplates: () => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  selectedElement: CanvasElement | null;
  design: Design;
}

const Toolbar: React.FC<ToolbarProps> = ({
  onAddText,
  onAddRect,
  onAddCircle,
  onAddImage,
  onDuplicate,
  onDelete,
  onSave,
  onExport,
  onImportDesign,
  onImportExcel,
  onOpenTemplates,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  selectedElement,
  design,
}) => {
  const [showHandlebarsHelp, setShowHandlebarsHelp] = useState(false);
  
  // التحقق من وجود عناصر في التصميم
  const hasElements = design.elements.length > 0;

  // تنزيل نموذج ملف Excel
  const downloadExcelTemplate = () => {
    // إنشاء بيانات Excel
    const excelData = [
      ['الاسم', 'البريد الإلكتروني', 'رقم الهاتف', 'المسمى الوظيفي', 'الشركة', 'العنوان', 'تاريخ الإصدار', 'رابط الصورة', 'رقم التسلسل'],
      ['أحمد محمد', 'ahmed@example.com', '+966501234567', 'مدير تنفيذي', 'شركة التقنية المتطورة', 'الرياض، المملكة العربية السعودية', '15/05/2025', 'https://images.unsplash.com/photo-1560250097-0b93528c311a', '12345'],
      ['سارة علي', 'sara@example.com', '+966501234568', 'مديرة تسويق', 'شركة الإبداع', 'جدة، المملكة العربية السعودية', '20/06/2025', 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2', '12346'],
      ['محمد خالد', 'mohammed@example.com', '+966501234569', 'مطور برمجيات', 'شركة البرمجيات الحديثة', 'الدمام، المملكة العربية السعودية', '25/07/2025', 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7', '12347']
    ];

    // إنشاء ورقة عمل
    const ws = XLSX.utils.aoa_to_sheet(excelData);
    
    // إنشاء ورقة تعليمات
    const instructionsData = [
      ['تعليمات استخدام نموذج البيانات'],
      [''],
      ['1. كيفية استخدام هذا النموذج:'],
      ['- أدخل بياناتك في الأعمدة المناسبة في ورقة "البيانات"'],
      ['- تأكد من الحفاظ على أسماء الأعمدة كما هي'],
      ['- يمكنك إضافة أعمدة جديدة حسب احتياجاتك'],
      [''],
      ['2. وصف الأعمدة:'],
      ['الاسم: اسم الشخص أو العنوان الرئيسي'],
      ['البريد الإلكتروني: عنوان البريد الإلكتروني'],
      ['رقم الهاتف: رقم الهاتف مع رمز الدولة'],
      ['المسمى الوظيفي: المسمى الوظيفي أو المنصب'],
      ['الشركة: اسم الشركة أو المؤسسة'],
      ['العنوان: العنوان البريدي'],
      ['تاريخ الإصدار: تاريخ إصدار الشهادة أو البطاقة'],
      ['رابط الصورة: رابط لصورة شخصية أو شعار (يجب أن يكون URL كامل)'],
      ['رقم التسلسل: رقم تسلسلي للبطاقة أو الشهادة']
    ];
    const wsInstructions = XLSX.utils.aoa_to_sheet(instructionsData);
    
    // إنشاء ورقة أمثلة Handlebars
    const handlebarsExamplesData = [
      ['أمثلة على استخدام قوالب Handlebars'],
      [''],
      ['1. استخدام الشروط:'],
      ['{{#if (ifCond row.العمر ">" 18)}}بالغ{{else}}قاصر{{/if}}'],
      [''],
      ['2. تنسيق التاريخ:'],
      ['{{formatDate row.تاريخ_الميلاد "long"}}'],
      [''],
      ['3. تنسيق العملة:'],
      ['{{formatCurrency row.السعر "SAR"}}'],
      [''],
      ['4. عمليات حسابية:'],
      ['المجموع: {{add row.السعر row.الضريبة}}'],
      [''],
      ['5. دمج نصوص:'],
      ['{{row.الاسم}} - {{row.المسمى_الوظيفي}} - {{row.الشركة}}'],
      [''],
      ['6. شروط متعددة:'],
      ['{{#if (ifCond row.الدرجة "==" "A")}}ممتاز{{else if (ifCond row.الدرجة "==" "B")}}جيد جدًا{{else}}مقبول{{/if}}']
    ];
    const wsHandlebarsExamples = XLSX.utils.aoa_to_sheet(handlebarsExamplesData);
    
    // إنشاء مصنف عمل
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "البيانات");
    XLSX.utils.book_append_sheet(wb, wsInstructions, "تعليمات");
    XLSX.utils.book_append_sheet(wb, wsHandlebarsExamples, "أمثلة Handlebars");
    
    // تعيين اتجاه الكتابة من اليمين إلى اليسار
    ws['!dir'] = 'rtl';
    wsInstructions['!dir'] = 'rtl';
    wsHandlebarsExamples['!dir'] = 'rtl';
    
    // تنزيل الملف
    XLSX.writeFile(wb, "نموذج-ملف-البيانات.xlsx");
  };

  return (
    <div className="bg-white border-b p-2 flex items-center justify-between">
      <div className="flex items-center space-x-2 space-x-reverse">
        <button
          className="btn btn-secondary tooltip"
          onClick={onAddText}
          data-tooltip="إضافة نص"
        >
          <Type className="h-5 w-5" />
        </button>
        <button
          className="btn btn-secondary tooltip"
          onClick={onAddRect}
          data-tooltip="إضافة مستطيل"
        >
          <Square className="h-5 w-5" />
        </button>
        <button
          className="btn btn-secondary tooltip"
          onClick={onAddCircle}
          data-tooltip="إضافة دائرة"
        >
          <Circle className="h-5 w-5" />
        </button>
        <button
          className="btn btn-secondary tooltip"
          onClick={onAddImage}
          data-tooltip="إضافة صورة"
        >
          <ImageIcon className="h-5 w-5" />
        </button>
        <div className="h-6 border-r border-gray-300 mx-2"></div>
        <button
          className="btn btn-secondary tooltip"
          onClick={onUndo}
          disabled={!canUndo}
          data-tooltip="تراجع (Ctrl+Z)"
        >
          <Undo className="h-5 w-5" />
        </button>
        <button
          className="btn btn-secondary tooltip"
          onClick={onRedo}
          disabled={!canRedo}
          data-tooltip="إعادة (Ctrl+Y)"
        >
          <Redo className="h-5 w-5" />
        </button>
        <div className="h-6 border-r border-gray-300 mx-2"></div>
        <button
          className="btn btn-secondary tooltip"
          onClick={onDuplicate}
          disabled={!selectedElement}
          data-tooltip="نسخ العنصر"
        >
          <Copy className="h-5 w-5" />
        </button>
        <button
          className="btn btn-secondary tooltip"
          onClick={onDelete}
          disabled={!selectedElement}
          data-tooltip="حذف العنصر"
        >
          <Trash2 className="h-5 w-5" />
        </button>
      </div>
      
      <div className="text-center">
        <h1 className="text-lg font-bold">{design.name}</h1>
        <p className="text-sm text-gray-500">{design.width} × {design.height}</p>
      </div>
      
      <div className="flex items-center space-x-2 space-x-reverse">
        <button
          className="btn btn-secondary tooltip"
          onClick={() => setShowHandlebarsHelp(true)}
          data-tooltip="مساعدة Handlebars"
        >
          <Code className="h-5 w-5" />
        </button>
        <button
          className="btn btn-secondary tooltip"
          onClick={onOpenTemplates}
          data-tooltip="القوالب المحفوظة"
        >
          <FileText className="h-5 w-5" />
        </button>
        <button
          className="btn btn-secondary tooltip"
          onClick={downloadExcelTemplate}
          data-tooltip="تنزيل نموذج Excel"
        >
          <FileDown className="h-5 w-5" />
        </button>
        <button
          className="btn btn-secondary tooltip"
          onClick={onImportExcel}
          data-tooltip="استيراد Excel"
        >
          <FileSpreadsheet className="h-5 w-5" />
        </button>
        <button
          className="btn btn-secondary tooltip"
          onClick={onImportDesign}
          data-tooltip="استيراد تصميم"
        >
          <Upload className="h-5 w-5" />
        </button>
        <button
          className="btn btn-secondary tooltip"
          onClick={onSave}
          disabled={!hasElements}
          data-tooltip={hasElements ? "حفظ التصميم" : "لا يوجد عناصر للحفظ"}
        >
          <Save className="h-5 w-5" />
        </button>
        <button
          className="btn btn-primary tooltip"
          onClick={onExport}
          disabled={!hasElements}
          data-tooltip={hasElements ? "تصدير التصميم" : "لا يوجد عناصر للتصدير"}
        >
          <Download className="h-5 w-5 ml-1" />
          <span>تصدير</span>
        </button>
      </div>
      
      <HandlebarsHelpModal isOpen={showHandlebarsHelp} onClose={() => setShowHandlebarsHelp(false)} />
    </div>
  );
};

export default Toolbar;