import React, { useState } from 'react';
import { ShapeElement } from '../../types';
import { Square, ChevronDown, ChevronUp, Droplet, Palette, Layers, Sun, Move } from 'lucide-react';
import { SectionHeader } from './SectionHeader';

interface ShapePropertiesProps {
  shapeElement: ShapeElement;
  onUpdateElement: (element: ShapeElement) => void;
  isExpanded: boolean;
  onToggleExpand: () => void;
}

const ShapeProperties: React.FC<ShapePropertiesProps> = ({
  shapeElement,
  onUpdateElement,
  isExpanded,
  onToggleExpand,
}) => {
  const [expandedSections, setExpandedSections] = useState({
    fill: true,
    border: true,
    effects: true,
    corners: shapeElement.shapeType === 'rect'
  });

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const handleCornerRadiusChange = (value: string) => {
    const radius = parseInt(value) || 0;
    onUpdateElement({
      ...shapeElement,
      cornerRadius: radius
    });
  };

  const handleShadowChange = (property: string, value: any) => {
    const currentShadow = shapeElement.shadow || {
      enabled: false,
      color: 'rgba(0,0,0,0.5)',
      blur: 10,
      offsetX: 5,
      offsetY: 5,
      opacity: 0.5
    };

    onUpdateElement({
      ...shapeElement,
      shadow: {
        ...currentShadow,
        [property]: value,
        enabled: property === 'enabled' ? value : true
      }
    });
  };

  const handleReflectionChange = (property: string, value: any) => {
    const currentReflection = shapeElement.reflection || {
      enabled: false,
      opacity: 0.5,
      distance: 20
    };

    onUpdateElement({
      ...shapeElement,
      reflection: {
        ...currentReflection,
        [property]: value,
        enabled: property === 'enabled' ? value : true
      }
    });
  };

  const handleGradientChange = (property: string, value: any) => {
    const currentGradient = shapeElement.gradient || {
      enabled: false,
      type: 'linear',
      angle: 90,
      startColor: '#ffffff',
      endColor: shapeElement.fill
    };

    onUpdateElement({
      ...shapeElement,
      gradient: {
        ...currentGradient,
        [property]: value,
        enabled: property === 'enabled' ? value : true
      }
    });
  };

  return (
    <div className="property-group mb-4">
      <SectionHeader
        title="خصائص الشكل"
        section="shape"
        icon={<Square className="h-4 w-4 text-green-500" />}
        isExpanded={isExpanded}
        onToggleExpand={onToggleExpand}
      />
      
      {isExpanded && (
        <>
          {/* قسم التعبئة واللون */}
          <div className="mb-3 border-b pb-3">
            <div 
              className="flex items-center justify-between cursor-pointer mb-2"
              onClick={() => toggleSection('fill')}
            >
              <div className="flex items-center">
                <Droplet className="h-4 w-4 text-blue-500 ml-2" />
                <span className="text-sm font-medium">التعبئة واللون</span>
              </div>
              {expandedSections.fill ? (
                <ChevronUp className="h-4 w-4 text-gray-500" />
              ) : (
                <ChevronDown className="h-4 w-4 text-gray-500" />
              )}
            </div>
            
            {expandedSections.fill && (
              <>
                <div className="mb-2">
                  <label className="block text-xs text-gray-500 mb-1">
                    لون التعبئة
                  </label>
                  <div className="flex items-center">
                    <input
                      type="color"
                      className="color-picker w-10 h-10 rounded-md ml-2"
                      value={shapeElement.fill}
                      onChange={(e) => onUpdateElement({ ...shapeElement, fill: e.target.value })}
                    />
                    <input
                      type="text"
                      className="text-input flex-grow"
                      value={shapeElement.fill}
                      onChange={(e) => onUpdateElement({ ...shapeElement, fill: e.target.value })}
                    />
                  </div>
                </div>
                
                <div className="mb-2">
                  <div className="flex items-center mb-1">
                    <input
                      type="checkbox"
                      id="enable-gradient"
                      className="ml-2"
                      checked={shapeElement.gradient?.enabled || false}
                      onChange={(e) => handleGradientChange('enabled', e.target.checked)}
                    />
                    <label htmlFor="enable-gradient" className="text-xs text-gray-500">
                      تفعيل التدرج اللوني
                    </label>
                  </div>
                  
                  {shapeElement.gradient?.enabled && (
                    <>
                      <div className="grid grid-cols-2 gap-2 mb-2">
                        <div>
                          <label className="block text-xs text-gray-500 mb-1">
                            لون البداية
                          </label>
                          <div className="flex items-center">
                            <input
                              type="color"
                              className="color-picker w-8 h-8 rounded-md ml-1"
                              value={shapeElement.gradient.startColor}
                              onChange={(e) => handleGradientChange('startColor', e.target.value)}
                            />
                            <input
                              type="text"
                              className="text-input text-xs flex-grow"
                              value={shapeElement.gradient.startColor}
                              onChange={(e) => handleGradientChange('startColor', e.target.value)}
                            />
                          </div>
                        </div>
                        <div>
                          <label className="block text-xs text-gray-500 mb-1">
                            لون النهاية
                          </label>
                          <div className="flex items-center">
                            <input
                              type="color"
                              className="color-picker w-8 h-8 rounded-md ml-1"
                              value={shapeElement.gradient.endColor}
                              onChange={(e) => handleGradientChange('endColor', e.target.value)}
                            />
                            <input
                              type="text"
                              className="text-input text-xs flex-grow"
                              value={shapeElement.gradient.endColor}
                              onChange={(e) => handleGradientChange('endColor', e.target.value)}
                            />
                          </div>
                        </div>
                      </div>
                      
                      <div className="mb-2">
                        <label className="block text-xs text-gray-500 mb-1">
                          نوع التدرج
                        </label>
                        <select
                          className="select-input"
                          value={shapeElement.gradient.type}
                          onChange={(e) => handleGradientChange('type', e.target.value)}
                        >
                          <option value="linear">خطي</option>
                          <option value="radial">دائري</option>
                        </select>
                      </div>
                      
                      {shapeElement.gradient.type === 'linear' && (
                        <div className="mb-2">
                          <label className="block text-xs text-gray-500 mb-1">
                            زاوية التدرج: {shapeElement.gradient.angle}°
                          </label>
                          <input
                            type="range"
                            className="range-input w-full"
                            min="0"
                            max="360"
                            value={shapeElement.gradient.angle}
                            onChange={(e) => handleGradientChange('angle', parseInt(e.target.value))}
                          />
                        </div>
                      )}
                    </>
                  )}
                </div>
                
                <div className="mb-2">
                  <label className="block text-xs text-gray-500 mb-1">
                    الشفافية: {Math.round(shapeElement.opacity * 100)}%
                  </label>
                  <input
                    type="range"
                    className="range-input w-full"
                    min="0"
                    max="1"
                    step="0.01"
                    value={shapeElement.opacity}
                    onChange={(e) => onUpdateElement({ ...shapeElement, opacity: parseFloat(e.target.value) })}
                  />
                </div>
              </>
            )}
          </div>
          
          {/* قسم الحدود */}
          <div className="mb-3 border-b pb-3">
            <div 
              className="flex items-center justify-between cursor-pointer mb-2"
              onClick={() => toggleSection('border')}
            >
              <div className="flex items-center">
                <Square className="h-4 w-4 text-gray-500 ml-2" />
                <span className="text-sm font-medium">الحدود</span>
              </div>
              {expandedSections.border ? (
                <ChevronUp className="h-4 w-4 text-gray-500" />
              ) : (
                <ChevronDown className="h-4 w-4 text-gray-500" />
              )}
            </div>
            
            {expandedSections.border && (
              <>
                <div className="mb-2">
                  <label className="block text-xs text-gray-500 mb-1">
                    سمك الحدود: {shapeElement.strokeWidth}px
                  </label>
                  <input
                    type="range"
                    className="range-input w-full"
                    min="0"
                    max="20"
                    value={shapeElement.strokeWidth}
                    onChange={(e) => onUpdateElement({ ...shapeElement, strokeWidth: parseInt(e.target.value) || 0 })}
                  />
                </div>
                
                <div className="mb-2">
                  <label className="block text-xs text-gray-500 mb-1">
                    لون الحدود
                  </label>
                  <div className="flex items-center">
                    <input
                      type="color"
                      className="color-picker w-10 h-10 rounded-md ml-2"
                      value={shapeElement.stroke}
                      onChange={(e) => onUpdateElement({ ...shapeElement, stroke: e.target.value })}
                    />
                    <input
                      type="text"
                      className="text-input flex-grow"
                      value={shapeElement.stroke}
                      onChange={(e) => onUpdateElement({ ...shapeElement, stroke: e.target.value })}
                    />
                  </div>
                </div>
                
                <div className="mb-2">
                  <label className="block text-xs text-gray-500 mb-1">
                    نوع الحدود
                  </label>
                  <select
                    className="select-input"
                    value={shapeElement.strokeStyle || 'solid'}
                    onChange={(e) => onUpdateElement({ ...shapeElement, strokeStyle: e.target.value })}
                  >
                    <option value="solid">متصل</option>
                    <option value="dashed">متقطع</option>
                    <option value="dotted">نقطي</option>
                  </select>
                </div>
              </>
            )}
          </div>
          
          {/* قسم زوايا المستطيل */}
          {shapeElement.shapeType === 'rect' && (
            <div className="mb-3 border-b pb-3">
              <div 
                className="flex items-center justify-between cursor-pointer mb-2"
                onClick={() => toggleSection('corners')}
              >
                <div className="flex items-center">
                  <Square className="h-4 w-4 text-purple-500 ml-2" />
                  <span className="text-sm font-medium">زوايا المستطيل</span>
                </div>
                {expandedSections.corners ? (
                  <ChevronUp className="h-4 w-4 text-gray-500" />
                ) : (
                  <ChevronDown className="h-4 w-4 text-gray-500" />
                )}
              </div>
              
              {expandedSections.corners && (
                <>
                  <div className="mb-2">
                    <label className="block text-xs text-gray-500 mb-1">
                      انحناء الزوايا: {shapeElement.cornerRadius || 0}px
                    </label>
                    <input
                      type="range"
                      className="range-input w-full"
                      min="0"
                      max="50"
                      value={shapeElement.cornerRadius || 0}
                      onChange={(e) => handleCornerRadiusChange(e.target.value)}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 mb-2">
                    <div>
                      <label className="block text-xs text-gray-500 mb-1">
                        الزاوية العلوية اليمنى
                      </label>
                      <input
                        type="number"
                        className="number-input"
                        min="0"
                        max="50"
                        value={shapeElement.cornerRadiusTopRight || shapeElement.cornerRadius || 0}
                        onChange={(e) => onUpdateElement({ 
                          ...shapeElement, 
                          cornerRadiusTopRight: parseInt(e.target.value) || 0 
                        })}
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-500 mb-1">
                        الزاوية العلوية اليسرى
                      </label>
                      <input
                        type="number"
                        className="number-input"
                        min="0"
                        max="50"
                        value={shapeElement.cornerRadiusTopLeft || shapeElement.cornerRadius || 0}
                        onChange={(e) => onUpdateElement({ 
                          ...shapeElement, 
                          cornerRadiusTopLeft: parseInt(e.target.value) || 0 
                        })}
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 mb-2">
                    <div>
                      <label className="block text-xs text-gray-500 mb-1">
                        الزاوية السفلية اليمنى
                      </label>
                      <input
                        type="number"
                        className="number-input"
                        min="0"
                        max="50"
                        value={shapeElement.cornerRadiusBottomRight || shapeElement.cornerRadius || 0}
                        onChange={(e) => onUpdateElement({ 
                          ...shapeElement, 
                          cornerRadiusBottomRight: parseInt(e.target.value) || 0 
                        })}
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-gray-500 mb-1">
                        الزاوية السفلية اليسرى
                      </label>
                      <input
                        type="number"
                        className="number-input"
                        min="0"
                        max="50"
                        value={shapeElement.cornerRadiusBottomLeft || shapeElement.cornerRadius || 0}
                        onChange={(e) => onUpdateElement({ 
                          ...shapeElement, 
                          cornerRadiusBottomLeft: parseInt(e.target.value) || 0 
                        })}
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-center mt-2">
                    <button
                      className="btn btn-secondary btn-sm"
                      onClick={() => onUpdateElement({
                        ...shapeElement,
                        cornerRadiusTopRight: undefined,
                        cornerRadiusTopLeft: undefined,
                        cornerRadiusBottomRight: undefined,
                        cornerRadiusBottomLeft: undefined,
                        cornerRadius: shapeElement.cornerRadius || 0
                      })}
                    >
                      توحيد جميع الزوايا
                    </button>
                  </div>
                </>
              )}
            </div>
          )}
          
          {/* قسم التأثيرات */}
          <div className="mb-3">
            <div 
              className="flex items-center justify-between cursor-pointer mb-2"
              onClick={() => toggleSection('effects')}
            >
              <div className="flex items-center">
                <Sun className="h-4 w-4 text-yellow-500 ml-2" />
                <span className="text-sm font-medium">التأثيرات</span>
              </div>
              {expandedSections.effects ? (
                <ChevronUp className="h-4 w-4 text-gray-500" />
              ) : (
                <ChevronDown className="h-4 w-4 text-gray-500" />
              )}
            </div>
            
            {expandedSections.effects && (
              <>
                {/* تأثير الظل */}
                <div className="mb-3 bg-gray-50 p-2 rounded-md">
                  <div className="flex items-center mb-2">
                    <input
                      type="checkbox"
                      id="enable-shadow"
                      className="ml-2"
                      checked={shapeElement.shadow?.enabled || false}
                      onChange={(e) => handleShadowChange('enabled', e.target.checked)}
                    />
                    <label htmlFor="enable-shadow" className="text-sm font-medium">
                      تفعيل الظل
                    </label>
                  </div>
                  
                  {shapeElement.shadow?.enabled && (
                    <>
                      <div className="mb-2">
                        <label className="block text-xs text-gray-500 mb-1">
                          لون الظل
                        </label>
                        <div className="flex items-center">
                          <input
                            type="color"
                            className="color-picker w-8 h-8 rounded-md ml-1"
                            value={shapeElement.shadow.color.startsWith('rgba') 
                              ? '#000000' 
                              : shapeElement.shadow.color}
                            onChange={(e) => handleShadowChange('color', e.target.value)}
                          />
                          <input
                            type="text"
                            className="text-input text-xs flex-grow"
                            value={shapeElement.shadow.color}
                            onChange={(e) => handleShadowChange('color', e.target.value)}
                          />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2 mb-2">
                        <div>
                          <label className="block text-xs text-gray-500 mb-1">
                            الإزاحة الأفقية: {shapeElement.shadow.offsetX}px
                          </label>
                          <input
                            type="range"
                            className="range-input w-full"
                            min="-50"
                            max="50"
                            value={shapeElement.shadow.offsetX}
                            onChange={(e) => handleShadowChange('offsetX', parseInt(e.target.value))}
                          />
                        </div>
                        <div>
                          <label className="block text-xs text-gray-500 mb-1">
                            الإزاحة العمودية: {shapeElement.shadow.offsetY}px
                          </label>
                          <input
                            type="range"
                            className="range-input w-full"
                            min="-50"
                            max="50"
                            value={shapeElement.shadow.offsetY}
                            onChange={(e) => handleShadowChange('offsetY', parseInt(e.target.value))}
                          />
                        </div>
                      </div>
                      
                      <div className="mb-2">
                        <label className="block text-xs text-gray-500 mb-1">
                          تمويه الظل: {shapeElement.shadow.blur}px
                        </label>
                        <input
                          type="range"
                          className="range-input w-full"
                          min="0"
                          max="50"
                          value={shapeElement.shadow.blur}
                          onChange={(e) => handleShadowChange('blur', parseInt(e.target.value))}
                        />
                      </div>
                      
                      <div className="mb-2">
                        <label className="block text-xs text-gray-500 mb-1">
                          شفافية الظل: {Math.round(shapeElement.shadow.opacity * 100)}%
                        </label>
                        <input
                          type="range"
                          className="range-input w-full"
                          min="0"
                          max="1"
                          step="0.01"
                          value={shapeElement.shadow.opacity}
                          onChange={(e) => handleShadowChange('opacity', parseFloat(e.target.value))}
                        />
                      </div>
                    </>
                  )}
                </div>
                
                {/* تأثير الانعكاس */}
                <div className="mb-3 bg-gray-50 p-2 rounded-md">
                  <div className="flex items-center mb-2">
                    <input
                      type="checkbox"
                      id="enable-reflection"
                      className="ml-2"
                      checked={shapeElement.reflection?.enabled || false}
                      onChange={(e) => handleReflectionChange('enabled', e.target.checked)}
                    />
                    <label htmlFor="enable-reflection" className="text-sm font-medium">
                      تفعيل الانعكاس
                    </label>
                  </div>
                  
                  {shapeElement.reflection?.enabled && (
                    <>
                      <div className="mb-2">
                        <label className="block text-xs text-gray-500 mb-1">
                          شفافية الانعكاس: {Math.round(shapeElement.reflection.opacity * 100)}%
                        </label>
                        <input
                          type="range"
                          className="range-input w-full"
                          min="0"
                          max="1"
                          step="0.01"
                          value={shapeElement.reflection.opacity}
                          onChange={(e) => handleReflectionChange('opacity', parseFloat(e.target.value))}
                        />
                      </div>
                      
                      <div className="mb-2">
                        <label className="block text-xs text-gray-500 mb-1">
                          مسافة الانعكاس: {shapeElement.reflection.distance}px
                        </label>
                        <input
                          type="range"
                          className="range-input w-full"
                          min="0"
                          max="100"
                          value={shapeElement.reflection.distance}
                          onChange={(e) => handleReflectionChange('distance', parseInt(e.target.value))}
                        />
                      </div>
                    </>
                  )}
                </div>
                
                {/* تأثير التمدد */}
                <div className="mb-3 bg-gray-50 p-2 rounded-md">
                  <div className="flex items-center mb-2">
                    <input
                      type="checkbox"
                      id="enable-stretch"
                      className="ml-2"
                      checked={shapeElement.stretch?.enabled || false}
                      onChange={(e) => onUpdateElement({
                        ...shapeElement,
                        stretch: {
                          ...(shapeElement.stretch || { factor: 1.2, direction: 'horizontal' }),
                          enabled: e.target.checked
                        }
                      })}
                    />
                    <label htmlFor="enable-stretch" className="text-sm font-medium">
                      تفعيل التمدد
                    </label>
                  </div>
                  
                  {shapeElement.stretch?.enabled && (
                    <>
                      <div className="mb-2">
                        <label className="block text-xs text-gray-500 mb-1">
                          عامل التمدد: {shapeElement.stretch.factor}x
                        </label>
                        <input
                          type="range"
                          className="range-input w-full"
                          min="1"
                          max="3"
                          step="0.1"
                          value={shapeElement.stretch.factor}
                          onChange={(e) => onUpdateElement({
                            ...shapeElement,
                            stretch: {
                              ...shapeElement.stretch,
                              factor: parseFloat(e.target.value)
                            }
                          })}
                        />
                      </div>
                      
                      <div className="mb-2">
                        <label className="block text-xs text-gray-500 mb-1">
                          اتجاه التمدد
                        </label>
                        <select
                          className="select-input"
                          value={shapeElement.stretch.direction}
                          onChange={(e) => onUpdateElement({
                            ...shapeElement,
                            stretch: {
                              ...shapeElement.stretch,
                              direction: e.target.value
                            }
                          })}
                        >
                          <option value="horizontal">أفقي</option>
                          <option value="vertical">عمودي</option>
                        </select>
                      </div>
                    </>
                  )}
                </div>
              </>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default ShapeProperties;