import React from 'react';
import { Layers } from 'lucide-react';

const EmptyState: React.FC = () => {
  return (
    <div className="property-panel p-4 h-full flex items-center justify-center bg-gray-50">
      <div className="text-center">
        <Layers className="h-12 w-12 mx-auto text-gray-300 mb-2" />
        <p className="text-gray-500">اختر عنصرًا لتعديل خصائصه</p>
        <p className="text-xs text-gray-400 mt-2">انقر على أي عنصر في التصميم لعرض خصائصه</p>
      </div>
    </div>
  );
};

export default EmptyState;