import React, { useState } from 'react';
import { CanvasElement, ExcelData, DataBinding } from '../../types';
import { Link, ChevronDown, ChevronUp, Plus, Trash2, Code } from 'lucide-react';
import { SectionHeader } from './SectionHeader';

interface DataBindingPropertiesProps {
  selectedElement: CanvasElement;
  onUpdateElement: (element: CanvasElement) => void;
  excelData: ExcelData | null;
  isExpanded: boolean;
  onToggleExpand: () => void;
}

const DataBindingProperties: React.FC<DataBindingPropertiesProps> = ({
  selectedElement,
  onUpdateElement,
  excelData,
  isExpanded,
  onToggleExpand,
}) => {
  const [showAddBinding, setShowAddBinding] = useState(false);

  if (!excelData) return null;

  // تنسيق قيم الخلايا
  const formatCellValue = (value: any, format?: string): string => {
    if (value === undefined || value === null) return 'لا توجد بيانات';
    switch (format) {
      case 'date': return new Date(value).toLocaleDateString('ar-SA');
      case 'currency': return `${parseFloat(value).toFixed(2)} ر.س`;
      case 'number': return parseFloat(value).toLocaleString('ar-SA');
      case 'percentage': return `${(parseFloat(value) * 100).toFixed(2)}%`;
      default: return String(value);
    }
  };

  // الحصول على روابط البيانات الحالية
  const getDataBindings = (): DataBinding[] => {
    if (!selectedElement.dataBinding) return [];
    return Array.isArray(selectedElement.dataBinding) 
      ? selectedElement.dataBinding 
      : [selectedElement.dataBinding];
  };

  // تحديث روابط البيانات
  const updateDataBindings = (bindings: DataBinding[]) => {
    if (bindings.length === 0) {
      // إزالة خاصية dataBinding إذا لم تكن هناك روابط
      const { dataBinding, ...rest } = selectedElement;
      onUpdateElement(rest);
    } else if (bindings.length === 1) {
      // استخدام كائن واحد للتوافق مع الإصدارات السابقة
      onUpdateElement({
        ...selectedElement,
        dataBinding: bindings[0]
      });
    } else {
      // استخدام مصفوفة للروابط المتعددة
      onUpdateElement({
        ...selectedElement,
        dataBinding: bindings
      });
    }
  };

  // تحديد الموضع الافتراضي للعمود بناءً على ترتيبه
  const getDefaultPositionForColumn = (columnIndex: number, elementWidth: number, elementHeight: number): { x: number, y: number } => {
    const padding = 20;
    
    switch (columnIndex) {
      case 0: // العمود الأول - جهة اليمين من أعلى
        return { x: padding, y: padding };
      case 1: // العمود الثاني - جهة اليمين من أسفل
        return { x: padding, y: elementHeight - padding };
      case 2: // العمود الثالث - وسط الطبقة
        return { x: elementWidth / 2, y: elementHeight / 2 };
      case 3: // العمود الرابع - جهة اليسار من أعلى
        return { x: elementWidth - padding, y: padding };
      case 4: // العمود الخامس - جهة اليسار من أسفل
        return { x: elementWidth - padding, y: elementHeight - padding };
      default: // للأعمدة الإضافية، نضعها في مواقع متباعدة
        return { 
          x: padding + ((columnIndex % 3) * (elementWidth - 2 * padding) / 2), 
          y: padding + (Math.floor(columnIndex / 3) % 3) * (elementHeight - 2 * padding) / 2 
        };
    }
  };

  // إضافة رابط بيانات جديد
  const handleAddBinding = () => {
    const bindings = getDataBindings();
    const columnIndex = bindings.length;
    const elementWidth = selectedElement.width;
    const elementHeight = selectedElement.height;
    
    // تحديد الموضع الافتراضي بناءً على ترتيب العمود
    const defaultPosition = getDefaultPositionForColumn(columnIndex, elementWidth, elementHeight);
    
    const newBinding: DataBinding = { 
      column: '',
      position: defaultPosition,
      fontSize: 25, // حجم الخط الافتراضي 25
      textColor: '#00AA00', // اللون الأخضر الافتراضي
      useTemplate: false, // افتراضيًا لا يستخدم قالب
      template: '' // قالب فارغ افتراضيًا
    };
    
    updateDataBindings([...bindings, newBinding]);
    setShowAddBinding(false);
  };

  // تحديث رابط بيانات موجود
  const handleUpdateBinding = (index: number, key: keyof DataBinding, value: any) => {
    const bindings = getDataBindings();
    
    // إذا كان التحديث للعمود، نقوم بتحديث الموضع أيضًا
    if (key === 'column' && !bindings[index].position) {
      const elementWidth = selectedElement.width;
      const elementHeight = selectedElement.height;
      const defaultPosition = getDefaultPositionForColumn(index, elementWidth, elementHeight);
      
      bindings[index] = { 
        ...bindings[index], 
        [key]: value,
        position: defaultPosition,
        fontSize: bindings[index].fontSize || 25,
        textColor: bindings[index].textColor || '#00AA00'
      };
    } else {
      bindings[index] = { ...bindings[index], [key]: value };
    }
    
    updateDataBindings(bindings);
  };

  // حذف رابط بيانات
  const handleDeleteBinding = (index: number) => {
    const bindings = getDataBindings();
    bindings.splice(index, 1);
    updateDataBindings(bindings);
  };

  const dataBindings = getDataBindings();

  return (
    <div className="property-group mb-4">
      <SectionHeader
        title="ربط البيانات"
        section="dataBinding"
        icon={<Link className="h-4 w-4 text-orange-500" />}
        isExpanded={isExpanded}
        onToggleExpand={onToggleExpand}
      />
      
      {isExpanded && (
        <>
          {dataBindings.length === 0 ? (
            <div className="mb-2 text-center">
              <p className="text-sm text-gray-500 mb-2">لا توجد روابط بيانات</p>
              <button
                className="btn btn-secondary btn-sm"
                onClick={handleAddBinding}
              >
                <Plus className="h-4 w-4 ml-1" />
                إضافة ربط بيانات
              </button>
            </div>
          ) : (
            <>
              {dataBindings.map((binding, index) => (
                <div key={index} className="mb-4 p-2 border border-gray-200 rounded-md">
                  <div className="flex justify-between items-center mb-2">
                    <h4 className="text-sm font-medium">ربط بيانات {index + 1}</h4>
                    <button
                      className="btn btn-icon btn-danger"
                      onClick={() => handleDeleteBinding(index)}
                      title="حذف الربط"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                  
                  <div className="mb-2">
                    <label className="block text-xs text-gray-500 mb-1">عمود البيانات</label>
                    <select
                      className="select-input p-2 rounded w-full border border-gray-300"
                      value={binding.column || ''}
                      onChange={(e) => handleUpdateBinding(index, 'column', e.target.value)}
                    >
                      <option value="">اختر عمود</option>
                      {excelData.headers.map(header => (
                        <option key={header} value={header}>{header}</option>
                      ))}
                    </select>
                  </div>
                  
                  {binding.column && (
                    <>
                      <div className="mb-2">
                        <div className="flex items-center justify-between">
                          <label className="block text-xs text-gray-500">استخدام قالب Handlebars</label>
                          <input
                            type="checkbox"
                            checked={binding.useTemplate || false}
                            onChange={(e) => handleUpdateBinding(index, 'useTemplate', e.target.checked)}
                            className="ml-2 h-4 w-4 text-blue-600 focus:ring-blue-500 rounded"
                          />
                        </div>
                      </div>
                      
                      {binding.useTemplate ? (
                        <div className="mb-2">
                          <label className="block text-xs text-gray-500 mb-1">قالب Handlebars</label>
                          <div className="relative">
                            <textarea
                              className="text-input p-2 rounded w-full border border-gray-300 font-mono text-sm"
                              value={binding.template || ''}
                              onChange={(e) => handleUpdateBinding(index, 'template', e.target.value)}
                              rows={4}
                              dir="ltr"
                              placeholder="مثال: {{#if (ifCond row.العمر '>' 18)}}بالغ{{else}}قاصر{{/if}}"
                            />
                            <Code className="absolute top-2 left-2 h-4 w-4 text-gray-400" />
                          </div>
                          <div className="mt-1 bg-blue-50 p-3 rounded-md border border-blue-100">
                            <p className="text-xs text-blue-700 mb-1">يمكنك استخدام الدوال التالية:</p>
                            <ul className="text-xs text-blue-600 list-disc list-inside">
                              <li>{"{{formatDate value format}}"}: لتنسيق التاريخ (format: short, long, time, datetime)</li>
                              <li>{"{{formatCurrency value}}"}: لتنسيق العملة</li>
                              <li>{"{{formatNumber value decimals}}"}: لتنسيق الأرقام</li>
                              <li>{"{{formatPercent value}}"}: لتنسيق النسب المئوية</li>
                              <li>{"{{#if (ifCond value operator value2)}}"}: للشروط المنطقية</li>
                              <li>{"{{#each items}}"}: للتكرار على العناصر</li>
                              <li>{"{{add/subtract/multiply/divide value1 value2}}"}: للعمليات الحسابية</li>
                            </ul>
                          </div>
                        </div>
                      ) : (
                        <div className="mb-2">
                          <label className="block text-xs text-gray-500 mb-1">تنسيق البيانات</label>
                          <select
                            className="select-input p-2 rounded w-full border border-gray-300"
                            value={binding.format || ''}
                            onChange={(e) => handleUpdateBinding(index, 'format', e.target.value)}
                          >
                            <option value="">بدون تنسيق</option>
                            <option value="date">تاريخ</option>
                            <option value="currency">عملة</option>
                            <option value="number">رقم</option>
                            <option value="percentage">نسبة مئوية</option>
                          </select>
                        </div>
                      )}
                      
                      <div className="mb-2">
                        <label className="block text-xs text-gray-500 mb-1">حجم الخط</label>
                        <input
                          type="number"
                          className="number-input p-2 rounded w-full border border-gray-300"
                          value={binding.fontSize || 25}
                          onChange={(e) => handleUpdateBinding(index, 'fontSize', parseInt(e.target.value) || 25)}
                        />
                      </div>
                      
                      <div className="mb-2">
                        <label className="block text-xs text-gray-500 mb-1">لون النص</label>
                        <div className="flex items-center">
                          <input
                            type="color"
                            className="color-picker w-10 h-10 rounded-md ml-2"
                            value={binding.textColor || '#00AA00'}
                            onChange={(e) => handleUpdateBinding(index, 'textColor', e.target.value)}
                          />
                          <input
                            type="text"
                            className="text-input flex-grow"
                            value={binding.textColor || '#00AA00'}
                            onChange={(e) => handleUpdateBinding(index, 'textColor', e.target.value)}
                          />
                        </div>
                      </div>
                      
                      <div className="mb-2">
                        <label className="block text-xs text-gray-500 mb-1">معاينة</label>
                        <div className="bg-gray-100 p-2 rounded-md text-sm">
                          {binding.useTemplate && binding.template ? (
                            <div className="text-blue-600 font-mono">
                              سيتم تطبيق قالب Handlebars عند التوليد
                            </div>
                          ) : (
                            excelData.rows[0] && binding.column
                              ? formatCellValue(excelData.rows[0][binding.column], binding.format)
                              : 'لا توجد بيانات'
                          )}
                        </div>
                      </div>
                      
                      {selectedElement.type === 'text' && !binding.useTemplate && (
                        <div className="mb-2 bg-blue-50 p-3 rounded-md border border-blue-100">
                          <label className="block text-xs font-medium text-blue-700 mb-1">كيفية استخدام البيانات في النص</label>
                          <div className="bg-white p-2 rounded-md text-sm border border-blue-200">
                            <p className="mb-2 text-blue-600">أضف الرمز التالي في النص حيث تريد ظهور البيانات:</p>
                            <code className="bg-blue-100 px-2 py-1 rounded text-blue-800 font-mono">{"{{" + binding.column + "}}"}</code>
                          </div>
                          <p className="mt-2 text-xs text-blue-600">
                            مثال: إذا كان النص "مرحباً {{الاسم}}"، سيتم استبداله بـ "مرحباً أحمد" إذا كانت قيمة عمود "الاسم" هي "أحمد"
                          </p>
                        </div>
                      )}
                      
                      {selectedElement.type === 'text' && binding.useTemplate && (
                        <div className="mb-2 bg-green-50 p-3 rounded-md border border-green-100">
                          <label className="block text-xs font-medium text-green-700 mb-1">استخدام قوالب Handlebars</label>
                          <div className="bg-white p-2 rounded-md text-sm border border-green-200">
                            <p className="mb-2 text-green-600">يمكنك استخدام قوالب Handlebars لإنشاء محتوى ديناميكي معقد:</p>
                            <code className="bg-green-100 px-2 py-1 rounded text-green-800 font-mono dir-ltr block">
                              {"{{#if (ifCond row.العمر \">\" 18)}}\n  مرحباً {{row.الاسم}} أنت بالغ\n{{else}}\n  مرحباً {{row.الاسم}} أنت قاصر\n{{/if}}"}
                            </code>
                          </div>
                          <p className="mt-2 text-xs text-green-600">
                            يمكنك الوصول إلى جميع بيانات الصف باستخدام row.اسم_العمود
                          </p>
                        </div>
                      )}
                    </>
                  )}
                </div>
              ))}
              
              <div className="text-center mt-2">
                <button
                  className="btn btn-secondary btn-sm"
                  onClick={handleAddBinding}
                >
                  <Plus className="h-4 w-4 ml-1" />
                  إضافة ربط بيانات آخر
                </button>
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
};

export default DataBindingProperties;