import React from 'react';
import { CanvasElement } from '../../types';
import { Sliders, ChevronDown, ChevronUp } from 'lucide-react';
import { SectionHeader } from './SectionHeader';

interface EffectsPropertiesProps {
  selectedElement: CanvasElement;
  onUpdateElement: (element: CanvasElement) => void;
  isExpanded: boolean;
  onToggleExpand: () => void;
}

const EffectsProperties: React.FC<EffectsPropertiesProps> = ({
  selectedElement,
  onUpdateElement,
  isExpanded,
  onToggleExpand,
}) => {
  const handleOpacityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const opacity = parseFloat(e.target.value) || 0;
    onUpdateElement({ ...selectedElement, opacity });
  };

  return (
    <div className="property-group mb-4">
      <SectionHeader
        title="التأثيرات"
        section="effects"
        icon={<Sliders className="h-4 w-4 text-purple-500" />}
        isExpanded={isExpanded}
        onToggleExpand={onToggleExpand}
      />
      
      {isExpanded && (
        <>
          <div className="mb-2">
            <label className="block text-xs text-gray-500 mb-1">الشفافية ({Math.round(selectedElement.opacity * 100)}%)</label>
            <input
              type="range"
              className="range-input w-full"
              min="0"
              max="1"
              step="0.01"
              value={selectedElement.opacity}
              onChange={handleOpacityChange}
            />
          </div>
          <div className="mb-2">
            <label className="block text-xs text-gray-500 mb-1">التكبير الأفقي</label>
            <input
              type="range"
              className="range-input w-full"
              min="0.1"
              max="3"
              step="0.1"
              value={selectedElement.scaleX}
              onChange={(e) => onUpdateElement({ ...selectedElement, scaleX: parseFloat(e.target.value) || 1 })}
            />
          </div>
          <div className="mb-2">
            <label className="block text-xs text-gray-500 mb-1">التكبير العمودي</label>
            <input
              type="range"
              className="range-input w-full"
              min="0.1"
              max="3"
              step="0.1"
              value={selectedElement.scaleY}
              onChange={(e) => onUpdateElement({ ...selectedElement, scaleY: parseFloat(e.target.value) || 1 })}
            />
          </div>
        </>
      )}
    </div>
  );
};

export default EffectsProperties;