import React from 'react';
import { CanvasElement } from '../../types';
import { Move, ChevronDown, ChevronUp } from 'lucide-react';
import { SectionHeader } from './SectionHeader';

interface PositionPropertiesProps {
  selectedElement: CanvasElement;
  onUpdateElement: (element: CanvasElement) => void;
  isExpanded: boolean;
  onToggleExpand: () => void;
}

const PositionProperties: React.FC<PositionPropertiesProps> = ({
  selectedElement,
  onUpdateElement,
  isExpanded,
  onToggleExpand,
}) => {
  const handlePositionChange = (axis: 'x' | 'y', value: string) => {
    const numValue = parseFloat(value) || 0;
    onUpdateElement({ ...selectedElement, [axis]: numValue });
  };

  const handleSizeChange = (dimension: 'width' | 'height', value: string) => {
    const numValue = parseFloat(value) || 0;
    onUpdateElement({ ...selectedElement, [dimension]: numValue });
  };

  const handleRotationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rotation = parseFloat(e.target.value) || 0;
    onUpdateElement({ ...selectedElement, rotation });
  };

  // تحديث القياسات بشكل دقيق
  const updateMeasurements = () => {
    // تأكد من أن القياسات دقيقة ومتناسبة
    const updatedElement = { ...selectedElement };
    
    // تأكد من أن العرض والارتفاع موجبان
    updatedElement.width = Math.max(5, updatedElement.width);
    updatedElement.height = Math.max(5, updatedElement.height);
    
    // إعادة تعيين المقياس إلى 1 (لتجنب التشوه)
    updatedElement.scaleX = 1;
    updatedElement.scaleY = 1;
    
    onUpdateElement(updatedElement);
  };

  // إعادة ضبط الدوران
  const resetRotation = () => {
    onUpdateElement({ ...selectedElement, rotation: 0 });
  };

  return (
    <div className="property-group mb-4">
      <SectionHeader
        title="الموضع والحجم"
        section="position"
        icon={<Move className="h-4 w-4 text-green-500" />}
        isExpanded={isExpanded}
        onToggleExpand={onToggleExpand}
      />
      
      {isExpanded && (
        <>
          <div className="grid grid-cols-2 gap-2 mb-2">
            <div>
              <label className="block text-xs text-gray-500 mb-1">X</label>
              <input
                type="number"
                className="number-input p-2 rounded w-full border border-gray-300"
                value={Math.round(selectedElement.x)}
                onChange={(e) => handlePositionChange('x', e.target.value)}
                onBlur={updateMeasurements}
              />
            </div>
            <div>
              <label className="block text-xs text-gray-500 mb-1">Y</label>
              <input
                type="number"
                className="number-input p-2 rounded w-full border border-gray-300"
                value={Math.round(selectedElement.y)}
                onChange={(e) => handlePositionChange('y', e.target.value)}
                onBlur={updateMeasurements}
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 mb-2">
            <div>
              <label className="block text-xs text-gray-500 mb-1">العرض</label>
              <input
                type="number"
                className="number-input p-2 rounded w-full border border-gray-300"
                value={Math.round(selectedElement.width)}
                onChange={(e) => handleSizeChange('width', e.target.value)}
                onBlur={updateMeasurements}
                min="5"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-500 mb-1">الارتفاع</label>
              <input
                type="number"
                className="number-input p-2 rounded w-full border border-gray-300"
                value={Math.round(selectedElement.height)}
                onChange={(e) => handleSizeChange('height', e.target.value)}
                onBlur={updateMeasurements}
                min="5"
              />
            </div>
          </div>
          <div className="mb-2">
            <div className="flex justify-between items-center">
              <label className="block text-xs text-gray-500">الدوران ({Math.round(selectedElement.rotation)}°)</label>
              <button 
                className="text-xs text-blue-500 hover:underline" 
                onClick={resetRotation}
              >
                إعادة ضبط
              </button>
            </div>
            <div className="flex items-center">
              <input
                type="range"
                className="range-input w-full"
                min="0"
                max="360"
                value={selectedElement.rotation}
                onChange={handleRotationChange}
              />
              <input
                type="number"
                className="number-input p-2 rounded w-16 border border-gray-300 mr-2"
                value={Math.round(selectedElement.rotation)}
                onChange={(e) => onUpdateElement({ ...selectedElement, rotation: parseFloat(e.target.value) || 0 })}
                min="0"
                max="360"
              />
            </div>
          </div>
          <div className="mt-3">
            <button
              className="btn btn-secondary w-full"
              onClick={updateMeasurements}
            >
              ضبط القياسات
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default PositionProperties;