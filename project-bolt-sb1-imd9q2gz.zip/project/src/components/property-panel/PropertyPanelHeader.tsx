import React from 'react';
import { CanvasElement } from '../../types';
import { Copy, Trash2 } from 'lucide-react';

interface PropertyPanelHeaderProps {
  selectedElement: CanvasElement;
  onDuplicate: () => void;
  onDelete: () => void;
}

const PropertyPanelHeader: React.FC<PropertyPanelHeaderProps> = ({
  selectedElement,
  onDuplicate,
  onDelete,
}) => {
  return (
    <div className="flex justify-between items-center mb-4">
      <h3 className="text-lg font-semibold">خصائص العنصر</h3>
      <div className="flex space-x-2 space-x-reverse">
        <button
          className="btn p-2 rounded bg-gray-200 hover:bg-gray-300"
          onClick={onDuplicate}
          title="نسخ العنصر"
        >
          <Copy className="h-4 w-4" />
        </button>
        <button
          className="btn p-2 rounded bg-red-500 text-white hover:bg-red-600"
          onClick={() => onDelete()}
          title="حذف العنصر"
        >
          <Trash2 className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};

export default PropertyPanelHeader;