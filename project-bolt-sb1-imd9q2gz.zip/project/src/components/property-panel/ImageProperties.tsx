import React from 'react';
import { ImageElement } from '../../types';
import { Image as ImageIcon, ChevronDown, ChevronUp } from 'lucide-react';
import { SectionHeader } from './SectionHeader';

interface ImagePropertiesProps {
  imageElement: ImageElement;
  onUpdateElement: (element: ImageElement) => void;
  isExpanded: boolean;
  onToggleExpand: () => void;
}

const ImageProperties: React.FC<ImagePropertiesProps> = ({
  imageElement,
  onUpdateElement,
  isExpanded,
  onToggleExpand,
}) => {
  return (
    <div className="property-group mb-4">
      <SectionHeader
        title="خصائص الصورة"
        section="image"
        icon={<ImageIcon className="h-4 w-4 text-purple-500" />}
        isExpanded={isExpanded}
        onToggleExpand={onToggleExpand}
      />
      
      {isExpanded && (
        <>
          <div className="mb-2">
            <label className="block text-xs text-gray-500 mb-1">معاينة</label>
            <img
              src={imageElement.src}
              alt="معاينة"
              className="max-h-24 max-w-full object-contain rounded-md"
            />
          </div>
          <div className="mb-2">
            <label className="block text-xs text-gray-500 mb-1">رابط الصورة</label>
            <input
              type="text"
              className="text-input p-2 rounded w-full border border-gray-300"
              value={imageElement.src}
              onChange={(e) => onUpdateElement({ ...imageElement, src: e.target.value })}
            />
          </div>
        </>
      )}
    </div>
  );
};

export default ImageProperties;