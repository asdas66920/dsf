import React from 'react';
import { TextElement } from '../../types';
import { Type, ChevronDown, ChevronUp } from 'lucide-react';
import { SectionHeader } from './SectionHeader';

interface TextPropertiesProps {
  textElement: TextElement;
  onUpdateElement: (element: TextElement) => void;
  isExpanded: boolean;
  onToggleExpand: () => void;
}

const TextProperties: React.FC<TextPropertiesProps> = ({
  textElement,
  onUpdateElement,
  isExpanded,
  onToggleExpand,
}) => {
  return (
    <div className="property-group mb-4">
      <SectionHeader
        title="خصائص النص"
        section="text"
        icon={<Type className="h-4 w-4 text-blue-500" />}
        isExpanded={isExpanded}
        onToggleExpand={onToggleExpand}
      />
      
      {isExpanded && (
        <>
          <div className="mb-2">
            <label className="block text-xs text-gray-500 mb-1">النص</label>
            <textarea
              className="text-input p-2 rounded w-full border border-gray-300"
              value={textElement.text}
              onChange={(e) => onUpdateElement({ ...textElement, text: e.target.value })}
              rows={3}
              dir="auto"
            />
          </div>
          <div className="grid grid-cols-2 gap-2 mb-2">
            <div>
              <label className="block text-xs text-gray-500 mb-1">حجم الخط</label>
              <input
                type="number"
                className="number-input p-2 rounded w-full border border-gray-300"
                value={textElement.fontSize}
                onChange={(e) => onUpdateElement({ ...textElement, fontSize: parseInt(e.target.value) || 16 })}
              />
            </div>
            <div>
              <label className="block text-xs text-gray-500 mb-1">نوع الخط</label>
              <select
                className="select-input p-2 rounded w-full border border-gray-300"
                value={textElement.fontFamily}
                onChange={(e) => onUpdateElement({ ...textElement, fontFamily: e.target.value })}
              >
                <option value="Tajawal">Tajawal</option>
                <option value="Arial">Arial</option>
                <option value="Helvetica">Helvetica</option>
              </select>
            </div>
          </div>
          <div className="mb-2">
            <label className="block text-xs text-gray-500 mb-1">لون النص</label>
            <input
              type="color"
              className="color-picker w-10 h-10 rounded-md"
              value={textElement.fill}
              onChange={(e) => onUpdateElement({ ...textElement, fill: e.target.value })}
            />
          </div>
        </>
      )}
    </div>
  );
};

export default TextProperties;