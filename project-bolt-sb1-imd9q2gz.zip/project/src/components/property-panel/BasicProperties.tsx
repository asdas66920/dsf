import React from 'react';
import { CanvasElement } from '../../types';
import { Layers, Eye, EyeOff, ChevronDown, ChevronUp } from 'lucide-react';
import { SectionHeader } from './SectionHeader';

interface BasicPropertiesProps {
  selectedElement: CanvasElement;
  onUpdateElement: (element: CanvasElement) => void;
  isExpanded: boolean;
  onToggleExpand: () => void;
}

const BasicProperties: React.FC<BasicPropertiesProps> = ({
  selectedElement,
  onUpdateElement,
  isExpanded,
  onToggleExpand,
}) => {
  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdateElement({ ...selectedElement, name: e.target.value });
  };

  const handleVisibilityToggle = () => {
    onUpdateElement({ ...selectedElement, visible: !selectedElement.visible });
  };

  return (
    <div className="property-group mb-4">
      <SectionHeader
        title="معلومات أساسية"
        section="basic"
        icon={<Layers className="h-4 w-4 text-blue-500" />}
        isExpanded={isExpanded}
        onToggleExpand={onToggleExpand}
      />
      
      {isExpanded && (
        <>
          <div className="property-row flex items-center mb-2">
            <label className="property-label w-24 text-sm">الاسم</label>
            <input
              type="text"
              className="text-input p-2 rounded w-full border border-gray-300"
              value={selectedElement.name}
              onChange={handleNameChange}
            />
          </div>
          <div className="property-row flex items-center mb-2">
            <label className="property-label w-24 text-sm">الرؤية</label>
            <button
              className={`btn p-2 rounded ${selectedElement.visible ? 'bg-blue-500 text-white' : 'bg-gray-300 text-gray-700'}`}
              onClick={handleVisibilityToggle}
            >
              {selectedElement.visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
            </button>
          </div>
          <div className="property-row flex items-center mb-2">
            <label className="property-label w-24 text-sm">ترتيب الطبقة</label>
            <input
              type="number"
              className="number-input p-2 rounded w-full border border-gray-300"
              value={selectedElement.zIndex}
              onChange={(e) => onUpdateElement({ ...selectedElement, zIndex: parseInt(e.target.value) || 0 })}
            />
          </div>
        </>
      )}
    </div>
  );
};

export default BasicProperties;