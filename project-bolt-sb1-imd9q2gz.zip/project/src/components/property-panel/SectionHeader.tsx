import React from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface SectionHeaderProps {
  title: string;
  section: string;
  icon: React.ReactNode;
  isExpanded: boolean;
  onToggleExpand: () => void;
}

export const SectionHeader: React.FC<SectionHeaderProps> = ({
  title,
  section,
  icon,
  isExpanded,
  onToggleExpand,
}) => {
  return (
    <div
      className="flex items-center justify-between py-2 px-1 cursor-pointer border-b border-gray-200 mb-2"
      onClick={onToggleExpand}
    >
      <div className="flex items-center">
        {icon}
        <span className="font-medium mr-2">{title}</span>
      </div>
      {isExpanded ? (
        <ChevronUp className="h-4 w-4 text-gray-500" />
      ) : (
        <ChevronDown className="h-4 w-4 text-gray-500" />
      )}
    </div>
  );
};