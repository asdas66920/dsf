import React, { useState, useRef } from 'react';
import { Upload, FileSpreadsheet, AlertCircle } from 'lucide-react';
import { parseExcelFile } from '../utils/excelUtils';
import { ExcelData } from '../types';

interface ExcelImporterProps {
  onExcelImported: (data: ExcelData) => void;
}

const ExcelImporter: React.FC<ExcelImporterProps> = ({ onExcelImported }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      await processFile(files[0]);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      await processFile(files[0]);
    }
  };

  const processFile = async (file: File) => {
    if (!file.name.match(/\.(xlsx|xls|csv)$/)) {
      setError('يرجى تحميل ملف Excel صالح (.xlsx, .xls, .csv)');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const data = await parseExcelFile(file);
      onExcelImported(data);
    } catch (err) {
      setError('حدث خطأ أثناء معالجة الملف. يرجى التحقق من تنسيق الملف والمحاولة مرة أخرى.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleButtonClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="w-full">
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center ${
          isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <FileSpreadsheet className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-sm font-semibold text-gray-900">استيراد ملف Excel</h3>
        <p className="mt-1 text-xs text-gray-500">
          اسحب وأفلت ملف Excel هنا، أو انقر لتحديد ملف
        </p>
        <div className="mt-4">
          <button
            type="button"
            className="btn btn-primary"
            onClick={handleButtonClick}
            disabled={isLoading}
          >
            {isLoading ? (
              <span>جاري المعالجة...</span>
            ) : (
              <>
                <Upload className="h-4 w-4 ml-2" />
                <span>تحميل ملف Excel</span>
              </>
            )}
          </button>
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            accept=".xlsx,.xls,.csv"
            onChange={handleFileChange}
            disabled={isLoading}
          />
        </div>
        {error && (
          <div className="mt-4 text-sm text-red-500 flex items-center justify-center">
            <AlertCircle className="h-4 w-4 ml-1" />
            {error}
          </div>
        )}
      </div>
    </div>
  );
};

export default ExcelImporter;