import React, { useRef, useState, useEffect } from 'react';
import { Stage, Layer } from 'react-konva';
import { CanvasElement, Design } from '../types';

// استيراد المكونات الفرعية
import KonvaText from './canvas/KonvaText';
import KonvaImage from './canvas/KonvaImage';
import KonvaShape from './canvas/KonvaShape';
import ContextMenu from './canvas/ContextMenu';
import DataBindingIndicator from './canvas/DataBindingIndicator';
import CanvasBackground from './canvas/CanvasBackground';
import CanvasZoomInfo from './canvas/CanvasZoomInfo';

interface DesignCanvasProps {
  design: Design;
  selectedElement: CanvasElement | null;
  onSelectElement: (element: CanvasElement | null) => void;
  onUpdateElement: (element: CanvasElement) => void;
}

const DesignCanvas: React.FC<DesignCanvasProps> = ({
  design,
  selectedElement,
  onSelectElement,
  onUpdateElement,
}) => {
  const stageRef = useRef<any>(null);
  const [stageSize, setStageSize] = useState({ width: 0, height: 0 });
  const containerRef = useRef<HTMLDivElement>(null);
  const [contextMenuPosition, setContextMenuPosition] = useState<{ x: number; y: number } | null>(null);
  const [contextMenuElement, setContextMenuElement] = useState<CanvasElement | null>(null);
  const [scale, setScale] = useState(1);
  const [isDragging, setIsDragging] = useState(false);

  useEffect(() => {
    const updateSize = () => {
      if (containerRef.current) {
        const containerWidth = containerRef.current.offsetWidth;
        const containerHeight = containerRef.current.offsetHeight;
        
        // حساب المقياس لملاءمة التصميم في الحاوية
        const scaleX = containerWidth / design.width;
        const scaleY = containerHeight / design.height;
        const newScale = Math.min(scaleX, scaleY, 1); // عدم التكبير أكثر من 100%
        
        setScale(newScale);
        setStageSize({
          width: design.width * newScale,
          height: design.height * newScale,
        });
      }
    };

    updateSize();
    window.addEventListener('resize', updateSize);
    
    return () => {
      window.removeEventListener('resize', updateSize);
    };
  }, [design.width, design.height]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (contextMenuPosition) {
        setContextMenuPosition(null);
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, [contextMenuPosition]);

  // إضافة التكبير/التصغير باستخدام عجلة الماوس
  const handleWheel = (e: any) => {
    e.evt.preventDefault();
    
    const scaleBy = 1.1;
    const stage = stageRef.current;
    const oldScale = stage.scaleX();
    
    const pointerPosition = stage.getPointerPosition();
    const mousePointTo = {
      x: (pointerPosition.x - stage.x()) / oldScale,
      y: (pointerPosition.y - stage.y()) / oldScale,
    };
    
    // حساب المقياس الجديد
    let newScale = e.evt.deltaY < 0 ? oldScale * scaleBy : oldScale / scaleBy;
    
    // تحديد حدود التكبير/التصغير
    newScale = Math.max(0.1, Math.min(newScale, 3));
    
    // تحديث المقياس والموضع
    stage.scale({ x: newScale, y: newScale });
    
    const newPos = {
      x: pointerPosition.x - mousePointTo.x * newScale,
      y: pointerPosition.y - mousePointTo.y * newScale,
    };
    
    stage.position(newPos);
    stage.batchDraw();
    
    setScale(newScale);
  };

  const handleStageClick = (e: any) => {
    // النقر على المرحلة وليس على أي شكل
    if (e.target === e.currentTarget) {
      onSelectElement(null);
      setContextMenuPosition(null);
    }
  };

  const handleElementSelect = (element: CanvasElement) => {
    onSelectElement(element);
  };

  const handleElementChange = (updatedElement: CanvasElement) => {
    onUpdateElement(updatedElement);
  };

  const handleContextMenu = (e: any, element: CanvasElement) => {
    e.evt.preventDefault();
    
    // الحصول على موضع القائمة السياقية
    const stage = stageRef.current;
    const pointerPosition = stage.getPointerPosition();
    
    setContextMenuPosition({
      x: pointerPosition.x,
      y: pointerPosition.y,
    });
    
    setContextMenuElement(element);
    onSelectElement(element);
  };

  const handleToggleVisibility = (element: CanvasElement) => {
    const updatedElement = {
      ...element,
      visible: !element.visible,
    };
    onUpdateElement(updatedElement);
  };

  // ترتيب العناصر حسب zIndex
  const sortedElements = [...design.elements].sort((a, b) => a.zIndex - b.zIndex);

  return (
    <div 
      ref={containerRef} 
      className="canvas-container w-full h-full relative overflow-auto"
      data-dragging={isDragging}
    >
      <CanvasZoomInfo scale={scale} width={design.width} height={design.height} />
      
      <Stage
        ref={stageRef}
        width={stageSize.width}
        height={stageSize.height}
        onClick={handleStageClick}
        onTap={handleStageClick}
        onContextMenu={(e) => e.evt.preventDefault()}
        onWheel={handleWheel}
        scaleX={scale}
        scaleY={scale}
        draggable={true} // السماح بسحب المرحلة بالكامل
        onDragStart={() => setIsDragging(true)}
        onDragEnd={() => setIsDragging(false)}
      >
        <Layer>
          {/* الخلفية */}
          <CanvasBackground 
            width={design.width} 
            height={design.height} 
            background={design.background} 
          />
          
          {/* عناصر التصميم */}
          {sortedElements.map((element) => {
            if (!element.visible) return null;
            
            const isSelected = selectedElement?.id === element.id;
            
            switch (element.type) {
              case 'text':
                return (
                  <KonvaText
                    key={element.id}
                    element={element}
                    isSelected={isSelected}
                    onSelect={() => handleElementSelect(element)}
                    onChange={(newAttrs) => handleElementChange(newAttrs)}
                    onContextMenu={(e) => handleContextMenu(e, element)}
                  />
                );
              case 'image':
                return (
                  <KonvaImage
                    key={element.id}
                    element={element}
                    isSelected={isSelected}
                    onSelect={() => handleElementSelect(element)}
                    onChange={(newAttrs) => handleElementChange(newAttrs)}
                    onContextMenu={(e) => handleContextMenu(e, element)}
                  />
                );
              case 'shape':
                return (
                  <KonvaShape
                    key={element.id}
                    element={element}
                    isSelected={isSelected}
                    onSelect={() => handleElementSelect(element)}
                    onChange={(newAttrs) => handleElementChange(newAttrs)}
                    onContextMenu={(e) => handleContextMenu(e, element)}
                  />
                );
              default:
                return null;
            }
          })}
          
          {/* مؤشرات موضع ربط البيانات */}
          <DataBindingIndicator selectedElement={selectedElement} />
        </Layer>
      </Stage>

      {/* القائمة السياقية */}
      <ContextMenu 
        position={contextMenuPosition}
        element={contextMenuElement}
        onClose={() => setContextMenuPosition(null)}
        onToggleVisibility={handleToggleVisibility}
      />
      
      {/* أزرار التكبير والتصغير */}
      <div className="absolute bottom-4 left-4 flex space-x-2">
        <button 
          className="bg-white rounded-full w-8 h-8 flex items-center justify-center shadow-md"
          onClick={() => {
            const stage = stageRef.current;
            const newScale = Math.min(scale * 1.2, 3);
            stage.scale({ x: newScale, y: newScale });
            stage.batchDraw();
            setScale(newScale);
          }}
        >
          +
        </button>
        <button 
          className="bg-white rounded-full w-8 h-8 flex items-center justify-center shadow-md"
          onClick={() => {
            const stage = stageRef.current;
            const newScale = Math.max(scale / 1.2, 0.1);
            stage.scale({ x: newScale, y: newScale });
            stage.batchDraw();
            setScale(newScale);
          }}
        >
          -
        </button>
        <button 
          className="bg-white rounded-full w-8 h-8 flex items-center justify-center shadow-md text-xs"
          onClick={() => {
            const stage = stageRef.current;
            stage.scale({ x: 1, y: 1 });
            stage.position({ x: 0, y: 0 });
            stage.batchDraw();
            setScale(1);
          }}
        >
          100%
        </button>
      </div>
    </div>
  );
};

export default DesignCanvas;