import React, { useState, useEffect, useMemo } from 'react';
import { ExcelData } from '../types';
import { Table, FileSpreadsheet, ChevronDown, ChevronUp, Search, Filter, Download, Eye, RefreshCw, Columns, SlidersHorizontal } from 'lucide-react';

interface ExcelDataPanelProps {
  excelData: ExcelData;
  onSelectSheet: (sheetName: string) => void;
  onPreviewDesign?: () => void; // إضافة دالة للمعاينة قبل التوليد
}

const ExcelDataPanel: React.FC<ExcelDataPanelProps> = ({ excelData, onSelectSheet, onPreviewDesign }) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [visibleRows, setVisibleRows] = useState(10);
  const [activeFilters, setActiveFilters] = useState<Record<string, string>>({});
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'ascending' | 'descending' } | null>(null);
  const [selectedColumns, setSelectedColumns] = useState<string[]>([]);
  const [showColumnSelector, setShowColumnSelector] = useState(false);

  // إعادة تعيين عدد الصفوف المرئية عند تغيير البحث أو الفلاتر
  useEffect(() => {
    setVisibleRows(10);
  }, [searchTerm, activeFilters]);

  // تصفية الصفوف بناءً على البحث والفلاتر
  const filteredRows = useMemo(() => {
    return excelData.rows.filter((row) => {
      // تطبيق البحث
      if (searchTerm) {
        const searchMatches = Object.values(row).some((value) => 
          String(value).toLowerCase().includes(searchTerm.toLowerCase())
        );
        if (!searchMatches) return false;
      }
      
      // تطبيق الفلاتر النشطة
      for (const [column, filterValue] of Object.entries(activeFilters)) {
        if (filterValue && String(row[column]) !== filterValue) {
          return false;
        }
      }
      
      return true;
    });
  }, [excelData.rows, searchTerm, activeFilters]);

  // ترتيب الصفوف
  const sortedRows = useMemo(() => {
    if (!sortConfig) return filteredRows;
    
    return [...filteredRows].sort((a, b) => {
      if (a[sortConfig.key] === undefined || b[sortConfig.key] === undefined) {
        return 0;
      }
      
      const aValue = a[sortConfig.key];
      const bValue = b[sortConfig.key];
      
      if (aValue < bValue) {
        return sortConfig.direction === 'ascending' ? -1 : 1;
      }
      if (aValue > bValue) {
        return sortConfig.direction === 'ascending' ? 1 : -1;
      }
      return 0;
    });
  }, [filteredRows, sortConfig]);

  // الصفوف المعروضة حاليًا
  const displayedRows = sortedRows.slice(0, visibleRows);

  // الأعمدة المعروضة (جميع الأعمدة أو الأعمدة المحددة فقط)
  const displayedColumns = selectedColumns.length > 0 
    ? selectedColumns 
    : excelData.headers;

  // تبديل ترتيب العمود
  const handleSort = (key: string) => {
    let direction: 'ascending' | 'descending' = 'ascending';
    
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    } else if (sortConfig && sortConfig.key === key && sortConfig.direction === 'descending') {
      // إلغاء الترتيب
      setSortConfig(null);
      return;
    }
    
    setSortConfig({ key, direction });
  };

  // تحميل المزيد من الصفوف
  const handleLoadMore = () => {
    setVisibleRows((prev) => prev + 10);
  };

  // تصدير البيانات المصفاة كملف CSV
  const handleExportCSV = () => {
    // تحويل البيانات المصفاة إلى CSV
    const headers = displayedColumns.join(',');
    const rows = sortedRows.map(row => 
      displayedColumns.map(header => {
        const value = row[header];
        // تغليف القيم التي تحتوي على فواصل بعلامات اقتباس
        if (typeof value === 'string' && value.includes(',')) {
          return `"${value}"`;
        }
        return value !== undefined ? value : '';
      }).join(',')
    ).join('\n');
    
    const csv = `${headers}\n${rows}`;
    
    // إنشاء ملف للتنزيل
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${excelData.fileName.replace(/\.[^/.]+$/, '')}_filtered.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // تبديل تحديد عمود
  const toggleColumnSelection = (column: string) => {
    setSelectedColumns(prev => {
      if (prev.includes(column)) {
        return prev.filter(col => col !== column);
      } else {
        return [...prev, column];
      }
    });
  };

  // الحصول على القيم الفريدة لعمود معين
  const getUniqueValues = (column: string) => {
    const values = new Set<string>();
    excelData.rows.forEach(row => {
      if (row[column] !== undefined) {
        values.add(String(row[column]));
      }
    });
    return Array.from(values).sort();
  };

  return (
    <div className="border rounded-lg overflow-hidden bg-white shadow-sm">
      <div 
        className="p-4 bg-gray-50 flex justify-between items-center cursor-pointer border-b"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center">
          <FileSpreadsheet className="h-5 w-5 ml-2 text-blue-500" />
          <div>
            <h3 className="font-semibold">{excelData.fileName}</h3>
            <p className="text-sm text-gray-500">
              {excelData.rows.length} صفوف, {excelData.headers.length} أعمدة
            </p>
          </div>
        </div>
        {isExpanded ? (
          <ChevronUp className="h-5 w-5 text-gray-500" />
        ) : (
          <ChevronDown className="h-5 w-5 text-gray-500" />
        )}
      </div>
      
      {isExpanded && (
        <div className="p-4">
          {/* أزرار الإجراءات */}
          <div className="flex justify-between items-center mb-4">
            <div className="flex space-x-2 space-x-reverse">
              {excelData.sheetNames.length > 1 && (
                <select
                  className="select-input text-sm"
                  value={excelData.activeSheet}
                  onChange={(e) => onSelectSheet(e.target.value)}
                >
                  {excelData.sheetNames.map((sheetName) => (
                    <option key={sheetName} value={sheetName}>
                      {sheetName}
                    </option>
                  ))}
                </select>
              )}
              
              <button
                className="btn btn-secondary btn-sm flex items-center"
                onClick={() => setShowColumnSelector(!showColumnSelector)}
                title="إدارة الأعمدة"
              >
                <Columns className="h-4 w-4 ml-1" />
                <span className="text-xs">الأعمدة</span>
              </button>
            </div>
            
            <div className="flex space-x-2 space-x-reverse">
              <button
                className="btn btn-secondary btn-sm flex items-center"
                onClick={handleExportCSV}
                title="تصدير البيانات المصفاة"
              >
                <Download className="h-4 w-4 ml-1" />
                <span className="text-xs">تصدير</span>
              </button>
              
              {onPreviewDesign && (
                <button
                  className="btn btn-primary btn-sm flex items-center"
                  onClick={onPreviewDesign}
                  title="معاينة التصميم قبل التوليد"
                >
                  <Eye className="h-4 w-4 ml-1" />
                  <span className="text-xs">معاينة التصميم</span>
                </button>
              )}
            </div>
          </div>
          
          {/* محدد الأعمدة */}
          {showColumnSelector && (
            <div className="mb-4 p-3 bg-gray-50 rounded-lg border border-gray-200">
              <div className="flex justify-between items-center mb-2">
                <h4 className="text-sm font-medium">إدارة الأعمدة المعروضة</h4>
                <div className="flex space-x-2 space-x-reverse">
                  <button
                    className="btn btn-secondary btn-sm text-xs"
                    onClick={() => setSelectedColumns([])}
                  >
                    عرض الكل
                  </button>
                  <button
                    className="btn btn-secondary btn-sm text-xs"
                    onClick={() => setSelectedColumns(excelData.headers)}
                  >
                    تحديد الكل
                  </button>
                </div>
              </div>
              <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto p-2">
                {excelData.headers.map(header => (
                  <div 
                    key={header}
                    className={`px-2 py-1 text-xs rounded-full cursor-pointer ${
                      selectedColumns.length === 0 || selectedColumns.includes(header)
                        ? 'bg-blue-100 text-blue-700 border border-blue-200'
                        : 'bg-gray-100 text-gray-500 border border-gray-200'
                    }`}
                    onClick={() => toggleColumnSelection(header)}
                  >
                    {header}
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* البحث والفلترة */}
          <div className="mb-4 flex flex-wrap gap-2">
            <div className="relative flex-grow">
              <input
                type="text"
                className="text-input pr-8 w-full"
                placeholder="بحث في البيانات..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-gray-400" />
              </div>
            </div>
            
            <div className="relative">
              <button
                className="btn btn-secondary btn-sm flex items-center"
                onClick={() => setActiveFilters({})}
                title="إعادة ضبط الفلاتر"
              >
                <RefreshCw className="h-4 w-4 ml-1" />
                <span className="text-xs">إعادة ضبط</span>
              </button>
            </div>
          </div>
          
          {/* عرض الفلاتر النشطة */}
          {Object.keys(activeFilters).length > 0 && (
            <div className="mb-4 flex flex-wrap gap-2 p-2 bg-blue-50 rounded-lg border border-blue-100">
              <span className="text-xs text-blue-700 ml-2">الفلاتر النشطة:</span>
              {Object.entries(activeFilters).map(([column, value]) => (
                <div 
                  key={column}
                  className="bg-white px-2 py-1 text-xs rounded-full border border-blue-200 flex items-center"
                >
                  <span className="font-medium ml-1">{column}:</span>
                  <span>{value}</span>
                  <button
                    className="mr-1 text-red-500 hover:text-red-700"
                    onClick={() => setActiveFilters(prev => {
                      const newFilters = { ...prev };
                      delete newFilters[column];
                      return newFilters;
                    })}
                  >
                    &times;
                  </button>
                </div>
              ))}
            </div>
          )}
          
          {/* عرض البيانات */}
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 border">
              <thead className="bg-gray-50">
                <tr>
                  {displayedColumns.map((header) => (
                    <th
                      key={header}
                      className="px-3 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider border-l cursor-pointer hover:bg-gray-100"
                      onClick={() => handleSort(header)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          {sortConfig?.key === header && (
                            <span className="ml-1">
                              {sortConfig.direction === 'ascending' ? '↑' : '↓'}
                            </span>
                          )}
                          {header}
                        </div>
                        <div className="relative group">
                          <Filter className="h-3 w-3 text-gray-400 hover:text-gray-600" />
                          <div className="absolute hidden group-hover:block left-0 mt-1 bg-white border border-gray-200 rounded-md shadow-lg z-10 w-48">
                            <div className="p-2 max-h-48 overflow-y-auto">
                              <div 
                                className={`px-2 py-1 text-xs rounded cursor-pointer mb-1 ${
                                  !activeFilters[header] ? 'bg-blue-100 text-blue-700' : 'hover:bg-gray-100'
                                }`}
                                onClick={() => setActiveFilters(prev => {
                                  const newFilters = { ...prev };
                                  delete newFilters[header];
                                  return newFilters;
                                })}
                              >
                                الكل
                              </div>
                              {getUniqueValues(header).map(value => (
                                <div 
                                  key={value}
                                  className={`px-2 py-1 text-xs rounded cursor-pointer mb-1 ${
                                    activeFilters[header] === value ? 'bg-blue-100 text-blue-700' : 'hover:bg-gray-100'
                                  }`}
                                  onClick={() => setActiveFilters(prev => ({
                                    ...prev,
                                    [header]: value
                                  }))}
                                >
                                  {value}
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {displayedRows.length === 0 ? (
                  <tr>
                    <td 
                      colSpan={displayedColumns.length} 
                      className="px-6 py-4 text-center text-sm text-gray-500"
                    >
                      لا توجد بيانات مطابقة للبحث
                    </td>
                  </tr>
                ) : (
                  displayedRows.map((row, rowIndex) => (
                    <tr key={rowIndex} className="hover:bg-gray-50">
                      {displayedColumns.map((header) => (
                        <td
                          key={`${rowIndex}-${header}`}
                          className="px-3 py-2 whitespace-nowrap text-sm text-gray-500 border-l"
                        >
                          {row[header] !== undefined ? String(row[header]) : ''}
                        </td>
                      ))}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
          
          {/* زر تحميل المزيد */}
          {filteredRows.length > visibleRows && (
            <div className="mt-4 text-center">
              <button
                className="btn btn-secondary"
                onClick={handleLoadMore}
              >
                عرض المزيد ({visibleRows} من {filteredRows.length})
              </button>
            </div>
          )}
          
          {/* إحصائيات البيانات */}
          <div className="mt-4 text-xs text-gray-500 flex justify-between items-center">
            <div>
              عرض {Math.min(visibleRows, filteredRows.length)} من {filteredRows.length} صفوف مصفاة (إجمالي: {excelData.rows.length})
            </div>
            <div className="flex items-center">
              <SlidersHorizontal className="h-3 w-3 ml-1" />
              <span>فلاتر نشطة: {Object.keys(activeFilters).length}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExcelDataPanel;