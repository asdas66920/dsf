import React, { useState } from 'react';
import { CanvasElement, TextElement, ImageElement, ShapeElement, ExcelData } from '../types';
import { v4 as uuidv4 } from 'uuid';

// استيراد المكونات الفرعية
import EmptyState from './property-panel/EmptyState';
import PropertyPanelHeader from './property-panel/PropertyPanelHeader';
import BasicProperties from './property-panel/BasicProperties';
import PositionProperties from './property-panel/PositionProperties';
import EffectsProperties from './property-panel/EffectsProperties';
import TextProperties from './property-panel/TextProperties';
import ShapeProperties from './property-panel/ShapeProperties';
import ImageProperties from './property-panel/ImageProperties';
import DataBindingProperties from './property-panel/DataBindingProperties';

interface PropertyPanelProps {
  selectedElement: CanvasElement | null;
  onUpdateElement: (element: CanvasElement) => void;
  onDeleteElement: (elementId: string) => void;
  excelData: ExcelData | null;
}

const PropertyPanel: React.FC<PropertyPanelProps> = ({
  selectedElement,
  onUpdateElement,
  onDeleteElement,
  excelData,
}) => {
  const [expandedSections, setExpandedSections] = useState({
    basic: true,
    position: true,
    appearance: true,
    text: true,
    shape: true,
    image: true,
    effects: true,
    dataBinding: true,
  });

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const handleDuplicate = () => {
    if (!selectedElement) return;
    
    const duplicatedElement = {
      ...selectedElement,
      id: uuidv4(),
      name: `${selectedElement.name} (نسخة)`,
      x: selectedElement.x + 20,
      y: selectedElement.y + 20,
      zIndex: Date.now(),
    };
    
    onUpdateElement(duplicatedElement);
  };

  // إذا لم يتم اختيار عنصر
  if (!selectedElement) {
    return <EmptyState />;
  }

  return (
    <div className="property-panel p-4 overflow-y-auto scrollbar-thin h-full bg-white shadow-md">
      <PropertyPanelHeader
        selectedElement={selectedElement}
        onDuplicate={handleDuplicate}
        onDelete={() => onDeleteElement(selectedElement.id)}
      />

      <BasicProperties
        selectedElement={selectedElement}
        onUpdateElement={onUpdateElement}
        isExpanded={expandedSections.basic}
        onToggleExpand={() => toggleSection('basic')}
      />

      <PositionProperties
        selectedElement={selectedElement}
        onUpdateElement={onUpdateElement}
        isExpanded={expandedSections.position}
        onToggleExpand={() => toggleSection('position')}
      />

      <EffectsProperties
        selectedElement={selectedElement}
        onUpdateElement={onUpdateElement}
        isExpanded={expandedSections.effects}
        onToggleExpand={() => toggleSection('effects')}
      />

      {selectedElement.type === 'text' && (
        <TextProperties
          textElement={selectedElement as TextElement}
          onUpdateElement={onUpdateElement}
          isExpanded={expandedSections.text}
          onToggleExpand={() => toggleSection('text')}
        />
      )}

      {selectedElement.type === 'shape' && (
        <ShapeProperties
          shapeElement={selectedElement as ShapeElement}
          onUpdateElement={onUpdateElement}
          isExpanded={expandedSections.shape}
          onToggleExpand={() => toggleSection('shape')}
        />
      )}

      {selectedElement.type === 'image' && (
        <ImageProperties
          imageElement={selectedElement as ImageElement}
          onUpdateElement={onUpdateElement}
          isExpanded={expandedSections.image}
          onToggleExpand={() => toggleSection('image')}
        />
      )}

      <DataBindingProperties
        selectedElement={selectedElement}
        onUpdateElement={onUpdateElement}
        excelData={excelData}
        isExpanded={expandedSections.dataBinding}
        onToggleExpand={() => toggleSection('dataBinding')}
      />
    </div>
  );
};

export default PropertyPanel;