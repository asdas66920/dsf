export interface ExcelData {
  headers: string[];
  rows: Record<string, string | number>[];
  fileName: string;
  sheetNames: string[];
  activeSheet: string;
}

export interface DataBinding {
  column: string;
  format?: string;
  position?: {
    x: number;
    y: number;
  };
  // إضافة خصائص تنسيق النص
  textColor?: string;
  fontSize?: number;
  fontFamily?: string;
  fontStyle?: string;
  textDecoration?: string;
  textAlign?: 'left' | 'center' | 'right';
  verticalAlign?: 'top' | 'middle' | 'bottom';
  // إضافة خاصية قالب Handlebars
  template?: string;
  useTemplate?: boolean;
}

export interface DesignElement {
  id: string;
  type: 'text' | 'image' | 'shape';
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  scaleX: number;
  scaleY: number;
  opacity: number;
  visible: boolean;
  name: string;
  zIndex: number;
  dataBinding?: DataBinding | DataBinding[];
}

export interface TextElement extends DesignElement {
  type: 'text';
  text: string;
  fontSize: number;
  fontFamily: string;
  fill: string;
  align: 'left' | 'center' | 'right';
  verticalAlign: 'top' | 'middle' | 'bottom';
  padding: number;
  lineHeight: number;
  fontStyle: string;
  textDecoration: string;
}

export interface ImageElement extends DesignElement {
  type: 'image';
  src: string;
  cropX?: number;
  cropY?: number;
  cropWidth?: number;
  cropHeight?: number;
}

export interface Shadow {
  enabled: boolean;
  color: string;
  blur: number;
  offsetX: number;
  offsetY: number;
  opacity: number;
}

export interface Reflection {
  enabled: boolean;
  opacity: number;
  distance: number;
}

export interface Gradient {
  enabled: boolean;
  type: 'linear' | 'radial';
  angle: number;
  startColor: string;
  endColor: string;
}

export interface Stretch {
  enabled: boolean;
  factor: number;
  direction: 'horizontal' | 'vertical';
}

export interface ShapeElement extends DesignElement {
  type: 'shape';
  shapeType: 'rect' | 'circle' | 'ellipse' | 'line';
  fill: string;
  stroke: string;
  strokeWidth: number;
  strokeStyle?: 'solid' | 'dashed' | 'dotted';
  cornerRadius?: number;
  cornerRadiusTopRight?: number;
  cornerRadiusTopLeft?: number;
  cornerRadiusBottomRight?: number;
  cornerRadiusBottomLeft?: number;
  shadow?: Shadow;
  reflection?: Reflection;
  gradient?: Gradient;
  stretch?: Stretch;
}

export type CanvasElement = TextElement | ImageElement | ShapeElement;

export interface Design {
  id: string;
  name: string;
  width: number;
  height: number;
  elements: CanvasElement[];
  background: string;
}

export interface GenerationSettings {
  outputFormat: 'png' | 'jpeg' | 'pdf';
  quality: number;
  generateFor: 'all' | 'selected';
  selectedRows?: number[];
  selectedRange?: [number, number];
  fileName: string;
}

export interface GeneratedDesign {
  id: string;
  preview: string;
  rowIndex: number;
  downloadUrl: string;
}

// تاريخ التغييرات للتراجع والإعادة
export interface HistoryState {
  design: Design;
  selectedElement: CanvasElement | null;
}

export interface HistoryManager {
  past: HistoryState[];
  future: HistoryState[];
  present: HistoryState;
}