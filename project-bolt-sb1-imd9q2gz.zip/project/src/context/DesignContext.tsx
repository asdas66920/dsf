import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { 
  Design, 
  CanvasElement, 
  ExcelData,
  GenerationSettings,
  GeneratedDesign,
  HistoryManager
} from '../types';
import { 
  createNewDesign, 
  createTextElement, 
  createShapeElement, 
  createImageElement, 
  duplicateElement,
  generateDesignsFromData,
  saveDesignAsJson,
  saveDesignAsTemplate,
  exportDesignAsImage,
  exportDesignAsPdf,
  designToImage,
  loadTemplates,
  deleteTemplate,
  applyTemplate
} from '../utils/designUtils';
import {
  createHistoryManager,
  pushHistory,
  undo,
  redo,
  canUndo,
  canRedo
} from '../utils/historyUtils';
import { useNotification } from './NotificationContext';

interface DesignContextType {
  design: Design;
  selectedElement: CanvasElement | null;
  excelData: ExcelData | null;
  showExcelImporter: boolean;
  showDesignImporter: boolean;
  showSaveModal: boolean;
  showTemplatesModal: boolean;
  showExcelTemplateModal: boolean;
  showPreviewModal: boolean;
  showGenerationPanel: boolean;
  canUndo: boolean;
  canRedo: boolean;
  setDesign: (design: Design) => void;
  setSelectedElement: (element: CanvasElement | null) => void;
  setExcelData: (data: ExcelData | null) => void;
  setShowExcelImporter: (show: boolean) => void;
  setShowDesignImporter: (show: boolean) => void;
  setShowSaveModal: (show: boolean) => void;
  setShowTemplatesModal: (show: boolean) => void;
  setShowExcelTemplateModal: (show: boolean) => void;
  setShowPreviewModal: (show: boolean) => void;
  setShowGenerationPanel: (show: boolean) => void;
  handleAddText: () => void;
  handleAddRect: () => void;
  handleAddCircle: () => void;
  handleAddImage: () => void;
  handleDuplicate: () => void;
  handleDelete: () => void;
  handleUpdateElement: (updatedElement: CanvasElement) => void;
  handleReorderElements: (reorderedElements: CanvasElement[]) => void;
  handleSave: () => void;
  handleSaveDesign: (name: string, format: string) => void;
  handleExport: () => void;
  handleExportDesign: (format: string) => void;
  handleDuplicateDesign: () => void;
  handleImportExcel: () => void;
  handleImportDesign: () => void;
  handleOpenTemplates: () => void;
  handleOpenExcelTemplate: () => void;
  handleApplyTemplate: (template: Design) => void;
  handleDeleteTemplate: (templateId: string) => void;
  handleExcelImported: (data: ExcelData) => void;
  handleSelectSheet: (sheetName: string) => void;
  handleDesignImported: (file: File, width: number, height: number) => void;
  handleGenerate: (settings: GenerationSettings) => Promise<GeneratedDesign[]>;
  handlePreviewDesign: () => void;
  handleUndo: () => void;
  handleRedo: () => void;
}

const DesignContext = createContext<DesignContextType | undefined>(undefined);

export const useDesign = () => {
  const context = useContext(DesignContext);
  if (!context) {
    throw new Error('useDesign must be used within a DesignProvider');
  }
  return context;
};

interface DesignProviderProps {
  children: ReactNode;
}

export const DesignProvider: React.FC<DesignProviderProps> = ({ children }) => {
  const [initialDesign] = useState<Design>(() => 
    createNewDesign(800, 600, 'تصميم جديد')
  );
  
  const [historyManager, setHistoryManager] = useState<HistoryManager>(() => 
    createHistoryManager(initialDesign, null)
  );
  
  const [excelData, setExcelData] = useState<ExcelData | null>(null);
  const [showExcelImporter, setShowExcelImporter] = useState(false);
  const [showDesignImporter, setShowDesignImporter] = useState(false);
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [showTemplatesModal, setShowTemplatesModal] = useState(false);
  const [showExcelTemplateModal, setShowExcelTemplateModal] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [showGenerationPanel, setShowGenerationPanel] = useState(false);
  
  const { showNotification } = useNotification();

  // استخراج التصميم والعنصر المحدد من مدير التاريخ
  const design = historyManager.present.design;
  const selectedElement = historyManager.present.selectedElement;

  // تحديث التصميم مع حفظ التاريخ
  const setDesign = (newDesign: Design) => {
    setHistoryManager(pushHistory(historyManager, newDesign, selectedElement));
  };

  // تحديث العنصر المحدد مع حفظ التاريخ
  const setSelectedElement = (element: CanvasElement | null) => {
    setHistoryManager(prevHistory => ({
      ...prevHistory,
      present: {
        ...prevHistory.present,
        selectedElement: element
      }
    }));
  };

  // إضافة عنصر نص جديد
  const handleAddText = () => {
    const newElement = createTextElement(
      design.width / 2 - 100,
      design.height / 2 - 25
    );
    
    const newDesign = {
      ...design,
      elements: [...design.elements, newElement]
    };
    
    setHistoryManager(pushHistory(historyManager, newDesign, newElement));
  };

  // إضافة عنصر مستطيل جديد
  const handleAddRect = () => {
    const newElement = createShapeElement(
      design.width / 2 - 50,
      design.height / 2 - 50,
      'rect'
    );
    
    const newDesign = {
      ...design,
      elements: [...design.elements, newElement]
    };
    
    setHistoryManager(pushHistory(historyManager, newDesign, newElement));
  };

  // إضافة عنصر دائرة جديد
  const handleAddCircle = () => {
    const newElement = createShapeElement(
      design.width / 2 - 50,
      design.height / 2 - 50,
      'circle'
    );
    
    const newDesign = {
      ...design,
      elements: [...design.elements, newElement]
    };
    
    setHistoryManager(pushHistory(historyManager, newDesign, newElement));
  };

  // إضافة عنصر صورة جديد
  const handleAddImage = () => {
    // في التطبيق الحقيقي، سيتم فتح مربع حوار لاختيار الصورة
    // هنا نستخدم صورة افتراضية للتوضيح
    const placeholderImage = 'https://via.placeholder.com/200x200';
    
    const newElement = createImageElement(
      design.width / 2 - 100,
      design.height / 2 - 100,
      placeholderImage,
      200,
      200
    );
    
    const newDesign = {
      ...design,
      elements: [...design.elements, newElement]
    };
    
    setHistoryManager(pushHistory(historyManager, newDesign, newElement));
  };

  // نسخ العنصر المحدد
  const handleDuplicate = () => {
    if (!selectedElement) return;
    
    const duplicatedElement = duplicateElement(selectedElement);
    
    const newDesign = {
      ...design,
      elements: [...design.elements, duplicatedElement]
    };
    
    setHistoryManager(pushHistory(historyManager, newDesign, duplicatedElement));
  };

  // حذف العنصر المحدد
  const handleDelete = () => {
    if (!selectedElement) return;
    
    const newDesign = {
      ...design,
      elements: design.elements.filter(el => el.id !== selectedElement.id)
    };
    
    setHistoryManager(pushHistory(historyManager, newDesign, null));
  };

  // تحديث خصائص العنصر
  const handleUpdateElement = (updatedElement: CanvasElement) => {
    const newDesign = {
      ...design,
      elements: design.elements.map(el => 
        el.id === updatedElement.id ? updatedElement : el
      )
    };
    
    const newSelectedElement = selectedElement && selectedElement.id === updatedElement.id
      ? updatedElement
      : selectedElement;
    
    setHistoryManager(pushHistory(historyManager, newDesign, newSelectedElement));
  };

  // إعادة ترتيب العناصر
  const handleReorderElements = (reorderedElements: CanvasElement[]) => {
    const newDesign = {
      ...design,
      elements: reorderedElements
    };
    
    setHistoryManager(pushHistory(historyManager, newDesign, selectedElement));
  };

  // فتح نافذة الحفظ
  const handleSave = () => {
    // التحقق من وجود عناصر في التصميم
    if (design.elements.length === 0) {
      showNotification('لا يمكن حفظ تصميم فارغ. يرجى إضافة عناصر أولاً.', 'error');
      return;
    }
    
    setShowSaveModal(true);
  };

  // حفظ التصميم
  const handleSaveDesign = (name: string, format: string) => {
    // تحديث اسم التصميم
    const updatedDesign = {
      ...design,
      name
    };
    
    setHistoryManager(pushHistory(historyManager, updatedDesign, selectedElement));
    
    // حفظ التصميم بالتنسيق المحدد
    if (format === 'json') {
      // حفظ كملف JSON
      saveDesignAsJson(updatedDesign, name);
      showNotification('تم حفظ التصميم بنجاح', 'success');
    } else if (format === 'template') {
      // حفظ كقالب
      saveDesignAsTemplate(updatedDesign, name);
      showNotification('تم حفظ التصميم كقالب بنجاح', 'success');
    }
  };

  // تصدير التصميم
  const handleExport = () => {
    // التحقق من وجود عناصر في التصميم
    if (design.elements.length === 0) {
      showNotification('لا يمكن تصدير تصميم فارغ. يرجى إضافة عناصر أولاً.', 'error');
      return;
    }
    
    setShowSaveModal(true);
  };

  // تصدير التصميم بتنسيق محدد
  const handleExportDesign = async (format: string) => {
    let success = false;
    
    if (format === 'png' || format === 'jpeg') {
      success = await exportDesignAsImage(design, format, 90, design.name);
    } else if (format === 'pdf') {
      success = await exportDesignAsPdf(design, design.name);
    }
    
    if (success) {
      showNotification(`تم تصدير التصميم بتنسيق ${format} بنجاح`, 'success');
    } else {
      showNotification('حدث خطأ أثناء تصدير التصميم', 'error');
    }
  };

  // نسخ التصميم الحالي
  const handleDuplicateDesign = () => {
    const duplicatedDesign = {
      ...design,
      id: uuidv4(),
      name: `${design.name} (نسخة)`
    };
    
    setHistoryManager(pushHistory(historyManager, duplicatedDesign, selectedElement));
    showNotification('تم نسخ التصميم بنجاح', 'success');
  };

  // استيراد ملف Excel
  const handleImportExcel = () => {
    setShowExcelImporter(true);
  };

  // استيراد تصميم
  const handleImportDesign = () => {
    setShowDesignImporter(true);
  };

  // فتح نافذة القوالب
  const handleOpenTemplates = () => {
    setShowTemplatesModal(true);
  };

  // فتح نافذة نموذج Excel
  const handleOpenExcelTemplate = () => {
    setShowExcelTemplateModal(true);
  };

  // تطبيق قالب
  const handleApplyTemplate = (template: Design) => {
    const newDesign = applyTemplate(template);
    setHistoryManager(pushHistory(historyManager, newDesign, null));
    showNotification('تم تطبيق القالب بنجاح', 'success');
  };

  // حذف قالب
  const handleDeleteTemplate = async (templateId: string) => {
    const success = await deleteTemplate(templateId);
    if (success) {
      showNotification('تم حذف القالب بنجاح', 'success');
    } else {
      showNotification('حدث خطأ أثناء حذف القالب', 'error');
    }
  };

  // معالجة استيراد ملف Excel
  const handleExcelImported = (data: ExcelData) => {
    setExcelData(data);
    setShowExcelImporter(false);
    setShowGenerationPanel(true);
    showNotification('تم استيراد ملف Excel بنجاح', 'success');
  };

  // تغيير ورقة العمل النشطة في Excel
  const handleSelectSheet = (sheetName: string) => {
    if (!excelData) return;
    
    // في التطبيق الحقيقي، سيتم تحميل البيانات من الورقة المحددة
    console.log(`تم اختيار ورقة العمل: ${sheetName}`);
  };

  // معالجة استيراد تصميم
  const handleDesignImported = (file: File, width: number, height: number) => {
    // تعديل حجم التصميم ليتناسب مع حجم الصورة المستوردة
    const newDesign = {
      ...design,
      width: width,
      height: height
    };
    
    // إنشاء عنصر صورة جديد من الملف المستورد
    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target && e.target.result) {
        const imageUrl = e.target.result as string;
        
        // إنشاء عنصر صورة جديد بنفس حجم الصورة
        const newElement = createImageElement(
          0,
          0,
          imageUrl,
          width,
          height
        );
        
        // إضافة العنصر إلى التصميم
        const updatedDesign = {
          ...newDesign,
          elements: [...design.elements, newElement]
        };
        
        setHistoryManager(pushHistory(historyManager, updatedDesign, newElement));
        
        showNotification('تم استيراد التصميم بنجاح', 'success');
      }
    };
    reader.readAsDataURL(file);
    
    setShowDesignImporter(false);
  };

  // معاينة التصميم قبل التوليد
  const handlePreviewDesign = () => {
    if (!excelData || excelData.rows.length === 0) {
      showNotification('يجب استيراد ملف Excel أولاً', 'error');
      return;
    }
    
    setShowPreviewModal(true);
  };

  // توليد التصاميم
  const handleGenerate = async (settings: GenerationSettings): Promise<GeneratedDesign[]> => {
    if (!excelData) {
      return [];
    }
    
    let rowIndices: number[] = [];
    
    if (settings.generateFor === 'all') {
      // توليد لجميع الصفوف
      rowIndices = Array.from({ length: excelData.rows.length }, (_, i) => i);
    } else if (settings.generateFor === 'selected' && settings.selectedRange) {
      // توليد لنطاق محدد من الصفوف
      const [start, end] = settings.selectedRange;
      rowIndices = Array.from(
        { length: end - start + 1 },
        (_, i) => start + i
      );
    }
    
    // تطبيق تحسينات الأداء إذا كانت مفعلة
    const optimizationOptions = {
      optimizeMemory: settings.optimizeMemory || false,
      parallelProcessing: settings.parallelProcessing || false,
      batchSize: settings.optimizeMemory ? 10 : undefined,
    };
    
    // توليد التصاميم
    return await generateDesignsFromData(design, excelData, rowIndices, optimizationOptions);
  };

  // التراجع عن آخر تغيير
  const handleUndo = () => {
    if (canUndo(historyManager)) {
      setHistoryManager(undo(historyManager));
    }
  };

  // إعادة التغيير الذي تم التراجع عنه
  const handleRedo = () => {
    if (canRedo(historyManager)) {
      setHistoryManager(redo(historyManager));
    }
  };

  // استخدام اختصارات لوحة المفاتيح للتراجع والإعادة
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // التراجع: Ctrl+Z
      if (e.ctrlKey && e.key === 'z') {
        e.preventDefault();
        handleUndo();
      }
      
      // الإعادة: Ctrl+Y أو Ctrl+Shift+Z
      if ((e.ctrlKey && e.key === 'y') || (e.ctrlKey && e.shiftKey && e.key === 'z')) {
        e.preventDefault();
        handleRedo();
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [historyManager]);

  const value = {
    design,
    selectedElement,
    excelData,
    showExcelImporter,
    showDesignImporter,
    showSaveModal,
    showTemplatesModal,
    showExcelTemplateModal,
    showPreviewModal,
    showGenerationPanel,
    canUndo: canUndo(historyManager),
    canRedo: canRedo(historyManager),
    setDesign,
    setSelectedElement,
    setExcelData,
    setShowExcelImporter,
    setShowDesignImporter,
    setShowSaveModal,
    setShowTemplatesModal,
    setShowExcelTemplateModal,
    setShowPreviewModal,
    setShowGenerationPanel,
    handleAddText,
    handleAddRect,
    handleAddCircle,
    handleAddImage,
    handleDuplicate,
    handleDelete,
    handleUpdateElement,
    handleReorderElements,
    handleSave,
    handleSaveDesign,
    handleExport,
    handleExportDesign,
    handleDuplicateDesign,
    handleImportExcel,
    handleImportDesign,
    handleOpenTemplates,
    handleOpenExcelTemplate,
    handleApplyTemplate,
    handleDeleteTemplate,
    handleExcelImported,
    handleSelectSheet,
    handleDesignImported,
    handleGenerate,
    handlePreviewDesign,
    handleUndo,
    handleRedo
  };

  return (
    <DesignContext.Provider value={value}>
      {children}
    </DesignContext.Provider>
  );
};